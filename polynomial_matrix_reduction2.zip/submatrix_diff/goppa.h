#pragma once
#ifndef __GOPPA_H
#define __GOPPA_H
#include <inttypes.h>
#include "matrix.h"

extern double encTimeArr[2];
extern double decTimeArr[10];


void gpp_init();

void gpp_finish(stMatVec gvec);
int find_pivot_popov_col(stPoly **P, int row, int last_col);

void gpp_bernstein1(uint64_t *codeword, stPoly *del, const int u, int *t0, int *lk);
void gpp_bernstein2(stPoly delta, int k, const int u, int t0, int *l, const int flag);
void cal_l(int *theta, int *l, int *lk, int e0_deg, int t, int extra);
#endif