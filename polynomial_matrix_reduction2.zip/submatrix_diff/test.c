#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <math.h>
#include "config.h"
#include "poly.h"
#include "matrix.h"
#include "goppa.h"
#include "test.h"

int pCnt = 0;
int nRow = 0;

int *IDX;

int fact(int n)
{
    int i, f = 1;
    for(i = 1; i <= n;i++)
    {
        f = f*i;
    }
    return f;
}

void idx_org(int *idx, int l)
{
	int i;
	for(i=0; i<l; i++)
		idx[i] = i;
}

int state(stPoly **P, int l)
{
	 int nst = 0, i, p;
	 
	 for(i=0; i < l; i++) {
		 p = find_pivot_popov_col(P, i, l);
		 if(p != -1) {
			 //printf("%d\n", (P[i][p]->d * l + (p + 1))); 
			 nst = nst + (P[i][p]->d * l + (p + 1));
			 //printf("[%d] = %d, %d\n", i, P[i][p]->d, p);
		 }
	 }
	 
	 return nst;
}

void pri_deg(stPoly **P, int row, int col)
{
	int i, p;
	FILE *fp;
	
	if ((fp = fopen("st_original.txt", "a")) == NULL)
	{
		printf("file write error\n");
		return;
	}
	
	p = find_pivot_popov_col(P, row, col);
	fprintf(fp, "%d,%d,", row, p);
	for(i=P[row][p]->d - 1; i >= 0; i--) {
		if(P[row][p]->c[i] != 0) {
			fprintf(fp, "%d,", i);
			break;
		}
	}
	
	for(i=0; i < col; i++)
		fprintf(fp, "%d,", P[row][i]->d);	
	
	fprintf(fp, "\n");
	fclose(fp);
}

void idx_rand(int *idx, int l)
{
	int i, j;
	i=0;
	while(i < l) {
		idx[i] = rand() % l;
		for(j=0; j < i; j++) {		
			if(idx[i] == idx[j]) {
				idx[i] = -1;
				break;
			}
		}
		
		if(idx[i] == -1)
			continue;				
		i += 1;
	}
}

void idx_proposed1(int *idx, int k, int l)
{
	int i, j, z;
	
	z = 0;
	for(i = 0; i < k; i++)
	{
		idx[z] = i;
		j = 0;	
		do {
			z = z + 1;	
			j = j + 1;									
			idx[z] = j * k + i;
			
		}while(j * k + i < l);				
	}
}

void idx_proposed2(int *idx, int k, int l)
{
	int i, j, z;
	int ncr, r, b;
	int **nonzero_coef;			
	nonzero_coef = (int **)malloc(sizeof(int *) * ((int)log2(k) + 1));
	
	for(i=0; i < ((int)log2(k) + 1); i++){
		nonzero_coef[i] = (int *)malloc(sizeof(int) * l);
		nonzero_coef[i][l-1] = 0;
	}
				
	for(i=0; i <= k; i++)
	{
		z = 0;
		for(j=0; j<= i; j++)
		{
			ncr=fact(i)/(fact(j)*fact(i-j));
			z = z + ncr%2;
		}
		nonzero_coef[(int)log2(z)][nonzero_coef[(int)log2(z)][l-1]] = i;
		nonzero_coef[(int)log2(z)][l-1] += 1;
	}
	
	z = 0;
	idx[0] = nonzero_coef[0][0];
	for(i = 1; i < ((int)log2(k) + 1); i++){
		r=0; b=0;
		do{
			for(j = nonzero_coef[i][l-1] - 1; j>=0; j--)
			{
				if(l <= r * k + nonzero_coef[i][j]){
					b = b + 1;
					continue;
				}
				z = z + 1;
				idx[z] = r * k + nonzero_coef[i][j];
			}
			r = r + 1;
		}while(b < nonzero_coef[i][l-1]);
	}
	
	for(i=0; i < ((int)log2(k) + 1); i++)
		free(nonzero_coef[i]);
	free(nonzero_coef);
	
}

void test_read_val(stPoly **mb, char *filename)
{
	int i, j=0;
	FILE *fp = NULL;
	char str_tmp[20000] = { 0, };
	char *ptr;
	int row, col, deg;
	uint16_t coef;

	if ((fp = fopen(filename, "r")) == NULL)
	{
		printf("file read error: %s\n", filename);
		return;
	}

	while (!feof(fp))
	{
		str_tmp[0] = 0;

		fgets(str_tmp, 19900, fp);

		if(str_tmp[0] == 0)
			continue;
		
		ptr = strtok(str_tmp, ",");	row = atoi(ptr);
		ptr = strtok(NULL, ",");	col = atoi(ptr);
		ptr = strtok(NULL, ",");	deg = atoi(ptr);	

		mb[row][col]->d = deg;
		if (deg != -1)
		{
			for (i = 0; i <= deg; i++)
			{
				ptr = strtok(NULL, ","); coef = atoi(ptr);
				mb[row][col]->c[i] = (coef);
			}
		}
		j += 1;
	}

	fclose(fp);
	return;
}

void test_write_val(stPoly **mb, int row, int col, char *filename)
{
	int i, j, z;
	FILE *fp = NULL;

	if ((fp = fopen(filename, "w")) == NULL)
	{
		printf("file write error\n");
		return;
	}

	for (i = 0; i < row; i++)
	{
		for (j = 0; j < col; j++)
		{
			fprintf(fp, "%d,%d,%d,", i, j, mb[i][j]->d);
			for (z = 0; z <= mb[i][j]->d; z++)
				fprintf(fp, "%d,", (mb[i][j]->c[z]));
			fprintf(fp, "\n");
		}
	}

	fclose(fp);
	return;
}



void WeakPopovFormSub_swap(stPoly** mb, int rows, int cols)
{
	int i, j, k, p, z, d;
	int pivots[100] = { 0, };
	int e;
	void* swap;
	uint16_t c;
	stPoly tmp = poly_alloc(5000);

	for (i = 0; i < rows; i++)
		pivots[i] = -1;

	for (i = 0; i < rows; i++)
	{
		FILE *fp = NULL;	
		if ((fp = fopen("pCnt.txt", "a")) == NULL) {
			printf("file write error\n");
			return;
		}
	
		fprintf(fp, "%d=%d\n", i , pCnt);
		fclose(fp);
		
		p = find_pivot_popov_col(mb, i, cols);
		
		if (p == -1)
			continue;
		pivots[i] = p;

		for (j = 0; j < i; j++)
		{
			if (p == pivots[j])
			{
				pCnt += 1;
				int jd = mb[j][p]->d;
				int id = mb[i][p]->d;
				e = jd - id;
				
				if (e <= 0)
					e = abs(e);
				else
				{
					swap = mb[j];
					mb[j] = mb[i];
					mb[i] = swap;

					id = mb[i][p]->d;
					jd = mb[j][p]->d;
				}

				c = gf_mul(mb[i][p]->c[id], gf_inv(mb[j][p]->c[jd]));

				for (k = 0; k < cols; k++)
				{
					d = -1;
					for (z = e; z >= 0; z--)
						tmp->c[z] = 0;

					for (z = 0; z <= mb[j][k]->d; z++)
					{
						d = z + e;
						tmp->c[d] = gf_mul(mb[j][k]->c[z], c);
					}
					tmp->d = d;
					poly_add(mb[i][k], mb[i][k], tmp);
				}

				i = i - 1;
				break;
			}
		}
		
		
	}
	
	poly_free(tmp);
}

double WeakPopovFormSub(FILE *fp, char *filename, int lk, int l, int *idxs)
{
	int i, j, k;
	stPoly** mb;
	char title[100];
	double start=0.0, end=0.0;
	stPoly** sub = (stPoly**)malloc(sizeof(stPoly*) * l);
	
#if _M == 6
	int len[8] = {6, 11, 16, 21, 27, 32, 37,42};
	int idx[8][42] = {0,};
	//int len[2] = {2,3};
	//int idx[2][3] = {0,};
#elif _M == 7
	int len[4] = {8, 15, 23, 30};
	int idx[4][30] = {0,};
#elif _M == 8
	int len[8] = {11, 22, 33, 44, 55, 66, 77, 87};
	int idx[8][87] = {0,};	
#elif _M == 4
	int len[4] = {4,8,11,14};
	int idx[4][14] = {0,};		
	//int len[4] = {3,5,7,9};
	//int idx[4][9] = {0,};
#elif _M == 5
	int len[4] = {6,11,16,21};
	int idx[4][21] = {0,};	
#endif

	for(i=0; i < lk; i++) 
	{
		for( j = 0; j < len[i]; j++)
			idx[i][j] = idxs[j];
	}
	
	mb = (stPoly**)malloc(sizeof(stPoly*) * l);
	for (i = 0; i < l; i++)
	{
		mb[i] = (stPoly*)malloc(sizeof(stPoly) * l);

		for (j = 0; j < l; j++)
			mb[i][j] = poly_alloc(5000);
	}

	sprintf(title, "%s.csv", filename);
	test_read_val(mb, title);
	
	start = (((double)clock()) / CLOCKS_PER_SEC);
	for (i = 0; i < lk; i++)
	{
		for (j = 0; j < len[i]; j++)
			sub[j] = mb[idx[i][j]];

		WeakPopovFormSub_swap(sub, len[i], l);
	}
	end = (((double)clock()) / CLOCKS_PER_SEC);

	{
		sprintf(title, "%s_swap.csv", filename);
		test_write_val(mb, l, l, title);
	}
	
	for(i = 0; i < l; i++)
	{		
		for(j = 0; j < l; j++)
			poly_free(mb[i][j]);
	}
	free(mb);
	free(sub);

	return (end - start);
}

void minima(char* filename, int l)
{
	int i, j;
	stPoly** mb;
	int rowdeg;
	int idx = 0, min = 3000;
	char title[100];

	mb = (stPoly**)malloc(sizeof(stPoly*) * l);

	for (i = 0; i < l; i++)
	{
		mb[i] = (stPoly*)malloc(sizeof(stPoly) * l);

		for (j = 0; j < l; j++)
			mb[i][j] = poly_alloc(3000);
	}

	sprintf(title, "%s.csv", filename);
	test_read_val(mb, title);

	for (i = 0; i < l; i++)
	{
		rowdeg = mb[i][0]->d;
		for (j = 1; j < l; j++)
		{
			if (rowdeg < mb[i][j]->d)
				rowdeg = mb[i][j]->d;
		}

		if (rowdeg < min)
		{
			min = rowdeg;
			idx = i;
		}
	}
	printf("min = %d\n", min);

	for (i = 0; i < l; i++)
	{
		printf("phi[%d] = ", i);
		for (j = 0; j < mb[idx][i]->d; j++)
			printf("F.fetch_int(%u)*x^%d + ", mb[idx][i]->c[j], j);
		printf("F.fetch_int(%u)*x^%d ", mb[idx][i]->c[j], j);
		printf("\n");
	}
}

void test_goppa()//Edited on 2023-02-08
{
	int i, k, t0, u, l, f;
	uint64_t *y;
	stPoly delta;

	char title[100];
	double avg1 = 0, avg2 = 0, rst;
	
	int err[100] = {0, };	
	
	FILE *fp = NULL;
	
	int *idx;
	int z, j;
	
	sprintf(title, "performance_%d.txt", _M);
	if ((fp = fopen(title, "a")) == NULL) {
		printf("file write error\n");
		return;
	}
	
	for(i=0; i<100; i++)
		title[i] = 0x00;
	
	y = (uint64_t *)calloc(BYTE_N, sizeof(uint64_t));
	
	u = (int)floor(_N - _T - sqrt(_N * (_N - 2 * _T - 2)));
	
	u = _U;
	printf("u=%d\n", u);

	for(f = 101; f < 102; f++) { //<< start loop//37
		int errVector[_N] = {0,};
		int errCnt = 0;
		
		for (i = 0; i < BYTE_N; i++)
			y[i] = 0;
		
		/* generate errors */
		do {
			int tmp = rand() % _N;
			if(errVector[tmp] == 0) {
				errVector[tmp] = 1;
				err[errCnt] = tmp;
				errCnt += 1;
			}
		}while( errCnt < (_T + u) );
				
		printf("err %d = ", f);
		for (i = 0; i < _T + u; i++)
			printf("%d ", err[i]);
		printf("\n");
				
		fprintf(fp, "err %d = ", f);
		for (i = 0; i < _T + u; i++) {
			fprintf(fp, "%d ", err[i]);
		}
		fprintf(fp, "\n");

		for (i = 0; i < _T + u; i++)
			VEC_SET_BIT(y, err[i], 1);
		
		gpp_bernstein1(y, &delta, u, &t0, &k); 
		
		k = _LATTICE_K;

		if (((-k) & k) != k) {
			printf("k is not a power of 2\n");
			return;
		}	
		gpp_bernstein2(delta, k, u, t0, &l, f); //create a lattice

		idx = (int*)malloc(sizeof(int) * l);
		{		
			sprintf(title, "my_lattice_m%d_t%d_u%d_lk%d_l%d_%d", _M, _T, u, k, l, f);

			idx_org(idx, l);
			for(i=0; i<l; i++) { printf("%d ", IDX[i]);  } printf("\n"); 
			
			pCnt = 0; nRow = 0;
			rst = WeakPopovFormSub(fp, title, k, l, idx);
			
			printf("original = %.2lf ", rst); printf("original = %d\n", pCnt); 
			fprintf(fp, "original = %.2lf ", rst); fprintf(fp, "original = %d\n", pCnt);		

			//proposed3
			for(i=0; i<l; i++) { printf("%d ", idx[i]);  } printf("\n"); 
			
			pCnt = 0;	nRow = 0;
			rst = WeakPopovFormSub(fp, title, k, l, IDX);
			
			printf("proposed3 = %.2lf ", rst); printf("proposed3 = %d\n", pCnt); 
			fprintf(fp, "proposed3 = %.2lf ", rst); fprintf(fp, "proposed3 = %d\n", pCnt);	

		}	

		{
			sprintf(title, "my_lattice_m%d_t%d_u%d_lk%d_l%d_%d_swap", _M, _T, u, k, l, f);
			minima(title, l);
		}

		free(idx);
	
	}//<< end loop
	fclose(fp);
	free(y);
	return;
}

#define logB(x, base) log(x)/log(base)
void test_IDX() 
{
	int theta, l, k = _LATTICE_K - 1;
	int i, j;
	stPoly h;
	stPoly delta;
	char filename[100];
	stPoly** mb;
	int min_diff_poly, min_diff_vec, d, r;
	int **idxgroup;
	
	gpp_init();
	
	cal_l(&theta, &l, &k, _T, _T, _U);
		
	IDX = (int *)malloc(sizeof(int) * l);
	
	idxgroup  = (int **)malloc(sizeof(int*) * (logB((double)k, 2.0) +1));
	
	for (i = 0; i <= logB((double)k, 2.0) ; i++)
	{
		idxgroup[i]  = (int *)malloc(sizeof(int*) * k);
		
		for (j = 0; j < k ; j++){
			idxgroup[i][j]=0;
		}
	}
	
		
	h = poly_alloc(_ORDER + 2);
	h->c[_Q] = 1; h->c[1] = 1; h->d = _Q;
	
	//delta = poly_alloc(_ORDER + 2);
	delta = poly_alloc(_ORDER + 2);
	delta->d = h->d - 1;
	for(i=0; i<=delta->d; i++)
		delta->c[i] = 1;
	
	//Step 7
	genReducMat(theta, l, k, h, delta, _U, 0);
	
	sprintf(filename, "my_lattice_m%d_t%d_u%d_lk%d_l%d_%d.csv", _M, _T, _U, k, l, 0);
		
	mb = (stPoly**)malloc(sizeof(stPoly*) * l);
	for (i = 0; i < l; i++)
	{
		mb[i] = (stPoly*)malloc(sizeof(stPoly) * l);

		for (j = 0; j < l; j++)
			mb[i][j] = poly_alloc(5000);
	}	
	test_read_val(mb, filename);
	
	for(i=0; i < k; i++)
	{
		min_diff_vec = mb[i][0]->d;
		
		for(j=0; j < l; j++)
		{
			d = min_diff_poly = mb[i][j]->d;
			
			while(d > 0)
			{
				r = d;
				do{
					r = r - 1;
				}while(r > 0 && mb[i][j]->c[r] == 0);
				
				if (min_diff_poly > d - r)
					min_diff_poly = d - r;
				
				d = r;			
			}
			
			if (min_diff_poly != -1 && min_diff_vec > min_diff_poly)
					min_diff_vec  = min_diff_poly;
		}
		
		for(j= logB((double)k, 2.0); j >= 0; j--){
			if ( min_diff_vec >= pow(2.0, (double)j) ){
				idxgroup[j][idxgroup[j][k-1]] = i;
				idxgroup[j][k-1] = idxgroup[j][k-1] + 1;
				break;
			}
		}
	}
	
	r=0;
	for(i= logB((double)k, 2.0); i >= 0; i--)
	{
		for(j=0; j < idxgroup[i][k-1]; j++)
		{
			d = 0;
			do{
				IDX[r] = (idxgroup[i][j] + k * d); 
				d = d + 1;
				r = r + 1;
			}while( idxgroup[i][j] + k * d < l);
		}
	}
	
	for(i = 0; i < l; i++)
	{		
		for(j = 0; j < l; j++)
			poly_free(mb[i][j]);
	}
	free(mb);
	
	return;
}