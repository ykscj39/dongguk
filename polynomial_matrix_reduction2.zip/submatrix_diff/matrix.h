#pragma once
#ifndef __MATRIX_H
#define __MATRIX_H
#include <inttypes.h>

//typedef struct _vector {
//	uint64_t *arr;
//} vector;

typedef struct _stMatVec {
	int row;
	int col;
	int colSize;
	uint64_t **v;
} *stMatVec;

typedef struct _stMatInt {
	int row;
	int col;
	uint16_t **mat; //20201028
} *stMatInt;

extern int _cwlen;
extern int _mslen;

extern uint64_t _pad;

#define VEC_WORDBITS	(sizeof(uint64_t) * 8)	///< 8, 16, 32, 64 

static inline int log2_floor(unsigned x)
{
#define NIMHTNOE0WNM(n) (((~(x>>n)+1)>>n)&n)

	int res, n;

	n = NIMHTNOE0WNM(16); res = n; x >>= n;
	n = NIMHTNOE0WNM(8); res |= n; x >>= n;
	n = NIMHTNOE0WNM(4); res |= n; x >>= n;
	n = NIMHTNOE0WNM(2); res |= n; x >>= n;
	n = NIMHTNOE0WNM(1); res |= n;
	return res;
}

#define VEC_LOG			log2_floor(VEC_WORDBITS)
#define VEC_SIZE(x)		((x >> VEC_LOG) + (!!(x & (VEC_WORDBITS - 1))))

#define BYTE_N VEC_SIZE(_cwlen)
#define BYTE_K VEC_SIZE(_mslen)

static inline void VEC_SET_BIT(uint64_t *vec, int i, uint64_t val)
{
	vec[i >> VEC_LOG] ^= (val << (i & (VEC_WORDBITS - 1)));
	return;
}

static inline int VEC_GET_BIT(uint64_t *vec, int i)
{
	return (1 & (vec[i >> VEC_LOG] >> (i & (VEC_WORDBITS - 1))));
}

static inline void vec_swap(int size, uint64_t *a, uint64_t *b)
{
	int i;
	uint64_t swap;
	for (i = 0; i < size; i++)
	{
		swap = a[i];
		a[i] = b[i];
		b[i] = swap;
	}
	return;
}

static inline void vec_xor(int size, uint64_t *src, uint64_t *dst)
{
	int i;
	for (i = 0; i < size; i++)
		dst[i] ^= src[i];
	return;
}

static inline void vec_cpy(int size, uint64_t *src, uint64_t *dst)
{
	int i;

	for (i = 0; i < size; i++)
		dst[i] = src[i];

	return;
}

static inline void vec_set_zero(uint64_t *array, int size)
{
	int i;
	for (i = 0; i < size; i++)
		array[i] = 0;
	return;
}

void vec_init(int n, int k);
void vec_print(uint64_t *a, int len, char *title);
void vec_genRndVec(uint64_t *a, int aLen);

stMatInt mat_allocInt(int row, int col);
void mat_freeInt(stMatInt a);

stMatVec mat_allocVec(int row, int col);
void mat_freeVec(stMatVec a);

stMatVec mat_IntToVec(int block, stMatInt H);
int mat_ref(stMatVec A, stMatVec *ref);
stMatVec mat_trs(stMatVec a);


int mat_mulVec(uint64_t *rst, uint64_t *vt, stMatVec mt);
stMatVec mat_ivs(stMatVec A);
stMatVec mat_mulMat(stMatVec A, stMatVec B);
void mat_print(stMatVec A, char *title);

void mat_nullSpace(stMatVec *nullSpace, stMatVec A);

#endif