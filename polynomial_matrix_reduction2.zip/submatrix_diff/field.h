#pragma once
#ifndef __FIELD_H
#define __FIELD_H

#include <inttypes.h>

extern int _ext;
extern uint16_t _ord;

extern uint16_t *gf_exp;
extern uint16_t *gf_val;

#define gf_get_exp(i)			gf_exp[i] ///< gf_get_val(value) = alpha^i, return alpha^i
#define gf_get_val(i)			gf_val[i] ///< gf_get_val(alpha^i)

#define gf_add(x, y)			(x ^ y)
#define gf_mod_q(d)				(((d) & _ord) + ((d) >> _ext)) ///<  d % _Q
#define gf_mul_fast(x, y)		((y) ? gf_val[gf_mod_q(gf_exp[x] + gf_exp[y])] : 0)
#define gf_mul(x, y)			((x) ? gf_mul_fast(x, y) : 0)
#define gf_quo(x, y)			((x) ? gf_val[gf_mod_q(gf_exp[x] - gf_exp[y])] : 0)
#define gf_inv(x)				((x) ? gf_val[_ord - gf_exp[x]] : 0)
#define gf_square(x)			((x) ? gf_val[gf_mod_q(gf_exp[x] << 1)] : 0)		///< (alpha^i)^2
#define gf_sqrt(x)				((x) ? gf_val[gf_mod_q(gf_exp[x] << (_ext - 1))] : 0) ///< square root


void gf_elements(int m, int n);
uint16_t gf_exp_pow(uint16_t x, int i);
#endif
