package hqc128;

//codeword is 128 bits, seen multiple ways
class Codeword{
	byte[] u8 = new byte[16];
	int[] u32 = new int[4];
	
	public void setu32(int idx, int val) {
		this.u32[idx] = val;
		int i = idx * 4;
		this.u8[i + 0] = (byte) (val & 0x000000FF);
		this.u8[i + 1] = (byte) ((val >> 8) & 0x000000FF);
		this.u8[i + 2] = (byte) ((val >> 16) & 0x000000FF);
		this.u8[i + 3] = (byte) ((val >> 24) & 0x000000FF);		
	}
};

class ExpandedCodeword{
	short[] v;	
	public ExpandedCodeword() {
		this.v = new short[128];
	}
}

//Expanded codeword has a short for every bit, for internal calculations
public class Reed_muller {
	Parameters parameters = new Parameters();
	Pri pri = new Pri();
	int BIT0MASK(int x) {
		return (int)(-((x) & 1));
	}
	
	int MULTIPLICITY(){
		return parameters.CEIL_DIVIDE(parameters.PARAM_N2, 128);
	}
	
	void copy(Codeword src, Codeword dst) {
		for(int i = 0; i < src.u32.length; i++)
			dst.setu32(i, src.u32[i]);	
	}
	
	/**
	 * @brief Encode a single byte into a single codeword using RM(1,7)
	 *
	 * Encoding matrix of this code:
	 * bit pattern (note that bits are numbered big endian)
	 * 0   aaaaaaaa aaaaaaaa aaaaaaaa aaaaaaaa
	 * 1   cccccccc cccccccc cccccccc cccccccc
	 * 2   f0f0f0f0 f0f0f0f0 f0f0f0f0 f0f0f0f0
	 * 3   ff00ff00 ff00ff00 ff00ff00 ff00ff00
	 * 4   ffff0000 ffff0000 ffff0000 ffff0000
	 * 5   ffffffff 00000000 ffffffff 00000000
	 * 6   ffffffff ffffffff 00000000 00000000
	 * 7   ffffffff ffffffff ffffffff ffffffff
	 *
	 * @param[out] word An RM(1,7) codeword
	 * @param[in] message A message
	 */
	void encode(Codeword word, int message) {
	    int first_word;

	    first_word = BIT0MASK(message >> 7);

	    first_word ^= BIT0MASK(message >> 0) & 0xaaaaaaaa;
	    first_word ^= BIT0MASK(message >> 1) & 0xcccccccc;
	    first_word ^= BIT0MASK(message >> 2) & 0xf0f0f0f0;
	    first_word ^= BIT0MASK(message >> 3) & 0xff00ff00;
	    first_word ^= BIT0MASK(message >> 4) & 0xffff0000;

	    word.setu32(0, first_word);//word.u32[0] = first_word;

	    first_word ^= BIT0MASK(message >> 5);
	    word.setu32(1, first_word);//word.u32[1] = first_word;
	    first_word ^= BIT0MASK(message >> 6);
	    word.setu32(3, first_word);//word.u32[3] = first_word;
	    first_word ^= BIT0MASK(message >> 5);
	    word.setu32(2, first_word);//word.u32[2] = first_word;
	    return;
	}

	/**
	 * @brief Hadamard transform
	 *
	 * Perform hadamard transform of src and store result in dst
	 * src is overwritten
	 *
	 * @param[out] src Structure that contain the expanded codeword
	 * @param[out] dst Structure that contain the expanded codeword
	 */
	void hadamard(ExpandedCodeword src, ExpandedCodeword dst) {
	    // the passes move data:
	    // src -> dst -> src -> dst -> src -> dst -> src -> dst
	    // using p1 and p2 alternately
	    ExpandedCodeword p1 = src;
	    ExpandedCodeword p2 = dst;
	    
	    for (int pass = 0; pass < 7; pass++) {
	        for (int i = 0; i < 64; i++) {
	            p2.v[i] = (short) (p1.v[2 * i] + p1.v[2 * i + 1]);
	            p2.v[i + 64] = (short) (p1.v[2 * i] - p1.v[2 * i + 1]);
	        }
	        // swap p1, p2 for next round
	        ExpandedCodeword p3 = p1;
	        p1 = p2;
	        p2 = p3;
	    }
	}

	/**
	 * @brief Add multiple codewords into expanded codeword
	 *
	 * Accesses memory in order
	 * Note: this does not write the codewords as -1 or +1 as the green machine does
	 * instead, just 0 and 1 is used.
	 * The resulting hadamard transform has:
	 * all values are halved
	 * the first entry is 64 too high
	 *
	 * @param[out] dest Structure that contain the expanded codeword
	 * @param[in] src Structure that contain the codeword
	 */
	void expand_and_sum(ExpandedCodeword dest, Codeword src[]) {
	    // start with the first copy
	    for (int part = 0; part < 4; part++) {
	        for (int bit = 0; bit < 32; bit++) {
	            dest.v[part * 32 + bit] = (short) (src[0].u32[part] >>> bit & 1);
	        }
	    }
	    // sum the rest of the copies
	    for (int copy = 1; copy < MULTIPLICITY(); copy++) {
	        for (int part = 0; part < 4; part++) {
	            for (int bit = 0; bit < 32; bit++) {
	                dest.v[part * 32 + bit] += src[copy].u32[part] >>> bit & 1;
	            }
	        }
	    }
	}



	/**
	 * @brief Finding the location of the highest value
	 *
	 * This is the final step of the green machine: find the location of the highest value,
	 * and add 128 if the peak is positive
	 * if there are two identical peaks, the peak with smallest value
	 * in the lowest 7 bits it taken
	 * @param[in] transform Structure that contain the expanded codeword
	 */
	byte find_peaks(ExpandedCodeword transform) {
		int peak_abs_value = 0;
		int peak_value = 0;
		byte peak_pos = 0;
	    for (short i = 0; i < 128; i++) {
	        // get absolute value
	    	int t = transform.v[i];
	    	int pos_mask = -(t > 0? 1 : 0);//-(t > 0)
	    	int absolute = (pos_mask & t) | (~pos_mask & -t);
	        // all compilers nowadays compile with a conditional move
	        peak_value = absolute > peak_abs_value ? t : peak_value;
	        peak_pos = absolute > peak_abs_value ? (byte)(i & 0x00FF) : peak_pos;
	        peak_abs_value = absolute > peak_abs_value ? absolute : peak_abs_value;
	    }
	    // set bit 7
	    peak_pos |= 128 * (peak_value > 0 ? 1 : 0);//peak_pos |= 128 * (peak_value > 0);
	    return peak_pos;
	}



	/**
	 * @brief Encodes the received word
	 *
	 * The message consists of N1 bytes each byte is encoded into PARAM_N2 bits,
	 * or MULTIPLICITY repeats of 128 bits
	 *
	 * @param[out] cdw Array of size VEC_N1N2_SIZE_64 receiving the encoded message
	 * @param[in] msg Array of size VEC_N1_SIZE_64 storing the message
	 */
	void reed_muller_encode(long[] cdw, final long[] msg) {
	    byte[] message_array = new byte[parameters.VEC_N1_SIZE_64 * 8]; 
	    for(int i=0; i<message_array.length - (message_array.length % 8); i += 8){
	    	for(int j=0; j<8; j++) {
	    		message_array[i + j] = (byte) (msg[i / 8] >> (j * 8) & 0x00000000000000ffL); 
	    	}
	    }
	    for(int j=0; j<message_array.length % 8; j++) {
	    	int i = message_array.length / 8;
	    	message_array[i + j] = (byte) (msg[i / 8] >> (j * 8) & 0x00000000000000ffL);
	    }
	    
	    int j=0;
	    Codeword[] codeArray = new Codeword[MULTIPLICITY() * parameters.VEC_N1_SIZE_BYTES];//need modify
    
	    for (int i = 0; i < parameters.VEC_N1_SIZE_BYTES; i++) {
	    	// fill entries i * MULTIPLICITY to (i+1) * MULTIPLICITY
	        int pos = i * MULTIPLICITY();
	        codeArray[pos] = new Codeword();	        
	        
	        // encode first word
	        encode(codeArray[pos], message_array[i]);
	        
	        // copy to other identical codewords
	        for (int copy = 1; copy < MULTIPLICITY(); copy++) {
	        	codeArray[pos + copy] = new Codeword();
	        	copy(codeArray[pos], codeArray[pos + copy]); //memcpy(&codeArray[pos + copy], &codeArray[pos], sizeof(codeword));
	        }
	    }
	
	    for(int i=0; i < codeArray.length; i++) {
	    	cdw[i * 2] = (codeArray[i].u32[1] & 0x00000000FFFFFFFFL) << 32 | (codeArray[i].u32[0] & 0x00000000FFFFFFFFL);
	    	cdw[i * 2 + 1] =(codeArray[i].u32[3] & 0x00000000FFFFFFFFL) << 32 | (codeArray[i].u32[2] & 0x00000000FFFFFFFFL);
 	    }
	    
	    return;
	}



	/**
	 * @brief Decodes the received word
	 *
	 * Decoding uses fast hadamard transform, for a more complete picture on Reed-Muller decoding, see MacWilliams, Florence Jessie, and Neil James Alexander Sloane.
	 * The theory of error-correcting codes codes @cite macwilliams1977theory
	 *
	 * @param[out] msg Array of size VEC_N1_SIZE_64 receiving the decoded message
	 * @param[in] cdw Array of size VEC_N1N2_SIZE_64 storing the received word
	 */
	void reed_muller_decode(long[] msg, final long[] cdw) {
	    byte[] message_array = new byte[msg.length * 8];
	    
	    Codeword[] codeArray = new Codeword[MULTIPLICITY() * parameters.VEC_N1_SIZE_BYTES]; 
	    //parameters.VEC_N_SIZE_64
	    for(int i = 0; i<codeArray.length; i++) {
	    	codeArray[i] = new Codeword();
	    	codeArray[i].setu32(0, (int) (cdw[i * 2] & 0x00000000FFFFFFFFL));
	    	codeArray[i].setu32(1, (int) ((cdw[i * 2] >>> 32) & 0x00000000FFFFFFFFL));
	    	codeArray[i].setu32(2, (int) (cdw[i * 2 + 1]  & 0x00000000FFFFFFFFL));
	    	codeArray[i].setu32(3, (int) ((cdw[i * 2 + 1] >>> 32) & 0x00000000FFFFFFFFL));	
	    }
	    	    
	    ExpandedCodeword expanded = new ExpandedCodeword();
	    Codeword[] tmp = new Codeword[MULTIPLICITY()];
	    tmp[0] = new Codeword();
	    tmp[1]= new Codeword();
    	tmp[2] = new Codeword();
    	
	    for (int i = 0; i < parameters.VEC_N1_SIZE_BYTES; i++) {	
	    	
	    	copy(codeArray[i * MULTIPLICITY()], tmp[0]);
	    	copy(codeArray[i * MULTIPLICITY() + 1], tmp[1]);
	    	copy(codeArray[i * MULTIPLICITY() + 2], tmp[2]);
	    	
	        // collect the codewords
	        expand_and_sum(expanded, tmp);
	        
	        copy(tmp[0], codeArray[i * MULTIPLICITY()]);
	    	copy(tmp[1], codeArray[i * MULTIPLICITY() + 1]);
	    	copy(tmp[2], codeArray[i * MULTIPLICITY() + 2]);
	        
	        // apply hadamard transform
	        ExpandedCodeword transform = new ExpandedCodeword();
	        hadamard(expanded, transform);
	        
	        // fix the first entry to get the half Hadamard transform
	        transform.v[0] -= 64 * MULTIPLICITY();
	        
	        // finish the decoding
	        message_array[i] = find_peaks(transform);
	    }
	    
	    for (int i = 0; i < message_array.length / 8; i++) {
			for (int j = 7; j >= 0; j--) {
				msg[i] <<= 8;
				msg[i] ^= ((long) message_array[(i * 8 + j)] & 0x00000000000000ffL);
			}
		}		
		for (int j = 0; j < message_array.length  % 8; j++) {
			int i = message_array.length  / 8;
			msg[i] ^= (long) ((message_array[(i * 8 + j)] & 0x00000000000000ffL) << (j * 8));
		}	    
	}
}
