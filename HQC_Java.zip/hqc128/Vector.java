package hqc128;

public class Vector {
	Parameters parameters = new Parameters();
	Shake_prng shake_prng = new Shake_prng();
	Pri pri = new Pri();

	static int compare_u32(final int v1, final int v2) {
		return (1 ^ (((v1 - v2) | (v2 - v1)) >>> 31));
	}

	/**
	 * @brief Generates a vector of a given Hamming weight
	 *
	 *        Implementation of Algorithm 5 in https://eprint.iacr.org/2021/1631.pdf
	 *
	 * @param[in] ctx Pointer to the context of the seed expander
	 * @param[in] v Pointer to an array
	 * @param[in] weight Integer that is the Hamming weight
	 */
	void vect_set_random_fixed_weight(Seedexpander_state ctx, long[] v, short weight) {
		int[] rand_u32 = new int[parameters.PARAM_OMEGA_R];
		int[] support = new int[parameters.PARAM_OMEGA_R];
		int[] index_tab = new int[parameters.PARAM_OMEGA_R];
		long[] bit_tab = new long[parameters.PARAM_OMEGA_R];
		byte[] temp = new byte[rand_u32.length * 4];
		
		shake_prng.seedexpander(ctx, temp, 4 * weight);
		//pri.longHexPri("ctx=", ctx.ctx);
		//pri.byteHexPri("temp=", temp);
		for (int i = 0; i < rand_u32.length; i++) {
			for (int j = 3; j >= 0; j--) {
				rand_u32[i] <<= 8;
				rand_u32[i] ^= (int) (temp[i * 4 + j] & 0x000000ff);
			}
		}
		//pri.intHexPri("rand_u32=", rand_u32);

		for (int i = 0; i < weight; ++i) {
			// support[i] = (i + rand_u32[i]) % (parameters.PARAM_N - i);
			/*long dividend = i + rand_u32[i] & 0x00000000FFFFFFFFL;
			long divisor = (parameters.PARAM_N - i);
			support[i] = (int)((dividend % divisor) & 0x00000000FFFFFFFFL);
			*/
			long dividend = rand_u32[i] & 0x00000000FFFFFFFFL;
			long divisor = (parameters.PARAM_N - i);
			support[i] = i + (int)((dividend % divisor) & 0x00000000FFFFFFFFL);
			
			//System.out.println(String.format("%d %08x %d(%08x) %d(%08x) %d(%08x)", i, (rand_u32[i]& 0x00000000FFFFFFFFL), dividend, dividend, divisor, divisor, support[i], support[i]));
		}
		//pri.intHexPri("support1=", support);
		
		for (int i = (weight - 1); i-- > 0;) {
			int found = 0;

			for (int j = i + 1; j < weight; ++j) {
				found |= compare_u32(support[j], support[i]);
			}

			int mask = -found;
			support[i] = (mask & i) ^ (~mask & support[i]);
		}
		//pri.intHexPri("support2=", support);

		for (int i = 0; i < weight; i++) {
			index_tab[i] = support[i] >>> 6;
			int pos = support[i] & 0x0000003f;
			bit_tab[i] = ((long) 1 & 0x000000000000000FL) << pos;
		}
		//pri.intHexPri("index_tab=", index_tab);
		//pri.longHexPri("bit_tab=", bit_tab);

		long val = 0;
		for (int i = 0; i < parameters.VEC_N_SIZE_64; i++) {
			val = 0;
			for (int j = 0; j < weight; j++) {
				int tmp = i - index_tab[j];
				int val1 = 1 ^ ((tmp | -tmp) >>> 31);
				long mask = -val1;
				val |= (bit_tab[j] & mask);
			}
			v[i] |= val;
		}
	}

	void vect_set_random(Seedexpander_state ctx, long[] v) {
		byte rand_bytes[] = new byte[parameters.VEC_N_SIZE_BYTES];

		shake_prng.seedexpander(ctx, rand_bytes, parameters.VEC_N_SIZE_BYTES);

		// memcpy(v, rand_bytes, VEC_N_SIZE_BYTES);
		for (int i = 0; i < parameters.VEC_N_SIZE_BYTES / 8; i++) {
			v[i] = 0x0000000000000000L;
			for (int j = 7; j >= 0; j--) {
				v[i] <<= 8;
				v[i] ^= ((long) rand_bytes[i * 8 + j] & 0x00000000000000ff);
			}
		}
		for (int j = (parameters.VEC_N_SIZE_BYTES % 8 - 1); j >= 0; j--) {
			int i = parameters.VEC_N_SIZE_BYTES / 8;
			v[i] <<= 8;
			v[i] ^= ((long) rand_bytes[i * 8 + j] & 0x00000000000000ffL);
		}

		v[parameters.VEC_N_SIZE_64 - 1] &= parameters.BITMASK(parameters.PARAM_N, 64);
	}

	void vect_set_random_from_prng(long[] v, int size_v) {
		byte[] rand_bytes = new byte[32]; // set to the maximum possible size - 256 bits

		shake_prng.shake_prng(rand_bytes, size_v << 3);
		// memcpy(v, rand_bytes, size_v << 3);
		for (int i = 0; i < v.length; i++) {
			v[i] = rand_bytes[i * 8 + 0] & 0x00000000000000FFL;
			v[i] ^= (rand_bytes[i * 8 + 1] & 0x00000000000000FFL) << 8;
			v[i] ^= (rand_bytes[i * 8 + 2] & 0x00000000000000FFL) << 16;
			v[i] ^= (rand_bytes[i * 8 + 3] & 0x00000000000000FFL) << 24;
			v[i] ^= (rand_bytes[i * 8 + 4] & 0x00000000000000FFL) << 32;
			v[i] ^= (rand_bytes[i * 8 + 5] & 0x00000000000000FFL) << 40;
			v[i] ^= (rand_bytes[i * 8 + 6] & 0x00000000000000FFL) << 48;
			v[i] ^= (rand_bytes[i * 8 + 7] & 0x00000000000000FFL) << 56;
		}		
	}

	void vect_add(long[] o, final long[] v1, final long[] v2, int size) {
		for (int i = 0; i < size; ++i) {
			o[i] = v1[i] ^ v2[i];
		}
	}

	byte vect_compare(final byte[] v1, final byte[] v2, int size) {
		long r = 0;

		for (int i = 0; i < size; i++) {
			r |= v1[i] ^ v2[i];
		}

		r = (~r + 1) >>> 63;
		return (byte) r;
	}

	void vect_resize(long[] o, int size_o, final long[] v, int size_v) {
		long mask = 0x7FFFFFFFFFFFFFFFL;
		short val = 0;
		if (size_o < size_v) {

			if ((size_o % 64) != 0) {
				val = (short) (64 - (size_o % 64));
			}

			// memcpy(o, v, VEC_N1N2_SIZE_BYTES);
			System.arraycopy(v, 0, o, 0, parameters.VEC_N1N2_SIZE_BYTES/8);
			//pri.longHexPri("o=", o);
			
			for (byte i = 0; i < val; ++i) {
				o[parameters.VEC_N1N2_SIZE_64 - 1] &= (mask >>> i);
			}
			
		} else {
			// memcpy(o, v, CEIL_DIVIDE(size_v, 8));
			System.arraycopy(v, 0, o, 0, parameters.CEIL_DIVIDE(size_v, 64));
		}
	}

	void vect_print(final long[] v, final int size) {
		if (size == parameters.VEC_K_SIZE_BYTES) {
			byte[] tmp = new byte[parameters.VEC_K_SIZE_BYTES];
			// memcpy(tmp, v, VEC_K_SIZE_BYTES);
			for (int i = 0; i < v.length; i++) {
				for (int j = 0; j < 8; j++)
					tmp[i * 8 + j] = (byte) ((v[i] >>> (j * 8)) & 0x00000000000000ffL);
			}

			for (int i = 0; i < parameters.VEC_K_SIZE_BYTES; ++i) {
				System.out.print(String.format("%02x", tmp[i]));
			}
		} else if (size == parameters.VEC_N_SIZE_BYTES) {
			byte[] tmp = new byte[parameters.VEC_N_SIZE_BYTES];
			// memcpy(tmp, v, VEC_N_SIZE_BYTES);
			for (int i = 0; i < v.length; i++) {
				for (int j = 0; j < 8; j++)
					tmp[i * 8 + j] = (byte) ((v[i] >>> (j * 8)) & 0x00000000000000ffL);
			}

			for (int i = 0; i < parameters.VEC_N_SIZE_BYTES; ++i) {
				System.out.print(String.format("%02x", tmp[i]));
			}
		} else if (size == parameters.VEC_N1N2_SIZE_BYTES) {
			byte[] tmp = new byte[parameters.VEC_N1N2_SIZE_BYTES];
			// memcpy(tmp, v, VEC_N1N2_SIZE_BYTES);
			for (int i = 0; i < v.length; i++) {
				for (int j = 0; j < 8; j++)
					tmp[i * 8 + j] = (byte) ((v[i] >>> (j * 8)) & 0x00000000000000ffL);
			}

			for (int i = 0; i < parameters.VEC_N1N2_SIZE_BYTES; ++i) {
				System.out.print(String.format("%02x", tmp[i]));
			}
		} else if (size == parameters.VEC_N1_SIZE_BYTES) {
			byte[] tmp = new byte[parameters.VEC_N1_SIZE_BYTES];
			// memcpy(tmp, v, VEC_N1_SIZE_BYTES);
			for (int i = 0; i < v.length; i++) {
				for (int j = 0; j < 8; j++)
					tmp[i * 8 + j] = (byte) ((v[i] >>> (j * 8)) & 0x00000000000000ffL);
			}

			for (int i = 0; i < parameters.VEC_N1_SIZE_BYTES; ++i) {
				System.out.print(String.format("%02x", tmp[i]));
			}
		}
	}

	void vect_print_sparse(final int[] v, final short weight) {
		for (short i = 0; i < weight - 1; ++i) {
			System.out.print(v[i] + ", ");
		}
		System.out.print(v[weight - 1]);
	}
}
