package hqc128;

public class Domains {

	public final byte PRNG_DOMAIN = 1;
	public final byte SEEDEXPANDER_DOMAIN = 2;
	public final byte G_FCT_DOMAIN = 3;
	public final byte H_FCT_DOMAIN = 4;
	public final byte K_FCT_DOMAIN = 5;

}