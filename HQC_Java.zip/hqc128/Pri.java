package hqc128;

public class Pri {
	static String stringToHex(final String string) {
		String result = "";
		// TODO Auto-generated method stub
		for(int i=0; i < string.length(); i++) {
			result += String.format("%02x", (int)string.charAt(i));
		}				
		return result;
	}
	
	static char[] hexToChar(final String hex) {
		char[] arr;
		if(hex.length()%2!=0) {
			System.err.println("Invlid hex string.");
			return null;
		}
		arr = new char[hex.length()/2];
		
		for (int i = 0; i < hex.length(); i = i + 2) {
			// Step-1 Split the hex string into two character group
			String s = hex.substring(i, i + 2);
			
			// Step-2 Convert the each character group into integer using valueOf method
			int n = Integer.valueOf(s, 16);
	        
			// Step-3 Cast the integer value to char
			arr[i/2] = (char)n;
	    }
		
		return arr;		
	}
	
	static String byteToHex(final byte[] arr) {
		String str = "";
		for(int i=0; i<arr.length; i++)
			str += String.format("%02x", arr[i]);
		return str;
	}
	
	static byte[] hexToByte(final String hex) {
		byte[] arr;
		if(hex.length()%2!=0) {
			System.err.println("Invlid hex string.");
			return null;
		}
		arr = new byte[hex.length()/2];
		
		for (int i = 0; i < hex.length(); i = i + 2) {
			// Step-1 Split the hex string into two character group
			String s = hex.substring(i, i + 2);
			
			// Step-2 Convert the each character group into integer using valueOf method
			byte n = (byte)((Character.digit(s.charAt(0), 16) << 4) + Character.digit(s.charAt(1), 16));		
	        
			// Step-3 Cast the integer value to char
			arr[i/2] = n;
	    }
		
		return arr;		
	}
	
	void byteHexPri(String title, final byte[] arr) {
		System.out.print(title);
		
		if(arr == null) {
			System.out.println("null");
			return;
		}
		
		for(int i=0; i<arr.length; i++) {
			System.out.print(String.format("%02x", arr[i]) + " ");	
		}
		System.out.println();
	}
	
	void shortHexPri(final String title, final short[] arr) {		
		System.out.print(title);
		
		if(arr == null) {
			System.out.println("null");
			return;
		}
		
		for(int i=0; i<arr.length; i++) {
			System.out.print(String.format("%04x", arr[i]) + " ");	
		}
		System.out.println();			
	}
	
	void charHexPri(final String title, final char[] arr) {
		System.out.print(title);
		
		if(arr == null) {
			System.out.println("null");
			return;
		}
		
		for(int i=0; i<arr.length; i++) {
			System.out.print(String.format("%04x", arr[i]) + " ");	
		}
		System.out.println();	
	}
	
	void intHexPri(final String title, final int[] arr) {
		System.out.print(title);
		
		if(arr == null) {
			System.out.println("null");
			return;
		}
		
		for(int i=0; i<arr.length; i++) {
			System.out.print(String.format("%08x", arr[i]) + " ");	
		}
		System.out.println();	
	}
	
	void longHexPri(final String title, final long[] arr) {
		System.out.print(title);
		
		if(arr == null) {
			System.out.println("null");
			return;
		}	
		
		for (int i = 0; i < arr.length; i++) {
			String str = String.format("%016x", arr[i]);
			System.out.print(str + " ");			
		}
		System.out.println();		
	}	
}