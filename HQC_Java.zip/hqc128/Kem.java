package hqc128;

public class Kem {

	Hqc hqc = new Hqc();
	Parameters parameters = new Parameters();
	Vector vector = new Vector();
	Shake_ds shake_ds = new Shake_ds();
	Domains domains = new Domains();
	Parsing parsing = new Parsing();
	Pri pri = new Pri();
	Api api = new Api();
	
	int crypto_kem_keypair(byte[] pk, byte[] sk) {
		if (parameters.VERBOSE) {
			System.out.println();
			System.out.println();
			System.out.println("### KEYGEN ###");
		}

		hqc.hqc_pke_keygen(pk, sk);
		return 0;
	}

	int crypto_kem_enc(byte[] ct, byte[] ss, final byte[] pk) {
		if(parameters.VERBOSE) {
	    	System.out.println();
	    	System.out.println();
	        System.out.println("### ENCAPS ###");
	    }

	    byte[] theta = new byte[parameters.SHAKE256_512_BYTES];
	    long[] m     = new long[parameters.VEC_K_SIZE_64];
	    long[] u     = new long[parameters.VEC_N_SIZE_64];
	    long[] v     = new long[parameters.VEC_N1N2_SIZE_64];
	    byte[] d     = new byte[parameters.SHAKE256_512_BYTES];
	    byte[] mc    = new byte[parameters.VEC_K_SIZE_BYTES + parameters.VEC_N_SIZE_BYTES + parameters.VEC_N1N2_SIZE_BYTES];
	    long[] salt  = new long[parameters.SALT_SIZE_64];
	    byte[] tmp   = new byte[parameters.VEC_K_SIZE_BYTES + parameters.SEED_BYTES + parameters.SALT_SIZE_BYTES];
	    Shake256incctx shake256state = new Shake256incctx();

	    // Computing m
	    vector.vect_set_random_from_prng(m, parameters.VEC_K_SIZE_64);

	    // Computing theta
	    vector.vect_set_random_from_prng(salt, parameters.SALT_SIZE_64);	    
	    
	    for (int i = 0; i < parameters.VEC_K_SIZE_64; i++) {
			for (int j = 0; j < 8; j++)
				tmp[i * 8 + j] = (byte) ((m[i] >>> (j * 8)) & 0x00000000000000ffL);
		}	    
	    System.arraycopy(pk, 0, tmp, parameters.VEC_K_SIZE_BYTES, parameters.SEED_BYTES);//memcpy(tmp + VEC_K_SIZE_BYTES, pk, SEED_BYTES);
	    
	    
	    for (int i = 0; i < parameters.SALT_SIZE_64; i++) {
			for (int j = 0; j < 8; j++)
				tmp[parameters.VEC_K_SIZE_BYTES + parameters.SEED_BYTES + i * 8 + j] = (byte) ((salt[i] >>> (j * 8)) & 0x00000000000000ffL);
		}	   	    
	    shake_ds.shake256_512_ds(shake256state, theta, tmp, parameters.VEC_K_SIZE_BYTES + parameters.SEED_BYTES + parameters.SALT_SIZE_BYTES, domains.G_FCT_DOMAIN);
	    	    
	    // Encrypting m
	    hqc.hqc_pke_encrypt(u, v, m, theta, pk);
	    
	    // Computing d	    
	    byte[] temp = new byte[m.length * 8];
	    for (int i = 0; i < parameters.VEC_K_SIZE_64; i++) {
			for (int j = 0; j < 8; j++)
				temp[i * 8 + j] = (byte) ((m[i] >>> (j * 8)) & 0x00000000000000ffL);
		}        
	    shake_ds.shake256_512_ds(shake256state, d, temp, parameters.VEC_K_SIZE_BYTES, domains.H_FCT_DOMAIN);
	    
	    // Computing shared secret
	    for (int i = 0; i < parameters.VEC_K_SIZE_64; i++) {
			for (int j = 0; j < 8; j++)
				mc[i * 8 + j] = (byte) ((m[i] >>> (j * 8)) & 0x00000000000000ffL);
		}
	    
	    for (int i = 0; i < parameters.VEC_N_SIZE_64; i++) {
			for (int j = 0; j < 8; j++)
				mc[parameters.VEC_K_SIZE_BYTES + (i * 8 + j)] = (byte) ((u[i] >>> (j * 8)) & 0x00000000000000ffL);
		}
	    
	    for (int i = 0; i < parameters.VEC_N1N2_SIZE_64; i++) {
			for (int j = 0; j < 8; j++)
				mc[parameters.VEC_K_SIZE_BYTES + parameters.VEC_N_SIZE_BYTES + (i * 8 + j)] = (byte) ((v[i] >>> (j * 8)) & 0x00000000000000ffL);
		}
	    
	    shake_ds.shake256_512_ds(shake256state, ss, mc, parameters.VEC_K_SIZE_BYTES + parameters.VEC_N_SIZE_BYTES + parameters.VEC_N1N2_SIZE_BYTES, domains.K_FCT_DOMAIN);
	    
	    // Computing ciphertext
	    parsing.hqc_ciphertext_to_string(ct, u, v, d, salt);
	    
	    if (parameters.VERBOSE) {
	    	System.out.println("\n\npk: "); for(int i = 0 ; i < parameters.PUBLIC_KEY_BYTES ; ++i) System.out.print(String.format("%02x", pk[i]));
	    	System.out.println("\n\nm: "); vector.vect_print(m, parameters.VEC_K_SIZE_BYTES);
	    	System.out.println("\n\ntheta: "); for(int i = 0 ; i < parameters.SHAKE256_512_BYTES ; ++i) System.out.print(String.format("%02x", theta[i]));
	    	System.out.println("\n\nd: "); for(int i = 0 ; i < parameters.SHAKE256_512_BYTES ; ++i) System.out.print(String.format("%02x", d[i]));
	    	System.out.println("\n\nciphertext: "); for(int i = 0 ; i < parameters.CIPHERTEXT_BYTES ; ++i) System.out.print(String.format("%02x", ct[i]));
	        System.out.println("\n\nsecret 1: "); for(int i = 0 ; i < parameters.SHARED_SECRET_BYTES ; ++i) System.out.print(String.format("%02x", ss[i]));
	    }

	    return 0;
	}
	
	
	/**
	 * @brief Decapsulation of the HQC_KEM IND_CAA2 scheme
	 *
	 * @param[out] ss String containing the shared secret
	 * @param[in] ct String containing the cipĥertext
	 * @param[in] sk String containing the secret key
	 * @returns 0 if decapsulation is successful, -1 otherwise
	 */
	int crypto_kem_dec(byte[] ss, final byte[] ct, final byte[] sk) {
		if (parameters.VERBOSE) {
			System.out.println("\n\n\n\n### DECAPS ###");
		}

	    byte result;
	    long[] u = new long[parameters.VEC_N_SIZE_64];
	    long[] v = new long[parameters.VEC_N1N2_SIZE_64];
	    byte[] d = new byte[parameters.SHAKE256_512_BYTES];
	    byte[] pk = new byte[parameters.PUBLIC_KEY_BYTES];
	    long[] m = new long[parameters.VEC_K_SIZE_64];
	    byte[] theta = new byte[parameters.SHAKE256_512_BYTES];
	    long[] u2 = new long[parameters.VEC_N_SIZE_64];
	    long[] v2 = new long[parameters.VEC_N1N2_SIZE_64];
	    byte[] d2 = new byte[parameters.SHAKE256_512_BYTES];
	    byte[] mc = new byte[parameters.VEC_K_SIZE_BYTES + parameters.VEC_N_SIZE_BYTES + parameters.VEC_N1N2_SIZE_BYTES];
	    long[] salt = new long[parameters.SALT_SIZE_64];
	    byte[] tmp = new byte[parameters.VEC_K_SIZE_BYTES + parameters.SALT_SIZE_BYTES + parameters.SEED_BYTES];
	    Shake256incctx shake256state = new Shake256incctx();
    
	    // Retrieving u, v and d from ciphertext
	    parsing.hqc_ciphertext_from_string(u, v, d, salt, ct);
	    //pri.longHexPri("u=", u);
	    //pri.longHexPri("v=", v);
	    //pri.byteHexPri("d=", d);
	    //pri.longHexPri("salt=", salt);
	    
	    // Retrieving pk from sk
	    //memcpy(pk, sk + SEED_BYTES, PUBLIC_KEY_BYTES);
	    System.arraycopy(sk, parameters.SEED_BYTES, pk, 0, api.CRYPTO_PUBLICKEYBYTES);

	    // Decryting	    
	    hqc.hqc_pke_decrypt(m, u, v, sk);
	    //pri.longHexPri("u=", u);
	    //pri.longHexPri("v=", v);
	    //pri.longHexPri("m=", m);
	    
	    // Computing theta
	    //memcpy(tmp, m, VEC_K_SIZE_BYTES);
	    for (int i = 0; i < parameters.VEC_K_SIZE_BYTES / 8; i++) {
			for (int j = 0; j < 8; j++)
				tmp[(i * 8 + j)] = (byte) ((m[i] >>> (j * 8)) & 0x00000000000000ffL);
		}
	    for (int j = 0; j < parameters.VEC_K_SIZE_BYTES % 8; j++) {
			int i = parameters.VEC_K_SIZE_BYTES / 8;
			tmp[(i * 8 + j)] = (byte) ((m[i] >>> (j * 8)) & 0x00000000000000ffL);
		}	    
	    System.arraycopy(pk, 0, tmp, parameters.VEC_K_SIZE_BYTES, parameters.SEED_BYTES);//memcpy(tmp + VEC_K_SIZE_BYTES, pk, SEED_BYTES);
	   
	    //memcpy(tmp + VEC_K_SIZE_BYTES + SEED_BYTES, salt, SALT_SIZE_BYTES);
	    for (int i = 0; i < parameters.SALT_SIZE_BYTES / 8; i++) {
			for (int j = 0; j < 8; j++)
				tmp[(i * 8 + j) + parameters.VEC_K_SIZE_BYTES + parameters.SEED_BYTES] = (byte) ((salt[i] >>> (j * 8)) & 0x00000000000000ffL);
		}
	    for (int j = 0; j < parameters.SALT_SIZE_BYTES % 8; j++) {
			int i = parameters.SALT_SIZE_BYTES / 8;
			tmp[(i * 8 + j) + parameters.VEC_K_SIZE_BYTES + parameters.SEED_BYTES] = (byte) ((salt[i] >>> (j * 8)) & 0x00000000000000ffL);
		}
	    shake_ds.shake256_512_ds(shake256state, theta, tmp, parameters.VEC_K_SIZE_BYTES + parameters.SEED_BYTES + parameters.SALT_SIZE_BYTES, domains.G_FCT_DOMAIN);
	    	    
	    // Encrypting m'	    
	    hqc.hqc_pke_encrypt(u2, v2, m, theta, pk);

	    // Computing d'
	    byte[] temp = new byte[m.length * 8];
	    for (int i = 0; i < parameters.VEC_K_SIZE_64; i++) {
			for (int j = 0; j < 8; j++)
				temp[i * 8 + j] = (byte) ((m[i] >>> (j * 8)) & 0x00000000000000ffL);
		}	
	    shake_ds.shake256_512_ds(shake256state, d2, temp, parameters.VEC_K_SIZE_BYTES, domains.H_FCT_DOMAIN);

	    // Computing shared secret
	    //memcpy(mc, m, VEC_K_SIZE_BYTES);
	    for (int i = 0; i < parameters.VEC_K_SIZE_64; i++) {
			for (int j = 0; j < 8; j++)
				mc[(i * 8 + j)] = (byte) ((m[i] >>> (j * 8)) & 0x00000000000000ffL);
		}	    
	    //memcpy(mc + VEC_K_SIZE_BYTES, u, VEC_N_SIZE_BYTES);
	    for (int i = 0; i < parameters.VEC_N_SIZE_64; i++) {
			for (int j = 0; j < 8; j++)
				mc[(i * 8 + j) + parameters.VEC_K_SIZE_BYTES] = (byte) ((u[i] >>> (j * 8)) & 0x00000000000000ffL);
		}
	    
	    //memcpy(mc + VEC_K_SIZE_BYTES + VEC_N_SIZE_BYTES, v, VEC_N1N2_SIZE_BYTES);
	    for (int i = 0; i < parameters.VEC_N1N2_SIZE_64; i++) {
			for (int j = 0; j < 8; j++)
				mc[(i * 8 + j) + parameters.VEC_K_SIZE_BYTES + parameters.VEC_N_SIZE_BYTES ] = (byte) ((v[i] >>> (j * 8)) & 0x00000000000000ffL);
		}
	    shake_ds.shake256_512_ds(shake256state, ss, mc, parameters.VEC_K_SIZE_BYTES + parameters.VEC_N_SIZE_BYTES + parameters.VEC_N1N2_SIZE_BYTES, domains.K_FCT_DOMAIN);

	    // Abort if c != c' or d != d'
	    byte[] tmpu = new byte[parameters.VEC_N_SIZE_64 * 8];
	    byte[] tmpu2 = new byte[parameters.VEC_N_SIZE_64 * 8];
	    for (int i = 0; i < parameters.VEC_N_SIZE_64; i++) {
			for (int j = 0; j < 8; j++) {
				tmpu[i * 8 + j] = (byte) ((u[i] >>> (j * 8)) & 0x00000000000000ffL);
				tmpu2[i * 8 + j] = (byte) ((u2[i] >>> (j * 8)) & 0x00000000000000ffL);
			}
		}	    
	    result = vector.vect_compare(tmpu, tmpu2, parameters.VEC_N_SIZE_BYTES);
	    
	    byte[] tmpv = new byte[parameters.VEC_N1N2_SIZE_64 * 8];
	    byte[] tmpv2 = new byte[parameters.VEC_N1N2_SIZE_64 * 8];
	    for (int i = 0; i < parameters.VEC_N1N2_SIZE_64; i++) {
			for (int j = 0; j < 8; j++) {
				tmpv[i * 8 + j] = (byte) ((v[i] >>> (j * 8)) & 0x00000000000000ffL);
				tmpv2[i * 8 + j] = (byte) ((v2[i] >>> (j * 8)) & 0x00000000000000ffL);
			}
		}
	    result |= vector.vect_compare(tmpv, tmpv2, parameters.VEC_N1N2_SIZE_BYTES);
	    result |= vector.vect_compare(d, d2, parameters.SHAKE256_512_BYTES);

	    result = (byte) (-((short) result) >> 15);

	    for (int i = 0 ; i < parameters.SHARED_SECRET_BYTES ; i++) {
	        ss[i] &= ~result;
	    }

	    if (parameters.VERBOSE) {
	    	System.out.println("\n\npk: "); for(int i = 0 ; i < parameters.PUBLIC_KEY_BYTES ; ++i) System.out.print(String.format("%02x", pk[i]));
	    	System.out.println("\n\nsk: "); for(int i = 0 ; i < parameters.SECRET_KEY_BYTES ; ++i) System.out.print(String.format("%02x", sk[i]));
	    	System.out.println("\n\nciphertext: "); for(int i = 0 ; i < parameters.CIPHERTEXT_BYTES ; ++i) System.out.print(String.format("%02x", ct[i]));
	    	System.out.println("\n\nm: "); vector.vect_print(m, parameters.VEC_K_SIZE_BYTES);
	    	System.out.println("\n\ntheta: "); for(int i = 0 ; i < parameters.SHAKE256_512_BYTES ; ++i) System.out.print(String.format("%02x", theta[i]));
	    	System.out.println("\n\n\n# Checking Ciphertext- Begin #");
	    	System.out.println("\n\nu2: "); vector.vect_print(u2, parameters.VEC_N_SIZE_BYTES);
	    	System.out.println("\n\nv2: "); vector.vect_print(v2, parameters.VEC_N1N2_SIZE_BYTES);
	    	System.out.println("\n\nd2: "); for(int i = 0 ; i < parameters.SHAKE256_512_BYTES ; ++i) System.out.print(String.format("%02x", d2[i]));
	    	System.out.println("\n\n# Checking Ciphertext - End #\n");
	    }

	    return -(result & 1);
	}
}
