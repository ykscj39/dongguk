package hqc128;

public class Hqc {
	Parameters parameters = new Parameters();
	Shake_prng shake_prng = new Shake_prng();
	Vector vector = new Vector();
	Gf2x gf2x = new Gf2x();
	Parsing parsing = new Parsing();
	Pri pri = new Pri();
	Code code = new Code();

	void hqc_pke_keygen(byte[] pk, byte[] sk) {
		Seedexpander_state sk_seedexpander = new Seedexpander_state();
		Seedexpander_state pk_seedexpander = new Seedexpander_state();

		byte[] sk_seed = new byte[parameters.SEED_BYTES];
		byte[] pk_seed = new byte[parameters.SEED_BYTES];
		long[] x = new long[parameters.VEC_N_SIZE_64];
		long[] y = new long[parameters.VEC_N_SIZE_64];
		long[] h = new long[parameters.VEC_N_SIZE_64];
		long[] s = new long[parameters.VEC_N_SIZE_64];

		// Create seed_expanders for public key and secret key
		shake_prng.shake_prng(sk_seed, parameters.SEED_BYTES);
		shake_prng.seedexpander_init(sk_seedexpander, sk_seed, parameters.SEED_BYTES);

		shake_prng.shake_prng(pk_seed, parameters.SEED_BYTES);
		shake_prng.seedexpander_init(pk_seedexpander, pk_seed, parameters.SEED_BYTES);

		// Compute secret key
		vector.vect_set_random_fixed_weight(sk_seedexpander, x, parameters.PARAM_OMEGA);
		vector.vect_set_random_fixed_weight(sk_seedexpander, y, parameters.PARAM_OMEGA);

		// Compute public key
		vector.vect_set_random(pk_seedexpander, h);

		gf2x.vect_mul(s, y, h);
		vector.vect_add(s, x, s, parameters.VEC_N_SIZE_64);

		// Parse keys to string
		parsing.hqc_public_key_to_string(pk, pk_seed, s);
		parsing.hqc_secret_key_to_string(sk, sk_seed, pk);

		if (parameters.VERBOSE) {
			System.out.print("\n\nsk_seed: ");
			for (int i = 0; i < parameters.SEED_BYTES; ++i)
				System.out.print(String.format("%02x", sk_seed[i]));
			System.out.print("\n\nx: ");
			vector.vect_print(x, parameters.VEC_N_SIZE_BYTES);
			System.out.print("\n\ny: ");
			vector.vect_print(y, parameters.VEC_N_SIZE_BYTES);

			System.out.print("\n\npk_seed: ");
			for (int i = 0; i < parameters.SEED_BYTES; ++i)
				System.out.print(String.format("%02x", pk_seed[i]));
			System.out.print("\n\nh: ");
			vector.vect_print(h, parameters.VEC_N_SIZE_BYTES);
			System.out.print("\n\ns: ");
			vector.vect_print(s, parameters.VEC_N_SIZE_BYTES);

			System.out.print("\n\nsk: ");
			for (int i = 0; i < parameters.SECRET_KEY_BYTES; ++i)
				System.out.print(String.format("%02x", sk[i]));
			System.out.print("\n\npk: ");
			for (int i = 0; i < parameters.PUBLIC_KEY_BYTES; ++i)
				System.out.print(String.format("%02x", pk[i]));
		}
	}

	void hqc_pke_encrypt(long[] u, long[] v, long[] m, byte[] theta, final byte[] pk) {
		Seedexpander_state seedexpander = new Seedexpander_state();
		long[] h = new long[parameters.VEC_N_SIZE_64];
		long[] s = new long[parameters.VEC_N_SIZE_64];
		long[] r1 = new long[parameters.VEC_N_SIZE_64];
		long[] r2 = new long[parameters.VEC_N_SIZE_64];
		long[] e = new long[parameters.VEC_N_SIZE_64];
		long[] tmp1 = new long[parameters.VEC_N_SIZE_64];
		long[] tmp2 = new long[parameters.VEC_N_SIZE_64];
		
		//pri.longHexPri("ctx=", seedexpander.ctx);
		//pri.byteHexPri("theta=", theta);
		// Create seed_expander from theta
		shake_prng.seedexpander_init(seedexpander, theta, parameters.SEED_BYTES);
		//pri.longHexPri("ctx=", seedexpander.ctx);
		
		// Retrieve h and s from public key
		parsing.hqc_public_key_from_string(h, s, pk);		
		
		// Generate r1, r2 and e
		vector.vect_set_random_fixed_weight(seedexpander, r1, parameters.PARAM_OMEGA_R);
		vector.vect_set_random_fixed_weight(seedexpander, r2, parameters.PARAM_OMEGA_R);
		//System.out.println("check error");
		vector.vect_set_random_fixed_weight(seedexpander, e, parameters.PARAM_OMEGA_E);
		//pri.longHexPri("h=", h);
		//pri.longHexPri("s=", s);
		//pri.byteHexPri("theta=", theta);
		//pri.longHexPri("r1=", r1);
		//pri.longHexPri("r2=", r2);
		//pri.longHexPri("e=", e);
		//pri.longHexPri("ctx=", seedexpander.ctx);
		
		// Compute u = r1 + r2.h
		//System.out.println("u gf2x======>");
		gf2x.vect_mul(u, r2, h);
		//pri.longHexPri("u=", u);
		vector.vect_add(u, r1, u, parameters.VEC_N_SIZE_64);		
						
		// Compute v = m.G by encoding the message
		code.code_encode(v, m);
		vector.vect_resize(tmp1, parameters.PARAM_N, v, parameters.PARAM_N1N2);

		// Compute v = m.G + s.r2 + e
		gf2x.vect_mul(tmp2, r2, s);
		vector.vect_add(tmp2, e, tmp2, parameters.VEC_N_SIZE_64);
		vector.vect_add(tmp2, tmp1, tmp2, parameters.VEC_N_SIZE_64);
		vector.vect_resize(v, parameters.PARAM_N1N2, tmp2, parameters.PARAM_N);

		if (parameters.VERBOSE) {
			System.out.println("\n\nh: "); vector.vect_print(h, parameters.VEC_N_SIZE_BYTES); 
			System.out.println("\n\ns: "); vector.vect_print(s, parameters.VEC_N_SIZE_BYTES);
			System.out.println("\n\nr1: ");	vector.vect_print(r1, parameters.VEC_N_SIZE_BYTES);	
			System.out.println("\n\nr2: "); vector.vect_print(r2, parameters.VEC_N_SIZE_BYTES);	
			System.out.println("\n\ne: "); vector.vect_print(e, parameters.VEC_N_SIZE_BYTES);	
			System.out.println("\n\ntmp2: "); vector.vect_print(tmp2, parameters.VEC_N_SIZE_BYTES);

			System.out.println("\n\nu: "); vector.vect_print(u, parameters.VEC_N_SIZE_BYTES);
			System.out.println("\n\nv: "); vector.vect_print(v, parameters.VEC_N1N2_SIZE_BYTES);
		}
	}
	
	
	/**
	 * @brief Decryption of the HQC_PKE IND_CPA scheme
	 *
	 * @param[out] m Vector representing the decrypted message
	 * @param[in] u Vector u (first part of the ciphertext)
	 * @param[in] v Vector v (second part of the ciphertext)
	 * @param[in] sk String containing the secret key
	 */
	void hqc_pke_decrypt(long[] m, final long[] u, final long[] v, final byte[] sk) {
	    long[] x = new long[parameters.VEC_N_SIZE_64];
	    long[] y = new long[parameters.VEC_N_SIZE_64];
	    byte[] pk = new byte[parameters.PUBLIC_KEY_BYTES];
	    long[] tmp1 = new long[parameters.VEC_N_SIZE_64];
	    long[] tmp2 = new long[parameters.VEC_N_SIZE_64];

	    // Retrieve x, y, pk from secret key
	    parsing.hqc_secret_key_from_string(x, y, pk, sk);

	    // Compute v - u.y
	    vector.vect_resize(tmp1, parameters.PARAM_N, v, parameters.PARAM_N1N2);
	    gf2x.vect_mul(tmp2, y, u);
	    vector.vect_add(tmp2, tmp1, tmp2, parameters.VEC_N_SIZE_64);
//pri.longHexPri("tmp2=", tmp2);
	    if (parameters.VERBOSE) {
	    	System.out.println("\n\nu: "); vector.vect_print(u, parameters.VEC_N_SIZE_BYTES);
	    	System.out.println("\n\nv: "); vector.vect_print(v, parameters.VEC_N1N2_SIZE_BYTES);
	    	System.out.println("\n\ny: "); vector.vect_print(y, parameters.VEC_N_SIZE_BYTES);
	    	System.out.println("\n\nv - u.y: "); vector.vect_print(tmp2, parameters.VEC_N_SIZE_BYTES);
	    }

	    // Compute m by decoding v - u.y
	    code.code_decode(m, tmp2);
	}

}
