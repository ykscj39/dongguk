package hqc128;

public class Api {
	public final String CRYPTO_ALGNAME = "HQC-128";
	public final int CRYPTO_SECRETKEYBYTES = 2289;
	public final int CRYPTO_PUBLICKEYBYTES = 2249;
	public final int CRYPTO_BYTES = 64;
	public final int CRYPTO_CIPHERTEXTBYTES = 4497;
}
