package hqc128;

public class Shake_ds {
	Fips202 fips202 = new Fips202();
	Pri pri = new Pri();

	void shake256_512_ds(Shake256incctx state, byte[] output, final byte[] input, int inlen, byte domain) {
		byte[] tmp = new byte[1];
		tmp[0] = domain;
						
		/* Init state */
		fips202.shake256_inc_init(state);
				
		/* Absorb input */
		fips202.shake256_inc_absorb(state, input, inlen);
		
		/* Absorb domain separation byte */
		fips202.shake256_inc_absorb(state, tmp, 1);
		domain = tmp[0];
		
		/* Finalize */
		fips202.shake256_inc_finalize(state);

		/* Squeeze output */
		fips202.shake256_inc_squeeze(output, 512 / 8, state);		
	}

}
