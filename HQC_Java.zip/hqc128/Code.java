package hqc128;

public class Code {
	Parameters parameters = new Parameters();
	Vector vector = new Vector();
	Reed_solomon reed_solomon = new Reed_solomon();
	Reed_muller reed_muller = new Reed_muller();
	Pri pri = new Pri();

	void code_encode(long[] em, final long[] m) {
		long[] tmp = new long[parameters.VEC_N1_SIZE_64];

		reed_solomon.reed_solomon_encode(tmp, m);
		reed_muller.reed_muller_encode(em, tmp);

		if (parameters.VERBOSE) {
			System.out.println("\n\nReed-Solomon code word: ");
			vector.vect_print(tmp, parameters.VEC_N1_SIZE_BYTES);
			System.out.println("\n\nConcatenated code word: ");
			vector.vect_print(em, parameters.VEC_N1N2_SIZE_BYTES);
		}
	}
	
	
	/**
	 * @brief Decoding the code word em to a message m using the concatenated code
	 *
	 * @param[out] m Pointer to an array that is the message
	 * @param[in] em Pointer to an array that is the code word
	 */
	void code_decode(long[] m, final long[] em) {
	    long[] tmp = new long[parameters.VEC_N1_SIZE_64];

	    reed_muller.reed_muller_decode(tmp, em);
	    //pri.longHexPri("tmp=", tmp);
	    
	    reed_solomon.reed_solomon_decode(m, tmp);


	    if (parameters.VERBOSE) {
	    	System.out.println("\n\nReed-Muller decoding result (the input for the Reed-Solomon decoding algorithm): "); vector.vect_print(tmp, parameters.VEC_N1_SIZE_BYTES);
	    }
	}

}
