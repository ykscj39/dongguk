package hqc128;

class Seedexpander_state extends Shake256incctx {
}

public class Shake_prng {
	Domains domains = new Domains();
	static Shake256incctx shake_prng_state = new Shake256incctx();
	Fips202 fips202 = new Fips202();
	Pri pri = new Pri();

	void shake_prng_init(byte[] entropy_input, byte[] personalization_string, int enlen, int perlen) {
		byte domain = domains.PRNG_DOMAIN;
		byte[] tmp = new byte[1];
		tmp[0] = domain;

		fips202.shake256_inc_init(shake_prng_state);
		// pri.longHexPri("init=", shake_prng_state.ctx);
		fips202.shake256_inc_absorb(shake_prng_state, entropy_input, enlen);
		// pri.longHexPri("absorb1 = ", shake_prng_state.ctx);

		fips202.shake256_inc_absorb(shake_prng_state, personalization_string, perlen);
		fips202.shake256_inc_absorb(shake_prng_state, tmp, 1);
		domain = tmp[0];
		fips202.shake256_inc_finalize(shake_prng_state);

		// pri.longHexPri("init rst = ", shake_prng_state.ctx);
	}

	void shake_prng(byte[] output, int outlen) {
		// pri.longHexPri("state=", shake_prng_state.ctx);
		fips202.shake256_inc_squeeze(output, outlen, shake_prng_state);
		// pri.byteHexPri(output);
	}

	void seedexpander_init(Seedexpander_state state, final byte[] seed, int seedlen) {
		byte[] domain = new byte[1];
		domain[0] = domains.SEEDEXPANDER_DOMAIN;
		fips202.shake256_inc_init(state);
		fips202.shake256_inc_absorb(state, seed, seedlen);
		fips202.shake256_inc_absorb(state, domain, 1);
		fips202.shake256_inc_finalize(state);
	}

	void seedexpander(Seedexpander_state state, byte[] output, int outlen) {
		final byte bsize = Long.BYTES;// sizeof(uint64_t);
		final byte remainder = (byte) (outlen % bsize);
		byte[] tmp = new byte[Long.BYTES];
		int idx = 0;
			
		fips202.shake256_inc_squeeze(output, outlen - remainder, state);
		//pri.byteHexPri("output1=", output);
				
		if (remainder != 0) {
			fips202.shake256_inc_squeeze(tmp, bsize, state);
			idx += outlen - remainder;// output += outlen - remainder;
			
			for (byte i = 0; i < remainder; i++) {
				output[i + idx] = tmp[i];
			}
		}
		//pri.byteHexPri("output2=", output);
	}

}