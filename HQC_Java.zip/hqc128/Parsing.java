package hqc128;

public class Parsing {
	Parameters parameters = new Parameters();
	Shake_prng shake_prng = new Shake_prng();
	Vector vector = new Vector();
	Api api = new Api();
	Pri pri = new Pri();

	void hqc_secret_key_to_string(byte[] sk, final byte[] sk_seed, final byte[] pk) {
		// memcpy(sk, sk_seed, SEED_BYTES);
		System.arraycopy(sk_seed, 0, sk, 0, parameters.SEED_BYTES);

		// memcpy(sk + SEED_BYTES, pk, PUBLIC_KEY_BYTES);
		System.arraycopy(pk, 0, sk, parameters.SEED_BYTES, parameters.PUBLIC_KEY_BYTES);
	}

	void hqc_secret_key_from_string(long[] x, long[] y, byte[] pk, final byte[] sk) {
		Seedexpander_state sk_seedexpander = new Seedexpander_state();
		byte[] sk_seed = new byte[parameters.SEED_BYTES];

		// memcpy(sk_seed, sk, SEED_BYTES);
		System.arraycopy(sk, 0, sk_seed, 0, parameters.SEED_BYTES);
		//pri.byteHexPri("sk_seed=", sk_seed);
		shake_prng.seedexpander_init(sk_seedexpander, sk_seed, parameters.SEED_BYTES);

		vector.vect_set_random_fixed_weight(sk_seedexpander, x, parameters.PARAM_OMEGA);
		vector.vect_set_random_fixed_weight(sk_seedexpander, y, parameters.PARAM_OMEGA);

		// memcpy(pk, sk + SEED_BYTES, PUBLIC_KEY_BYTES);
		System.arraycopy(sk, parameters.SEED_BYTES, pk, 0, parameters.PUBLIC_KEY_BYTES);
	}

	void hqc_public_key_to_string(byte[] pk, final byte[] pk_seed, final long[] s) {
		// memcpy(pk, pk_seed, SEED_BYTES);
		System.arraycopy(pk_seed, 0, pk, 0, parameters.SEED_BYTES);

		// memcpy(pk + SEED_BYTES, s, VEC_N_SIZE_BYTES);
		for (int i = 0; i < parameters.VEC_N_SIZE_BYTES - (parameters.VEC_N_SIZE_BYTES % 8); i += 8) {
			for (int j = 0; j < 8; j++) {
				pk[i + j + parameters.SEED_BYTES] = (byte) ((s[i / 8] >>> (j * 8)) & 0x00000000000000ffL);
			}
		}
		for (int j = 0; j < parameters.VEC_N_SIZE_BYTES % 8; j++) {
			int i = (parameters.VEC_N_SIZE_BYTES - (parameters.VEC_N_SIZE_BYTES % 8));
			pk[i + j + parameters.SEED_BYTES] = (byte) ((s[i / 8] >>> (j * 8)) & 0x00000000000000ffL);
		}
	}

	void hqc_public_key_from_string(long[] h, long[] s, final byte[] pk) {
		Seedexpander_state pk_seedexpander = new Seedexpander_state();
		byte[] pk_seed = new byte[parameters.SEED_BYTES];

		// memcpy(pk_seed, pk, SEED_BYTES);
		System.arraycopy(pk, 0, pk_seed, 0, parameters.SEED_BYTES);
		shake_prng.seedexpander_init(pk_seedexpander, pk_seed, parameters.SEED_BYTES);
		vector.vect_set_random(pk_seedexpander, h);
	
		// memcpy(s, pk + SEED_BYTES, VEC_N_SIZE_BYTES);
		for (int i = 0; i < parameters.VEC_N_SIZE_BYTES / 8; i++) {
			for (int j = 7; j >= 0; j--) {
				s[i] <<= 8;
				s[i] ^= ((long) pk[(i * 8 + j) + parameters.SEED_BYTES] & 0x00000000000000ffL);
			}
		}		
		
		for (int j = 0; j < parameters.VEC_N_SIZE_BYTES % 8; j++) {
			int i = parameters.VEC_N_SIZE_BYTES / 8;
			s[i] ^= (long) ((pk[(i * 8 + j) + parameters.SEED_BYTES] & 0x00000000000000ffL) << (j * 8));
		}
	}

	void hqc_ciphertext_to_string(byte[] ct, final long[] u, final long[] v, final byte[] d, final long[] salt) {
		// memcpy(ct, u, VEC_N_SIZE_BYTES);
		for (int i = 0; i < parameters.VEC_N_SIZE_64; i++) {
			for (int j = 0; j < 8; j++)
				ct[i * 8 + j] = (byte) ((u[i] >>> (j * 8)) & 0x00000000000000ffL);
		}

		// memcpy(ct + VEC_N_SIZE_BYTES, v, VEC_N1N2_SIZE_BYTES);
		for (int i = 0; i < parameters.VEC_N1N2_SIZE_64; i++) {
			for (int j = 0; j < 8; j++)
				ct[(i * 8 + j) + parameters.VEC_N_SIZE_BYTES] = (byte) ((v[i] >>> (j * 8)) & 0x00000000000000ffL);
		}

		// memcpy(ct + VEC_N_SIZE_BYTES + VEC_N1N2_SIZE_BYTES, d, SHAKE256_512_BYTES);
		System.arraycopy(d, 0, ct, parameters.VEC_N_SIZE_BYTES + parameters.VEC_N1N2_SIZE_BYTES, parameters.SHAKE256_512_BYTES);

		// memcpy(ct + VEC_N_SIZE_BYTES + VEC_N1N2_SIZE_BYTES + SHAKE256_512_BYTES,
		// salt, SALT_SIZE_BYTES);
		for (int i = 0; i < parameters.SALT_SIZE_64; i++) {
			for (int j = 0; j < 8; j++)
				ct[(i * 8 + j) + parameters.VEC_N_SIZE_BYTES + parameters.VEC_N1N2_SIZE_BYTES + parameters.SHAKE256_512_BYTES] = (byte) ((salt[i] >>> (j * 8)) & 0x00000000000000ffL);
		}
	}

	void hqc_ciphertext_from_string(long[] u, long[] v, byte[] d, long[] salt, final byte[] ct) {
		// memcpy(u, ct, VEC_N_SIZE_BYTES);
		for (int i = 0; i < parameters.VEC_N_SIZE_BYTES / 8; i++) {
			for (int j = 7; j >= 0; j--) {
				u[i] <<= 8;
				u[i] ^= ((long) ct[(i * 8 + j)] & 0x00000000000000ff);
			}
		}
		for (int j = 0; j < parameters.VEC_N_SIZE_BYTES % 8; j++) {
			int i = parameters.VEC_N_SIZE_BYTES / 8;
			u[i] ^= (long) ((ct[(i * 8 + j)] & 0x00000000000000ffL) << (j * 8));;
		}

		// memcpy(v, ct + VEC_N_SIZE_BYTES, VEC_N1N2_SIZE_BYTES);
		for (int i = 0; i < parameters.VEC_N1N2_SIZE_BYTES / 8; i++) {
			for (int j = 7; j >= 0; j--) {
				v[i] <<= 8;
				v[i] ^= ((long) ct[(i * 8 + j) + parameters.VEC_N_SIZE_BYTES] & 0x00000000000000ff);
			}
		}
		for (int j = 0; j < parameters.VEC_N1N2_SIZE_BYTES % 8; j++) {
			int i = parameters.VEC_N1N2_SIZE_BYTES / 8;
			v[i] ^= (long) ((ct[(i * 8 + j) + parameters.VEC_N_SIZE_BYTES] & 0x00000000000000ffL) << (j * 8));;
		}

		// memcpy(d, ct + VEC_N_SIZE_BYTES + VEC_N1N2_SIZE_BYTES, SHAKE256_512_BYTES);
		System.arraycopy(ct, parameters.VEC_N_SIZE_BYTES + parameters.VEC_N1N2_SIZE_BYTES, d, 0,
				parameters.SHAKE256_512_BYTES);

		// memcpy(salt, ct + VEC_N_SIZE_BYTES + VEC_N1N2_SIZE_BYTES +
		// SHAKE256_512_BYTES, SALT_SIZE_BYTES);
		for (int i = 0; i < parameters.SALT_SIZE_BYTES / 8; i++) {
			for (int j = 7; j >= 0; j--) {
				salt[i] <<= 8;
				salt[i] ^= ((long) ct[(i * 8 + j) + parameters.VEC_N_SIZE_BYTES + parameters.VEC_N1N2_SIZE_BYTES
						+ parameters.SHAKE256_512_BYTES] & 0x00000000000000ff);
			}
		}
		for (int j = 0; j < parameters.SALT_SIZE_BYTES % 8; j++) {
			int i = parameters.SALT_SIZE_BYTES / 8;
			salt[i] ^= (long) ((ct[(i * 8 + j) + parameters.VEC_N_SIZE_BYTES + parameters.VEC_N1N2_SIZE_BYTES + parameters.SHAKE256_512_BYTES] & 0x00000000000000ffL) << (j * 8));;
		}		
	}
}
