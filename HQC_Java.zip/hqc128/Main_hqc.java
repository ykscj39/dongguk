package hqc128;

import java.util.Arrays;

public class Main_hqc {

	public static final int MAX_MARKER_LEN = 50;
	public static final int KAT_SUCCESS = 0;
	public static final int KAT_FILE_OPEN_ERROR = -1;
	public static final int KAT_DATA_ERROR = -3;
	public static final int KAT_CRYPTO_FAILURE = -4;

	static Api api = new Api();
	static Shake_prng shake_prng = new Shake_prng();
	static Pri pri = new Pri();
	static Kem kem = new Kem();

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		byte[] fn_req = new byte[32];
		byte[] fn_rsp = new byte[32];
		byte[][] seed = new byte[100][48];
		byte[] entropy_input = new byte[48];
		byte[] ct = new byte[api.CRYPTO_CIPHERTEXTBYTES];
		byte[] ss = new byte[api.CRYPTO_BYTES];
		byte[] ss1 = new byte[api.CRYPTO_BYTES];
		int count;
		int done;
		byte[] pk = new byte[api.CRYPTO_PUBLICKEYBYTES];
		byte[] sk = new byte[api.CRYPTO_SECRETKEYBYTES];
		int ret_val;

		for (byte i = 0; i < 48; i++)
			entropy_input[i] = i;

		shake_prng.shake_prng_init(entropy_input, null, 48, 0);

		for (int i = 0; i < 100; i++) {
			shake_prng.shake_prng(seed[i], 48);
		}

		for (int i = 0; i < 100; i++) {
			
			shake_prng.shake_prng_init(seed[i], null, 48, 0);
			
			if ((ret_val = kem.crypto_kem_keypair(pk, sk)) != 0) {
				System.out.println("crypto_kem_keypair returned" + ret_val);
				return;// return KAT_CRYPTO_FAILURE;
			}

			if ((ret_val = kem.crypto_kem_enc(ct, ss, pk)) != 0) {
				System.out.println("crypto_kem_enc returned" + ret_val);
				return;// return KAT_CRYPTO_FAILURE;
			}

			if ((ret_val = kem.crypto_kem_dec(ss1, ct, sk)) != 0) {
				System.out.println("crypto_kem_keypair returned" + ret_val);
				return;// return KAT_CRYPTO_FAILURE;
			}
			pri.byteHexPri("ss1=", ss1);

			if (!Arrays.equals(ss, ss1)) {
				System.out.println("crypto_kem_dec returned bad 'ss' value\\n");
				return;// return KAT_CRYPTO_FAILURE;
			}

		}

		System.out.println("test");
		return;

	}

}