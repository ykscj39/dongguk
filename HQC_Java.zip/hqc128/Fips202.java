package hqc128;

import hqc128.Pri;
import hqc128.Sha3_256incctx;
import hqc128.Sha3_384incctx;
import hqc128.Sha3_512incctx;
import hqc128.Shake128ctx;
import hqc128.Shake128incctx;
import hqc128.Shake256ctx;
import hqc128.Shake256incctx;

//Context for incremental API
class Shake128incctx {
	long[] ctx = new long[26];
};

//Context for non-incremental API
class Shake128ctx {
	long[] ctx = new long[25];
};

//Context for incremental API
class Shake256incctx {
	long[] ctx = new long[26];
};

//Context for non-incremental API
class Shake256ctx {
	long[] ctx = new long[25];
};

//Context for incremental API
class Sha3_256incctx {
	long[] ctx = new long[26];
};

//Context for incremental API
class Sha3_384incctx {
	long[] ctx = new long[26];
};

//Context for incremental API
class Sha3_512incctx {
	long[] ctx = new long[26];
};


public class Fips202 {
	public final int SHAKE128_RATE = 168;
	public final int SHAKE256_RATE = 136;
	public final int SHA3_256_RATE = 136;
	public final int SHA3_384_RATE = 104;
	public final int SHA3_512_RATE = 72;
	
	public final static int NROUNDS = 24;
	
	static Pri pri = new Pri();
	
	static long ROL(long a, int offset) {
		return (((a) << (offset)) ^ ((a) >>> (64 - (offset))));
	}
	
	static long load64(final byte[] x) {
	    long r = 0;
	    for (int i = 0; i < 8; ++i) {
	        r |= (long)x[i] << 8 * i;
	    }

	    return r;
	}
	
	static void store64(byte[] x, long u) {
	    for (int i = 0; i < 8; ++i) {
	        x[i] = (byte) (u >>> 8 * i);
	    }
	}
	
	/* Keccak round constants */
	static final long KeccakF_RoundConstants[] = {
	    0x0000000000000001L, 0x0000000000008082L,
	    0x800000000000808aL, 0x8000000080008000L,
	    0x000000000000808bL, 0x0000000080000001L,
	    0x8000000080008081L, 0x8000000000008009L,
	    0x000000000000008aL, 0x0000000000000088L,
	    0x0000000080008009L, 0x000000008000000aL,
	    0x000000008000808bL, 0x800000000000008bL,
	    0x8000000000008089L, 0x8000000000008003L,
	    0x8000000000008002L, 0x8000000000000080L,
	    0x000000000000800aL, 0x800000008000000aL,
	    0x8000000080008081L, 0x8000000000008080L,
	    0x0000000080000001L, 0x8000000080008008L
	};
	
	static void KeccakF1600_StatePermute(long[] state) {
	    int round;

	    long Aba, Abe, Abi, Abo, Abu;
	    long Aga, Age, Agi, Ago, Agu;
	    long Aka, Ake, Aki, Ako, Aku;
	    long Ama, Ame, Ami, Amo, Amu;
	    long Asa, Ase, Asi, Aso, Asu;
	    long BCa, BCe, BCi, BCo, BCu;
	    long Da, De, Di, Do, Du;
	    long Eba, Ebe, Ebi, Ebo, Ebu;
	    long Ega, Ege, Egi, Ego, Egu;
	    long Eka, Eke, Eki, Eko, Eku;
	    long Ema, Eme, Emi, Emo, Emu;
	    long Esa, Ese, Esi, Eso, Esu;

	    // copyFromState(A, state)
	    Aba = state[0];
	    Abe = state[1];
	    Abi = state[2];
	    Abo = state[3];
	    Abu = state[4];
	    Aga = state[5];
	    Age = state[6];
	    Agi = state[7];
	    Ago = state[8];
	    Agu = state[9];
	    Aka = state[10];
	    Ake = state[11];
	    Aki = state[12];
	    Ako = state[13];
	    Aku = state[14];
	    Ama = state[15];
	    Ame = state[16];
	    Ami = state[17];
	    Amo = state[18];
	    Amu = state[19];
	    Asa = state[20];
	    Ase = state[21];
	    Asi = state[22];
	    Aso = state[23];
	    Asu = state[24];
	    
	    //pri.longHexPri("kecc state=", state);
	    
	    //System.out.println("ROS");
	    for (round = 0; round < NROUNDS; round += 2) {
	        //    prepareTheta
	        BCa = Aba ^ Aga ^ Aka ^ Ama ^ Asa;
	        BCe = Abe ^ Age ^ Ake ^ Ame ^ Ase;
	        BCi = Abi ^ Agi ^ Aki ^ Ami ^ Asi;
	        BCo = Abo ^ Ago ^ Ako ^ Amo ^ Aso;
	        BCu = Abu ^ Agu ^ Aku ^ Amu ^ Asu;
	        //System.out.println(String.format("%016x ", BCa) + String.format("%016x ", BCe) + String.format("%016x ", BCi) + String.format("%016x ", BCo) + String.format("%016x ", BCu));
	        
	        // thetaRhoPiChiIotaPrepareTheta(round  , A, E)
	        Da = BCu ^ ROL(BCe, 1);
	        De = BCa ^ ROL(BCi, 1);
	        Di = BCe ^ ROL(BCo, 1);
	        Do = BCi ^ ROL(BCu, 1);
	        Du = BCo ^ ROL(BCa, 1);
	        //System.out.println(String.format("%016x ", Da) + String.format("%016x ", De) + String.format("%016x ", Di) + String.format("%016x ", Do) + String.format("%016x ", Du));
	        
	        Aba ^= Da;
	        BCa = Aba;
	        Age ^= De;
	        BCe = ROL(Age, 44);
	        Aki ^= Di;
	        BCi = ROL(Aki, 43);
	        Amo ^= Do;
	        BCo = ROL(Amo, 21);
	        Asu ^= Du;
	        BCu = ROL(Asu, 14);
	        Eba = BCa ^ ((~BCe) & BCi);
	        Eba ^= KeccakF_RoundConstants[round];
	        Ebe = BCe ^ ((~BCi) & BCo);
	        Ebi = BCi ^ ((~BCo) & BCu);
	        Ebo = BCo ^ ((~BCu) & BCa);
	        Ebu = BCu ^ ((~BCa) & BCe);

	        Abo ^= Do;
	        BCa = ROL(Abo, 28);
	        Agu ^= Du;
	        BCe = ROL(Agu, 20);
	        Aka ^= Da;
	        BCi = ROL(Aka, 3);
	        Ame ^= De;
	        BCo = ROL(Ame, 45);
	        Asi ^= Di;
	        BCu = ROL(Asi, 61);
	        Ega = BCa ^ ((~BCe) & BCi);
	        Ege = BCe ^ ((~BCi) & BCo);
	        Egi = BCi ^ ((~BCo) & BCu);
	        Ego = BCo ^ ((~BCu) & BCa);
	        Egu = BCu ^ ((~BCa) & BCe);

	        Abe ^= De;
	        BCa = ROL(Abe, 1);
	        Agi ^= Di;
	        BCe = ROL(Agi, 6);
	        Ako ^= Do;
	        BCi = ROL(Ako, 25);
	        Amu ^= Du;
	        BCo = ROL(Amu, 8);
	        Asa ^= Da;
	        BCu = ROL(Asa, 18);
	        Eka = BCa ^ ((~BCe) & BCi);
	        Eke = BCe ^ ((~BCi) & BCo);
	        Eki = BCi ^ ((~BCo) & BCu);
	        Eko = BCo ^ ((~BCu) & BCa);
	        Eku = BCu ^ ((~BCa) & BCe);

	        Abu ^= Du;
	        BCa = ROL(Abu, 27);
	        Aga ^= Da;
	        BCe = ROL(Aga, 36);
	        Ake ^= De;
	        BCi = ROL(Ake, 10);
	        Ami ^= Di;
	        BCo = ROL(Ami, 15);
	        Aso ^= Do;
	        BCu = ROL(Aso, 56);
	        Ema = BCa ^ ((~BCe) & BCi);
	        Eme = BCe ^ ((~BCi) & BCo);
	        Emi = BCi ^ ((~BCo) & BCu);
	        Emo = BCo ^ ((~BCu) & BCa);
	        Emu = BCu ^ ((~BCa) & BCe);

	        Abi ^= Di;
	        BCa = ROL(Abi, 62);
	        Ago ^= Do;
	        BCe = ROL(Ago, 55);
	        Aku ^= Du;
	        BCi = ROL(Aku, 39);
	        Ama ^= Da;
	        BCo = ROL(Ama, 41);
	        Ase ^= De;
	        BCu = ROL(Ase, 2);
	        Esa = BCa ^ ((~BCe) & BCi);
	        Ese = BCe ^ ((~BCi) & BCo);
	        Esi = BCi ^ ((~BCo) & BCu);
	        Eso = BCo ^ ((~BCu) & BCa);
	        Esu = BCu ^ ((~BCa) & BCe);

	        //    prepareTheta
	        BCa = Eba ^ Ega ^ Eka ^ Ema ^ Esa;
	        BCe = Ebe ^ Ege ^ Eke ^ Eme ^ Ese;
	        BCi = Ebi ^ Egi ^ Eki ^ Emi ^ Esi;
	        BCo = Ebo ^ Ego ^ Eko ^ Emo ^ Eso;
	        BCu = Ebu ^ Egu ^ Eku ^ Emu ^ Esu;

	        // thetaRhoPiChiIotaPrepareTheta(round+1, E, A)
	        Da = BCu ^ ROL(BCe, 1);
	        De = BCa ^ ROL(BCi, 1);
	        Di = BCe ^ ROL(BCo, 1);
	        Do = BCi ^ ROL(BCu, 1);
	        Du = BCo ^ ROL(BCa, 1);

	        Eba ^= Da;
	        BCa = Eba;
	        Ege ^= De;
	        BCe = ROL(Ege, 44);
	        Eki ^= Di;
	        BCi = ROL(Eki, 43);
	        Emo ^= Do;
	        BCo = ROL(Emo, 21);
	        Esu ^= Du;
	        BCu = ROL(Esu, 14);
	        Aba = BCa ^ ((~BCe) & BCi);
	        Aba ^= KeccakF_RoundConstants[round + 1];
	        Abe = BCe ^ ((~BCi) & BCo);
	        Abi = BCi ^ ((~BCo) & BCu);
	        Abo = BCo ^ ((~BCu) & BCa);
	        Abu = BCu ^ ((~BCa) & BCe);

	        Ebo ^= Do;
	        BCa = ROL(Ebo, 28);
	        Egu ^= Du;
	        BCe = ROL(Egu, 20);
	        Eka ^= Da;
	        BCi = ROL(Eka, 3);
	        Eme ^= De;
	        BCo = ROL(Eme, 45);
	        Esi ^= Di;
	        BCu = ROL(Esi, 61);
	        Aga = BCa ^ ((~BCe) & BCi);
	        Age = BCe ^ ((~BCi) & BCo);
	        Agi = BCi ^ ((~BCo) & BCu);
	        Ago = BCo ^ ((~BCu) & BCa);
	        Agu = BCu ^ ((~BCa) & BCe);

	        Ebe ^= De;
	        BCa = ROL(Ebe, 1);
	        Egi ^= Di;
	        BCe = ROL(Egi, 6);
	        Eko ^= Do;
	        BCi = ROL(Eko, 25);
	        Emu ^= Du;
	        BCo = ROL(Emu, 8);
	        Esa ^= Da;
	        BCu = ROL(Esa, 18);
	        Aka = BCa ^ ((~BCe) & BCi);
	        Ake = BCe ^ ((~BCi) & BCo);
	        Aki = BCi ^ ((~BCo) & BCu);
	        Ako = BCo ^ ((~BCu) & BCa);
	        Aku = BCu ^ ((~BCa) & BCe);

	        Ebu ^= Du;
	        BCa = ROL(Ebu, 27);
	        Ega ^= Da;
	        BCe = ROL(Ega, 36);
	        Eke ^= De;
	        BCi = ROL(Eke, 10);
	        Emi ^= Di;
	        BCo = ROL(Emi, 15);
	        Eso ^= Do;
	        BCu = ROL(Eso, 56);
	        Ama = BCa ^ ((~BCe) & BCi);
	        Ame = BCe ^ ((~BCi) & BCo);
	        Ami = BCi ^ ((~BCo) & BCu);
	        Amo = BCo ^ ((~BCu) & BCa);
	        Amu = BCu ^ ((~BCa) & BCe);

	        Ebi ^= Di;
	        BCa = ROL(Ebi, 62);
	        Ego ^= Do;
	        BCe = ROL(Ego, 55);
	        Eku ^= Du;
	        BCi = ROL(Eku, 39);
	        Ema ^= Da;
	        BCo = ROL(Ema, 41);
	        Ese ^= De;
	        BCu = ROL(Ese, 2);
	        Asa = BCa ^ ((~BCe) & BCi);
	        Ase = BCe ^ ((~BCi) & BCo);
	        Asi = BCi ^ ((~BCo) & BCu);
	        Aso = BCo ^ ((~BCu) & BCa);
	        Asu = BCu ^ ((~BCa) & BCe);
	    }

	    // copyToState(state, A)
	    state[0] = Aba;
	    state[1] = Abe;
	    state[2] = Abi;
	    state[3] = Abo;
	    state[4] = Abu;
	    state[5] = Aga;
	    state[6] = Age;
	    state[7] = Agi;
	    state[8] = Ago;
	    state[9] = Agu;
	    state[10] = Aka;
	    state[11] = Ake;
	    state[12] = Aki;
	    state[13] = Ako;
	    state[14] = Aku;
	    state[15] = Ama;
	    state[16] = Ame;
	    state[17] = Ami;
	    state[18] = Amo;
	    state[19] = Amu;
	    state[20] = Asa;
	    state[21] = Ase;
	    state[22] = Asi;
	    state[23] = Aso;
	    state[24] = Asu;	    
	}
	
	static void keccak_absorb(long[] s, int r, final byte[] m, int mlen, byte p) {
		int i;
		byte[] t = new byte[200];
		byte[] tmp = new byte[8];
		int idx = 0;
		/* Zero state */
		for (i = 0; i < 25; ++i) {
			s[i] = 0;
		}
	
		while (mlen >= r) {
			for (i = 0; i < r / 8; ++i) {
				System.arraycopy(m, 8 * i + idx, tmp, 0, 8);
				s[i] ^= load64(tmp);
			}
		
			KeccakF1600_StatePermute(s);
			mlen -= r;
			idx += r;//m += r;
		}
	
		for (i = 0; i < r; ++i) {
			t[i] = 0;
		}
		
		for (i = 0; i < mlen; ++i) {
			t[i] = m[i];
		}
		
		t[i] = p;
		t[r - 1] |= 128;
		
		for (i = 0; i < r / 8; ++i) {
			System.arraycopy(t, 8 * i, tmp, 0, 8);
			s[i] ^= load64(tmp);
		}
	}
	
	static void keccak_squeezeblocks(byte[] h, int nblocks, long[] s, int r) {
		byte[] tmp = new byte[8];
		int idx = 0;
		
		while (nblocks > 0) {
			KeccakF1600_StatePermute(s);
			for (int i = 0; i < (r >>> 3); i++) {
				System.arraycopy(h, 8 * i + idx, tmp, 0, 8);
				store64(tmp, s[i]);
			}
			idx += r;//h += r;
			nblocks--;
		}
	}
	
	static void keccak_inc_init(long[] s_inc) {
	    int i;

	    for (i = 0; i < 25; ++i) {
	        s_inc[i] = 0;
	    }
	    s_inc[25] = 0;
	}
	
	static void keccak_inc_absorb(long[] s_inc, int r, final byte[] m, int mlen) {
		int i;
		int idx = 0;

		//if(mlen > 2231)
		//	System.out.println(String.format("%02x %016x ", m[54 + 2176], m[54 + 2176]));
		
		/* Recall that s_inc[25] is the non-absorbed bytes xored into the state */
		while (mlen + s_inc[25] >= r) {
			for (i = 0; i < r - (int)s_inc[25]; i++) {
				/* Take the i'th byte from message
				 * xor with the s_inc[25] + i'th byte of the state; little-endian */				
				//s_inc[(int) ((s_inc[25] + i) >>> 3)] ^= (long)((m[i + idx] & 0x00000000000000FFL) << (8 * ((s_inc[25] + i) & 0x07)));
				long tmp = (m[i + idx] & 0x00000000000000FFL);
				//System.out.print(String.format("%016x ", tmp));
				s_inc[(int) ((s_inc[25] + i) >>> 3)] ^= (tmp << (8 * ((s_inc[25] + i) & 0x07)));
			}
			//System.out.println("");
			mlen -= (r - s_inc[25]);
			idx += (r - s_inc[25]); //m += r - s_inc[25];
			s_inc[25] = 0;
			
			//pri.longHexPri("keccak1=", s_inc);
			//System.out.println(String.format("%016x, %016x", s_inc[0], s_inc[6]));
			KeccakF1600_StatePermute(s_inc);
			//pri.longHexPri("keccak2=", s_inc);
		}
		
		for (i = 0; i < mlen; i++) {
			s_inc[(int) ((s_inc[25] + i) >>> 3)] ^= (long)((m[i + idx] & 0x00000000000000FFL) << (8 * ((s_inc[25] + i) & 0x07)));
		}
		s_inc[25] += mlen;
	}
	
	static void keccak_inc_finalize(long[] s_inc, int r, byte p) {
	    /* After keccak_inc_absorb, we are guaranteed that s_inc[25] < r,
	       so we can always use one more byte for p in the current state. */
	    s_inc[(int) (s_inc[25] >>> 3)] ^= (long)p << (8 * (s_inc[25] & 0x07));
	    s_inc[(r - 1) >> 3] ^= (long)128 << (8 * ((r - 1) & 0x07));
	    s_inc[25] = 0;
	}
	
	static void keccak_inc_squeeze(byte[] h, int outlen, long[] s_inc, int r) {
		int i;
		int idx = 0;
		//System.out.print("h="); 
		/* First consume any bytes we still have sitting around */
		for (i = 0; i < outlen && i < s_inc[25]; i++) {
			/* There are s_inc[25] bytes left, so r - s_inc[25] is the first
			 * available byte. We consume from there, i.e., up to r. */
			h[i + idx] = (byte)(s_inc[(int) ((r - s_inc[25] + i) >>> 3)] >>> (8 * ((r - s_inc[25] + i) & 0x07)));
			//System.out.println(String.format("%02x", h[i + idx]) + " ");
		}
		//System.out.println();
		
		idx += i;//h += i;
		outlen -= i;
		s_inc[25] -= i;		
		//System.out.println("s_inc[25] = " + String.format("%016x", s_inc[25]));
		
		/* Then squeeze the remaining necessary blocks */
		while (outlen > 0) {
			KeccakF1600_StatePermute(s_inc);
			//System.out.print("kecc = "); Pri.longHexPri(s_inc);
			
			for (i = 0; i < outlen && i < r; i++) {
				h[i + idx] = (byte)(s_inc[i >>> 3] >>> (8 * (i & 0x07)));
			}
			
			idx += i;//h += i;
			outlen -= i;
			s_inc[25] = r - i;
		}
	}
	
	void shake128_inc_init(Shake128incctx state) {	
	    keccak_inc_init(state.ctx);
	}
	
	void shake128_inc_absorb(Shake128incctx state, final byte[] input, int inlen) {
	    keccak_inc_absorb(state.ctx, SHAKE128_RATE, input, inlen);
	}

	void shake128_inc_finalize(Shake128incctx state) {
	    keccak_inc_finalize(state.ctx, SHAKE128_RATE, (byte) 0x1F);
	}

	void shake128_inc_squeeze(byte[] output, int outlen, Shake128incctx state) {
	    keccak_inc_squeeze(output, outlen, state.ctx, SHAKE128_RATE);
	}

	void shake256_inc_init(Shake256incctx state) {
	    keccak_inc_init(state.ctx);
	}

	void shake256_inc_absorb(Shake256incctx state, final byte[] input, int inlen) {
	    keccak_inc_absorb(state.ctx, SHAKE256_RATE, input, inlen);
	}

	void shake256_inc_finalize(Shake256incctx state) {
	    keccak_inc_finalize(state.ctx, SHAKE256_RATE, (byte) 0x1F);
	}

	void shake256_inc_squeeze(byte[] output, int outlen, Shake256incctx state) {
	    keccak_inc_squeeze(output, outlen, state.ctx, SHAKE256_RATE);
	}
	
	void shake128_absorb(Shake128ctx state, final byte[] input, int inlen) {
	    keccak_absorb(state.ctx, SHAKE128_RATE, input, inlen, (byte) 0x1F);
	}
	
	void shake128_squeezeblocks(byte[] output, int nblocks, Shake128ctx state) {
	    keccak_squeezeblocks(output, nblocks, state.ctx, SHAKE128_RATE);
	}
	
	void shake256_absorb(Shake256ctx state, final byte[] input, int inlen) {
	    keccak_absorb(state.ctx, SHAKE256_RATE, input, inlen, (byte) 0x1F);
	}
	
	void shake256_squeezeblocks(byte[] output, int nblocks, Shake256ctx state) {
	    keccak_squeezeblocks(output, nblocks, state.ctx, SHAKE256_RATE);
	}
	
	void shake128(byte[] output, int outlen, final byte[] input, int inlen) {
		int nblocks = outlen / SHAKE128_RATE;
		byte[] t = new byte[SHAKE128_RATE];
		Shake128ctx s = new Shake128ctx();
		int idxOut = 0;
		
		shake128_absorb(s, input, inlen);
		shake128_squeezeblocks(output, nblocks, s);
		
		idxOut += nblocks * SHAKE128_RATE; //output += nblocks * SHAKE128_RATE;
		outlen -= nblocks * SHAKE128_RATE;
		
		if (outlen != 0) {
			shake128_squeezeblocks(t, 1, s);
			for (int i = 0; i < outlen; ++i) {
				output[i + idxOut] = t[i];
			}
		}
	}
	
	void shake256(byte[] output, int outlen, final byte[] input, int inlen) {
		int nblocks = outlen / SHAKE256_RATE;
		byte[] t = new byte[SHAKE256_RATE];
		Shake256ctx s = new Shake256ctx();
		int idxOut = 0;

		shake256_absorb(s, input, inlen);
		shake256_squeezeblocks(output, nblocks, s);

		idxOut+= nblocks * SHAKE256_RATE;//output += nblocks * SHAKE256_RATE;
		outlen -= nblocks * SHAKE256_RATE;
		
		if (outlen != 0) {
			shake256_squeezeblocks(t, 1, s);
			for (int i = 0; i < outlen; ++i) {
				output[i + idxOut] = t[i];
			}
		}
	}
	
	void sha3_256_inc_init(Sha3_256incctx state) {
		keccak_inc_init(state.ctx);
	}
	
	void sha3_256_inc_absorb(Sha3_256incctx state, final byte[] input, int inlen) {
		keccak_inc_absorb(state.ctx, SHA3_256_RATE, input, inlen);
	}
	
	void sha3_256_inc_finalize(byte[] output, Sha3_256incctx state) {
		
		byte[] t = new byte[SHA3_256_RATE];
		keccak_inc_finalize(state.ctx, SHA3_256_RATE, (byte)0x06);
		keccak_squeezeblocks(t, 1, state.ctx, SHA3_256_RATE);
		
		for (int i = 0; i < 32; i++) {
			output[i] = t[i];
		}
	}
	
	void sha3_256(byte[] output, final byte[] input, int inlen) {
	    long[] s = new long[25];
	    byte[] t = new byte[SHA3_256_RATE];

	    /* Absorb input */
	    keccak_absorb(s, SHA3_256_RATE, input, inlen, (byte)0x06);

	    /* Squeeze output */
	    keccak_squeezeblocks(t, 1, s, SHA3_256_RATE);

	    for (int i = 0; i < 32; i++) {
	        output[i] = t[i];
	    }
	}

	void sha3_384_inc_init(Sha3_384incctx state) {
	    keccak_inc_init(state.ctx);
	}

	void sha3_384_inc_absorb(Sha3_384incctx state, final byte[] input, int inlen) {
	    keccak_inc_absorb(state.ctx, SHA3_384_RATE, input, inlen);
	}

	void sha3_384_inc_finalize(byte[] output, Sha3_384incctx state) {
	    byte[] t = new byte[SHA3_384_RATE];
	    keccak_inc_finalize(state.ctx, SHA3_384_RATE, (byte)0x06);

	    keccak_squeezeblocks(t, 1, state.ctx, SHA3_384_RATE);

	    for (int i = 0; i < 48; i++) {
	        output[i] = t[i];
	    }
	}
	
	void sha3_384(byte[] output, final byte[] input, int inlen) {
		long[] s = new long[25];
		byte[] t = new byte[SHA3_384_RATE];
		
		/* Absorb input */
		keccak_absorb(s, SHA3_384_RATE, input, inlen, (byte)0x06);
		
		/* Squeeze output */
		keccak_squeezeblocks(t, 1, s, SHA3_384_RATE);
		
		for (int i = 0; i < 48; i++) {
			output[i] = t[i];
		}
	}

	void sha3_512_inc_init(Sha3_512incctx state) {
		keccak_inc_init(state.ctx);
	}

	void sha3_512_inc_absorb(Sha3_512incctx state, final byte[] input, int inlen) {
		keccak_inc_absorb(state.ctx, SHA3_512_RATE, input, inlen);
	}

	void sha3_512_inc_finalize(byte[] output, Sha3_512incctx state) {
		byte[] t = new byte[SHA3_512_RATE];

		keccak_inc_finalize(state.ctx, SHA3_512_RATE, (byte)0x06);

	    keccak_squeezeblocks(t, 1, state.ctx, SHA3_512_RATE);

	    for (int i = 0; i < 64; i++) {
	        output[i] = t[i];
	    }
	}
	
	void sha3_512(byte[] output, final byte[] input, int inlen) {
		long[] s = new long[25];
		byte[] t = new byte[SHA3_512_RATE];

	    /* Absorb input */
	    keccak_absorb(s, SHA3_512_RATE, input, inlen,(byte) 0x06);

	    /* Squeeze output */
	    keccak_squeezeblocks(t, 1, s, SHA3_512_RATE);

	    for (int i = 0; i < 64; i++) {
	        output[i] = t[i];
	    }
	}

}
