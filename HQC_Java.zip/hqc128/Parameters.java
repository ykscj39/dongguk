package hqc128;

public class Parameters {
	Api api = new Api();

	int CEIL_DIVIDE(int a, int b) {
		return (((a) / (b)) + ((a) % (b) == 0 ? 0 : 1));
	}

	long BITMASK(int a, int size) {
		return (((0x0000000000000001L) << ((long) a % (long) size)) - 1);
	}

	public final int PARAM_N = 17669;
	public final int PARAM_N1 = 46;
	public final int PARAM_N2 = 384;
	public final int PARAM_N1N2 = 17664;
	public final short PARAM_OMEGA = 66;
	public final short PARAM_OMEGA_E = 75;
	public final short PARAM_OMEGA_R = 75;
	public final int PARAM_SECURITY = 128;
	public final int PARAM_DFR_EXP = 128;

	public final int SECRET_KEY_BYTES = api.CRYPTO_SECRETKEYBYTES;
	public final int PUBLIC_KEY_BYTES = api.CRYPTO_PUBLICKEYBYTES;
	public final int SHARED_SECRET_BYTES = api.CRYPTO_BYTES;
	public final int CIPHERTEXT_BYTES = api.CRYPTO_CIPHERTEXTBYTES;

	public final short PARAM_DELTA = 15;
	public final int PARAM_M = 8;
	public final short PARAM_GF_POLY = 0x11D;
	public final int PARAM_GF_POLY_WT = 5;
	public final int PARAM_GF_POLY_M2 = 4;
	public final short PARAM_GF_MUL_ORDER = 255;
	public final int PARAM_K = 16;
	public final int PARAM_G = 31;
	public final int PARAM_FFT = 4;
	public final short[] RS_POLY_COEFS = { 89, 69, 153, 116, 176, 117, 111, 75, 73, 233, 242, 233, 65, 210, 21, 139,
			103, 173, 67, 118, 105, 210, 174, 110, 74, 69, 228, 82, 255, 181, 1 };

	public final int UTILS_REJECTION_THRESHOLD = 16767881;
	public final int VEC_N_SIZE_BYTES = CEIL_DIVIDE(PARAM_N, 8);
	public final int VEC_K_SIZE_BYTES = PARAM_K;
	public final int VEC_N1_SIZE_BYTES = PARAM_N1;
	public final int VEC_N1N2_SIZE_BYTES = CEIL_DIVIDE(PARAM_N1N2, 8);

	public final int VEC_N_SIZE_64 = CEIL_DIVIDE(PARAM_N, 64);
	public final int VEC_K_SIZE_64 = CEIL_DIVIDE(PARAM_K, 8);
	public final int VEC_N1_SIZE_64 = CEIL_DIVIDE(PARAM_N1, 8);
	public final int VEC_N1N2_SIZE_64 = CEIL_DIVIDE(PARAM_N1N2, 64);

	public final long RED_MASK = BITMASK(PARAM_N, 64);
	public final int SHAKE256_512_BYTES = 64;
	public final int SEED_BYTES = 40;
	public final int SALT_SIZE_BYTES = 16;
	public final int SALT_SIZE_64 = 2;

	public static final boolean VERBOSE = false;

}
