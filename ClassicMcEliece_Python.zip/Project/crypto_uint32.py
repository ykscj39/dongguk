from gf import *


def crypto_uint32_signed_negative_mask(crypto_uint32_signed_x):
    return crypto_uint32_signed_x.value >> 31


def crypto_uint32_nonzero_mask(crypto_uint32_x):
    return crypto_uint32_signed_negative_mask(crypto_uint32_x) | crypto_uint32_signed_negative_mask(int32_t(-crypto_uint32_x.value))


def crypto_uint32_zero_mask(crypto_uint32_x):
    return int32_t(~crypto_uint32_nonzero_mask(crypto_uint32_x)).value


def crypto_uint32_unequal_mask(crypto_uint32_x, crypto_uint32_y):
    crypto_uint32_xy = uint32_t(crypto_uint32_x.value ^ crypto_uint32_y.value)
    return crypto_uint32_nonzero_mask(crypto_uint32_xy)


def crypto_uint32_equal_mask(crypto_uint32_x, crypto_uint32_y):
    return int32_t(~crypto_uint32_unequal_mask(crypto_uint32_x, crypto_uint32_y)).value


def crypto_uint32_smaller_mask(crypto_uint32_x, crypto_uint32_y):
    crypto_uint32_xy = uint32_t(crypto_uint32_x.value ^ crypto_uint32_y.value)
    crypto_uint32_z = uint32_t(crypto_uint32_x.value - crypto_uint32_y.value)
    crypto_uint32_z.value ^= crypto_uint32_xy.value & (crypto_uint32_z.value ^ crypto_uint32_x.value ^ (1 << 31))
    return crypto_uint32_signed_negative_mask(crypto_uint32_z)


def crypto_uint32_min(crypto_uint32_x, crypto_uint32_y):
    crypto_uint32_xy = uint32_t(crypto_uint32_y.value ^ crypto_uint32_x.value)
    crypto_uint32_z = uint32_t(crypto_uint32_y.value - crypto_uint32_x.value)
    crypto_uint32_z.value ^= crypto_uint32_xy.value & (crypto_uint32_z.value ^ crypto_uint32_y.value ^ (1 << 31))
    crypto_uint32_z.value = crypto_uint32_signed_negative_mask(crypto_uint32_z)
    crypto_uint32_z.value &= crypto_uint32_xy.value
    return crypto_uint32_x.value ^ crypto_uint32_z.value


def crypto_uint32_max(crypto_uint32_x, crypto_uint32_y):
    crypto_uint32_xy = uint32_t(crypto_uint32_y.value ^ crypto_uint32_x.value)
    crypto_uint32_z = uint32_t(crypto_uint32_y.value - crypto_uint32_x.value)
    crypto_uint32_z.value ^= crypto_uint32_xy.value & (crypto_uint32_z.value ^ crypto_uint32_y.value ^ (1 << 31))
    crypto_uint32_z.value = crypto_uint32_signed_negative_mask(crypto_uint32_z)
    crypto_uint32_z.value &= crypto_uint32_xy.value
    return crypto_uint32_y.value ^ crypto_uint32_z.value


def crypto_uint32_minmax(crypto_uint32_a, crypto_uint32_b):
    crypto_uint32_x = crypto_uint32_a
    crypto_uint32_y = crypto_uint32_b
    crypto_uint32_xy = uint32_t(crypto_uint32_y.value ^ crypto_uint32_x.value)
    crypto_uint32_z = uint32_t(crypto_uint32_y.value - crypto_uint32_x.value)
    crypto_uint32_z.value ^= crypto_uint32_xy.value & (crypto_uint32_z.value ^ crypto_uint32_y.value ^ (1 << 31))
    crypto_uint32_z.value = crypto_uint32_signed_negative_mask(crypto_uint32_z)
    crypto_uint32_z.value &= crypto_uint32_xy.value
    crypto_uint32_a.value = crypto_uint32_x.value ^ crypto_uint32_z.value
    crypto_uint32_b.value = crypto_uint32_y.value ^ crypto_uint32_z.value
