# This file is for syndrome computation

from root import *

"""
input: Goppa polynomial f, support L, received word r 
output: out, the syndrome of length 2t 
"""


def synd(out, f, L, r):
    e = gf()
    e_inv = gf()
    c = gf()

    for j in range(2 * SYS_T):
        out[j] = 0

    for i in range(SYS_N):
        c.value = (r[i // 8] >> (i % 8)) & 1

        e = eval(f, gf(L[i]))
        e_inv = gf_inv(gf(gf_mul(e, e)))

        for j in range(2 * SYS_T):
            out[j] = gf_add(gf(out[j]), gf(gf_mul(e_inv, c))).value
            e_inv.value = gf_mul(e_inv, gf(L[i]))
