"""
   PQCgenKAT_kem.c
   Created by Bassham, Lawrence E (Fed) on 8/29/17.
   Copyright © 2017 Bassham, Lawrence E (Fed). All rights reserved.
   + mods from djb: see KATNOTES
"""

from operations import *
import sys
from crypto_kem import *

KAT_SUCCESS = 0
KAT_FILE_OPEN_ERROR = -1
KAT_CRYPTO_FAILURE = -4
KATNUM = 10

entropy_input = bytearray(48)
seed = [bytearray(48) for _ in range(KATNUM)]


def fprintBstr(fp, S, A, L):
    fp.write(S)
    for i in range(L):
        fp.write("{:02X}".format(A[i]))
    if L == 0:
        fp.write("00")
    fp.write("\n")


def main():
    ct = bytearray(crypto_kem_CIPHERTEXTBYTES)
    ss = bytearray(crypto_kem_BYTES)
    ss1 = bytearray(crypto_kem_BYTES)
    pk = bytearray(crypto_kem_PUBLICKEYBYTES)
    sk = bytearray(crypto_kem_SECRETKEYBYTES)

    for i in range(48):
        entropy_input[i] = i
    randombytes_init(entropy_input, None, 256)

    for i in range(KATNUM):
        randombytes(seed[i], 48)

    fp_req = open("kat_kem.req", "w")
    if fp_req is None:
        return KAT_FILE_OPEN_ERROR

    for i in range(KATNUM):
        fp_req.write(f"count = {i}\n")
        fprintBstr(fp_req, "seed = ", seed[i], 48)
        fp_req.write("pk =\n")
        fp_req.write("sk =\n")
        fp_req.write("ct =\n")
        fp_req.write("ss =\n\n")

    fp_rsp = open("kat_kem.int", "w")
    if fp_rsp is None:
        return KAT_FILE_OPEN_ERROR

    fp_rsp.write("# kem/{}\n\n".format(crypto_kem_PRIMITIVE))

    for i in range(KATNUM):
        if pk is None:
            pk = bytearray(crypto_kem_PUBLICKEYBYTES)
            if pk is None:
                sys.exit("Memory allocation failed for pk")

        if sk is None:
            sk = bytearray(crypto_kem_SECRETKEYBYTES)
            if sk is None:
                sys.exit("Memory allocation failed for sk")

        if ct is None:
            ct = bytearray(crypto_kem_CIPHERTEXTBYTES)
            if ct is None:
                sys.exit("Memory allocation failed for ct")

        if ss is None:
            ss = bytearray(crypto_kem_BYTES)
            if ss is None:
                sys.exit("Memory allocation failed for ss")

        randombytes_init(seed[i], None, 256)

        fp_rsp.write("count = {}\n".format(i))
        fprintBstr(fp_rsp, "seed = ", seed[i], 48)

        ret_val = crypto_kem_keypair(pk, sk)

        if ret_val != 0:
            print(f"crypto_kem_keypair returned <{ret_val}>")
            return KAT_CRYPTO_FAILURE

        fprintBstr(fp_rsp, "pk = ", pk, crypto_kem_PUBLICKEYBYTES)
        fprintBstr(fp_rsp, "sk = ", sk, crypto_kem_SECRETKEYBYTES)

        ret_val = crypto_kem_enc(ct, ss, pk)
        if ret_val != 0:
            print(f"crypto_kem_enc returned <{ret_val}>")
            return KAT_CRYPTO_FAILURE

        fprintBstr(fp_rsp, "ct = ", ct, crypto_kem_CIPHERTEXTBYTES)
        fprintBstr(fp_rsp, "ss = ", ss, crypto_kem_BYTES)

        fp_rsp.write("\n")

        ret_val = crypto_kem_dec(ss1, ct, sk)

        if ret_val != 0:
            print(f"crypto_kem_keypair returned <{ret_val}>")
            return KAT_CRYPTO_FAILURE

        if ss[: crypto_kem_BYTES] == ss1[: crypto_kem_BYTES]:
            print(f"crypto_kem_dec returned bad 'ss' value")
            return KAT_CRYPTO_FAILURE
        else:
            print("success")

    return KAT_SUCCESS


if __name__ == "__main__":
    main()
