import ctypes

RNG_SUCCESS = 0
RNG_BAD_MAXLEN = -1
RNG_BAD_OUTBUF = -2
RNG_BAD_REQ_LEN = -3


class AEX_XOF_struct:
    def __init__(self):
        self.buffer = bytearray(16)
        self.buffer_pos = 0
        self.length_remaining = 0
        self.key = bytearray(32)
        self.ctr = bytearray(16)


class AES256_CTR_DRBG_struct:
    def __init__(self):
        self.Key = bytearray(32)
        self.V = bytearray(16)
        self.reseed_counter = 0


# ctx = AEX_XOF_struct()
DRBG_ctx = AES256_CTR_DRBG_struct()


# seedexpander_init()
# ctx            - stores the current state of an instance of the seed expander
# seed           - a 32 byte random value
# diversifier    - an 8 byte diversifier
# maxlen         - maximum number of bytes (less than 2**32) generated under this seed and diversifie
def seedexpander_init(ctx: AEX_XOF_struct, seed, diversifier, maxlen):
    if maxlen >= 0x100000000:
        return RNG_BAD_MAXLEN

    ctx.length_remaining = maxlen

    ctx.key[:] = seed[:32]

    ctx.ctr[:8] = diversifier[:8]
    ctx.ctr[11] = maxlen % 256
    maxlen >>= 8
    ctx.ctr[10] = maxlen % 256
    maxlen >>= 8
    ctx.ctr[9] = maxlen % 256
    maxlen >>= 8
    ctx.ctr[8] = maxlen % 256
    ctx.ctr[12:16] = bytearray([0x00] * 4)

    ctx.buffer_pos = 16
    ctx.buffer[:16] = bytearray([0x00] * 16)

    return RNG_SUCCESS


# seedexpander()
#    ctx  - stores the current state of an instance of the seed expander
#    x    - returns the XOF data
#    xlen - number of bytes to return
def seedexpander(ctx: AEX_XOF_struct, x, xlen):
    if x is None:
        return RNG_BAD_OUTBUF
    if xlen >= ctx.length_remaining:
        return RNG_BAD_REQ_LEN

    ctx.length_remaining -= xlen

    offset = 0
    while xlen > 0:
        if xlen <= (16 - ctx.buffer_pos):  # buffer has what we need
            x[offset:offset + xlen] = ctx.buffer[ctx.buffer_pos:ctx.buffer_pos + xlen]
            ctx.buffer_pos += xlen

            return RNG_SUCCESS

        # take what's in the buffer
        x[offset:offset + 16 - ctx.buffer_pos] = ctx.buffer[ctx.buffer_pos:16]
        xlen -= 16 - ctx.buffer_pos
        offset += 16 - ctx.buffer_pos

        AES256_ECB(ctx.key, ctx.ctr, ctx.buffer)
        ctx.buffer_pos = 0

        # increment the counter
        for i in range(15, 11, -1):
            if ctx.ctr[i] == 0xff:
                ctx.ctr[i] = 0x00
            else:
                ctx.ctr[i] += 1
                break

    return RNG_SUCCESS


libcrypto = ctypes.CDLL("C:/Program Files/OpenSSL-Win64/bin/libcrypto-3-x64.dll")
libcrypto.EVP_CIPHER_CTX_new.restype = ctypes.c_void_p
libcrypto.EVP_aes_256_ecb.restype = ctypes.c_void_p
libcrypto.EVP_EncryptInit_ex.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_char_p,
                                         ctypes.c_void_p]
libcrypto.EVP_EncryptUpdate.argtypes = [ctypes.c_void_p, ctypes.c_char_p, ctypes.POINTER(ctypes.c_int), ctypes.c_char_p,
                                        ctypes.c_int]
libcrypto.EVP_CIPHER_CTX_free.argtypes = [ctypes.c_void_p]


# Use whatever AES implementation you have. This uses AES from openSSL library
#      key - 256-bit AES key
#      ctr - a 128-bit plaintext value
#      buffer - a 128-bit ciphertext value
def AES256_ECB(key, ctr, buffer):
    key_b = bytes(key)
    ctr_b = bytes(ctr)
    ctx = libcrypto.EVP_CIPHER_CTX_new()
    if not ctx:
        raise Exception("Failed to create context")

    aes_256_ecb = libcrypto.EVP_aes_256_ecb()
    if not libcrypto.EVP_EncryptInit_ex(ctx, aes_256_ecb, None, key_b, None):
        libcrypto.EVP_CIPHER_CTX_free(ctx)
        raise Exception("Failed to initialize encryption")

    len = ctypes.c_int()
    if not libcrypto.EVP_EncryptUpdate(ctx, buffer, ctypes.byref(len), ctr_b, 16):
        libcrypto.EVP_CIPHER_CTX_free(ctx)
        raise Exception("Failed to encrypt")

    libcrypto.EVP_CIPHER_CTX_free(ctx)


def randombytes_init(entropy_input, personalization_string, security_strength):
    seed_material = bytearray(48)

    seed_material[:] = entropy_input[:48]

    if personalization_string:
        for i in range(48):
            seed_material[i] ^= personalization_string[i]

    DRBG_ctx.Key[:32] = bytearray(32)
    DRBG_ctx.V[:16] = bytearray(16)
    AES256_CTR_DRBG_Update(seed_material, DRBG_ctx.Key, DRBG_ctx.V)

    DRBG_ctx.reseed_counter = 1


def randombytes(x, xlen):
    block = bytearray(16)
    block_b = ctypes.create_string_buffer(16)
    # block = bytearray(16)
    i = 0

    while xlen > 0:
        # increment V
        for j in range(15, -1, -1):
            if DRBG_ctx.V[j] == 0xff:
                DRBG_ctx.V[j] = 0x00
            else:
                DRBG_ctx.V[j] += 1
                break

        AES256_ECB(DRBG_ctx.Key, DRBG_ctx.V, block_b)
        block = bytearray(block_b.raw)
        if xlen > 15:
            x[i:i + 16] = block[:16]
            i += 16
            xlen -= 16
        else:
            x[i:i + xlen] = block[:xlen]
            xlen = 0

    AES256_CTR_DRBG_Update(None, DRBG_ctx.Key, DRBG_ctx.V)
    DRBG_ctx.reseed_counter += 1

    return RNG_SUCCESS


def AES256_CTR_DRBG_Update(provided_data, Key, V):
    # AES256_CTR_DRBG_Update(seed_material, DRBG_ctx.Key, DRBG_ctx.V)
    temp = bytearray(48)
    # temp = bytearray(48)

    for i in range(3):
        # increment V
        for j in range(15, -1, -1):
            if V[j] == 0xff:
                V[j] = 0x00
            else:
                V[j] += 1
                break
        temp_b = ctypes.create_string_buffer(16)
        AES256_ECB(Key, V, temp_b)
        temp_b = bytearray(temp_b.raw)
        for k in range(16):
            temp[16 * i + k] = temp_b[k]

    if provided_data is not None:
        for i in range(48):
            temp[i] ^= provided_data[i]

    Key[:32] = temp[:32]
    V[:16] = temp[32:48]
