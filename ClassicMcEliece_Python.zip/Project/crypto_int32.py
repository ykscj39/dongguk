from gf import *


def crypto_int32_negative_mask(crypto_int32_x):
    return crypto_int32_x.value >> 31


def crypto_int32_nonzero_mask(crypto_int32_x):
    return crypto_int32_negative_mask(crypto_int32_x) | crypto_int32_negative_mask(int32_t(-crypto_int32_x.value))


def crypto_int32_zero_mask(crypto_int32_x):
    return ~crypto_int32_nonzero_mask(crypto_int32_x)


def crypto_int32_positive_mask(crypto_int32_x):
    crypto_int32_z = int32_t(-crypto_int32_x.value)
    crypto_int32_z.value ^= crypto_int32_x.value & crypto_int32_z.value
    return crypto_int32_negative_mask(crypto_int32_z)


def crypto_int32_unequal_mask(crypto_int32_x, crypto_int32_y):
    crypto_int32_xy = int32_t(crypto_int32_x.value ^ crypto_int32_y.value)
    return crypto_int32_nonzero_mask(crypto_int32_xy)


def crypto_int32_equal_mask(crypto_int32_x, crypto_int32_y):
    return ~crypto_int32_unequal_mask(crypto_int32_x, crypto_int32_y)


def crypto_int32_smaller_mask(crypto_int32_x, crypto_int32_y):
    crypto_int32_xy = int32_t(crypto_int32_x.value ^ crypto_int32_y.value)
    crypto_int32_z = int32_t(crypto_int32_x.value - crypto_int32_y.value)
    crypto_int32_z.value ^= crypto_int32_xy.value & (crypto_int32_z.value ^ crypto_int32_x.value)
    return crypto_int32_negative_mask(crypto_int32_z)


def crypto_int32_min(crypto_int32_x, crypto_int32_y):
    crypto_int32_xy = int32_t(crypto_int32_y.value ^ crypto_int32_x.value)
    crypto_int32_z = int32_t(crypto_int32_y.value - crypto_int32_x.value)
    crypto_int32_z.value ^= crypto_int32_xy.value & (crypto_int32_z.value ^ crypto_int32_y.value)
    crypto_int32_z.value = crypto_int32_negative_mask(crypto_int32_z)
    crypto_int32_z.value &= crypto_int32_xy.value
    return crypto_int32_x.value ^ crypto_int32_z.value


def crypto_int32_max(crypto_int32_x, crypto_int32_y):
    crypto_int32_xy = int32_t(crypto_int32_y.value ^ crypto_int32_x.value)
    crypto_int32_z = int32_t(crypto_int32_y.value - crypto_int32_x.value)
    crypto_int32_z.value ^= crypto_int32_xy.value & (crypto_int32_z.value ^ crypto_int32_y.value)
    crypto_int32_z.value = crypto_int32_negative_mask(crypto_int32_z)
    crypto_int32_z.value &= crypto_int32_xy.value
    return crypto_int32_y.value ^ crypto_int32_z.value


def crypto_int32_minmax(crypto_int32_a, crypto_int32_b):
    crypto_int32_x = crypto_int32_a
    crypto_int32_y = crypto_int32_b
    crypto_int32_xy = int32_t(crypto_int32_y.value ^ crypto_int32_x.value)
    crypto_int32_z = int32_t(crypto_int32_y.value - crypto_int32_x.value)
    crypto_int32_z.value ^= crypto_int32_xy.value & (crypto_int32_z.value ^ crypto_int32_y.value)
    crypto_int32_z.value = crypto_int32_negative_mask(crypto_int32_z)
    crypto_int32_z.value &= crypto_int32_xy.value
    crypto_int32_a.value = crypto_int32_x.value ^ crypto_int32_z.value
    crypto_int32_b.value = crypto_int32_y.value ^ crypto_int32_z.value
