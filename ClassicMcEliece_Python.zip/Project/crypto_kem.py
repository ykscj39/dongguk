from crypto_kem_mceliece348864 import *

crypto_kem_PUBLICKEYBYTES = crypto_kem_mceliece348864_PUBLICKEYBYTES
crypto_kem_SECRETKEYBYTES = crypto_kem_mceliece348864_SECRETKEYBYTES
crypto_kem_BYTES = crypto_kem_mceliece348864_BYTES
crypto_kem_CIPHERTEXTBYTES = crypto_kem_mceliece348864_CIPHERTEXTBYTES
crypto_kem_PRIMITIVE = "mceliece348864"
