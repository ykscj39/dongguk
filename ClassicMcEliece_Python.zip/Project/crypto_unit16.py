from gf import *


def crypto_uint16_signed_negative_mask(crypto_uint16_signed_x):
    return crypto_uint16_signed_x.value >> 15


def crypto_uint16_nonzero_mask(crypto_uint16_x):
    return crypto_uint16_signed_negative_mask(crypto_uint16_x) | crypto_uint16_signed_negative_mask(int16_t(-crypto_uint16_x.value))


def crypto_uint16_zero_mask(crypto_uint16_x):
    return int16_t(~crypto_uint16_nonzero_mask(crypto_uint16_x)).value


def crypto_uint16_unequal_mask(crypto_uint16_x, crypto_uint16_y):
    crypto_uint16_xy = gf(crypto_uint16_x.value ^ crypto_uint16_y.value)
    return crypto_uint16_nonzero_mask(crypto_uint16_xy)


def crypto_uint16_equal_mask(crypto_uint16_x, crypto_uint16_y):
    return int16_t(~crypto_uint16_unequal_mask(crypto_uint16_x, crypto_uint16_y)).value


def crypto_uint16_smaller_mask(crypto_uint16_x, crypto_uint16_y):
    crypto_uint16_xy = gf(crypto_uint16_x.value ^ crypto_uint16_y.value)
    crypto_uint16_z = gf(crypto_uint16_x.value - crypto_uint16_y.value)
    crypto_uint16_z.value ^= crypto_uint16_xy.value & (crypto_uint16_z.value ^ crypto_uint16_x.value ^ (1 << 15))
    return crypto_uint16_signed_negative_mask(crypto_uint16_z)


def crypto_uint16_min(crypto_uint16_x, crypto_uint16_y):
    crypto_uint16_xy = gf(crypto_uint16_y.value ^ crypto_uint16_x.value)
    crypto_uint16_z = gf(crypto_uint16_y.value - crypto_uint16_x.value)
    crypto_uint16_z.value ^= crypto_uint16_xy.value & (crypto_uint16_z.value ^ crypto_uint16_y.value ^ (1 << 15))
    crypto_uint16_z.value = crypto_uint16_signed_negative_mask(crypto_uint16_z)
    crypto_uint16_z.value &= crypto_uint16_xy.value
    return crypto_uint16_x.value ^ crypto_uint16_z.value


def crypto_uint16_max(crypto_uint16_x, crypto_uint16_y):
    crypto_uint16_xy = gf(crypto_uint16_y.value ^ crypto_uint16_x.value)
    crypto_uint16_z = gf(crypto_uint16_y.value - crypto_uint16_x.value)
    crypto_uint16_z.value ^= crypto_uint16_xy.value & (crypto_uint16_z.value ^ crypto_uint16_y.value ^ (1 << 15))
    crypto_uint16_z.value = crypto_uint16_signed_negative_mask(crypto_uint16_z)
    crypto_uint16_z.value &= crypto_uint16_xy.value
    return crypto_uint16_y.value ^ crypto_uint16_z.value


def crypto_uint16_minmax(crypto_uint16_a, crypto_uint16_b):
    crypto_uint16_x = crypto_uint16_a
    crypto_uint16_y = crypto_uint16_b
    crypto_uint16_xy = gf(crypto_uint16_y.value ^ crypto_uint16_x.value)
    crypto_uint16_z = gf(crypto_uint16_y.value - crypto_uint16_x.value)
    crypto_uint16_z.value ^= crypto_uint16_xy.value & (crypto_uint16_z.value ^ crypto_uint16_y.value ^ (1 << 15))
    crypto_uint16_z.value = crypto_uint16_signed_negative_mask(crypto_uint16_z)
    crypto_uint16_z.value &= crypto_uint16_xy.value
    crypto_uint16_a.value = crypto_uint16_x.value ^ crypto_uint16_z.value
    crypto_uint16_b.value = crypto_uint16_y.value ^ crypto_uint16_z.value
