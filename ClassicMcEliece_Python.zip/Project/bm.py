"""
This file is for the Berlekamp-Massey algorithm
  see http://crypto.stanford.edu/~mironov/cs359/massey.pdf
"""

from gf import *

"""
the Berlekamp-Massey algorithm
input: s, sequence of field elements
output: out, minimal polynomial of s
"""


def bm(out, s):
    N = gf(0)
    L = gf(0)
    mle = gf()
    mne = gf()

    T = (gf * (SYS_T + 1))()
    C = (gf * (SYS_T + 1))()
    B = (gf * (SYS_T + 1))()

    b = gf(1)
    d = gf()
    f = gf()

    for i in range(SYS_T + 1):
        C[i] = B[i] = 0

    B[1] = C[0] = 1

    for N.value in range(2 * SYS_T):
        d.value = 0

        for i in range(min(N.value, SYS_T) + 1):
            d.value ^= gf_mul(gf(C[i]), gf(s[N.value - i]))

        mne.value = d.value
        mne.value -= 1
        mne.value >>= 15
        mne.value -= 1
        mle.value = N.value
        mle.value -= 2 * L.value
        mle.value >>= 15
        mle.value -= 1
        mle.value &= mne.value

        for i in range(SYS_T + 1):
            T[i] = C[i]

        f = gf_frac(b, d)

        for i in range(SYS_T + 1):
            C[i] ^= gf_mul(f, gf(B[i])) & mne.value

        L.value = (L.value & ~mle.value) | ((N.value + 1 - L.value) & mle.value)

        for i in range(SYS_T + 1):
            B[i] = (B[i] & ~mle.value) | (T[i] & mle.value)

        b.value = (b.value & ~mle.value) | (d.value & mle.value)

        for i in range(SYS_T, 0, -1):
            B[i] = B[i - 1]
        B[0] = 0

    for i in range(SYS_T + 1):
        out[i] = C[SYS_T - i]

