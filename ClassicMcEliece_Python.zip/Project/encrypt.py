from util import *
from randombytes import *
from crypto_declassify import *
from crypto_unit16 import *
from crypto_uint32 import *


def uint16_is_smaller_declassify(t, u):
    mask = gf(crypto_uint16_smaller_mask(t, u))
    crypto_declassify(mask, ctypes.sizeof(mask))
    return mask


def uint32_is_equal_declassify(t, u):
    mask = uint32_t(crypto_uint32_equal_mask(t, u))
    crypto_declassify(mask, ctypes.sizeof(mask))
    return mask


def same_mask(x, y):
    mask = uint32_t()

    mask.value = (x.value ^ y.value)
    mask.value -= 1
    mask.value >>= 31
    mask.value = -mask.value
    return mask.value & 0xFF


class BufStructure(ctypes.Union):
    _fields_ = [
        ("nums", ctypes.c_uint16 * (SYS_T * 2)),
        ("bytes", ctypes.c_ubyte * (SYS_T * 2 * ctypes.sizeof(ctypes.c_uint16)))
    ]


# output: e, an error vector of weight t
def gen_e(e):
    buf = BufStructure()
    ind = (gf * SYS_T)()
    mask = bytearray()
    val = bytearray(SYS_T)

    while True:
        randombytes(buf.bytes, ctypes.sizeof(buf))

        for i in range(SYS_T * 2):
            buf.nums[i] = load_gf(buf.bytes[i * 2:])

        # moving and counting indices in the correct range
        i = 0
        count = 0
        while i < SYS_T * 2 and count < SYS_T:
            if uint16_is_smaller_declassify(gf(buf.nums[i]), gf(SYS_N)):
                ind[count] = buf.nums[i]
                count += 1
            i += 1

        if count < SYS_T:
            continue

        # Check for repetition
        eq = 0
        for i in range(1, SYS_T):
            for j in range(i):
                if uint32_is_equal_declassify(uint32_t(ind[i]), uint32_t(ind[j])):
                    eq = 1

        if eq == 0:
            break

    for j in range(SYS_T):
        val[j] = 1 << (ind[j] & 7)

    for i in range(SYS_N // 8):
        e[i] = 0
        for j in range(SYS_T):
            mask = same_mask(gf(i), gf((ind[j] >> 3)))
            e[i] |= val[j] & mask


"""
input: public key pk, error vector e 
output: syndrome s 
"""


def syndrome(s, pk, e):
    b = bytearray()
    row = bytearray(SYS_N // 8)

    pk_ptr = pk

    for i in range(SYND_BYTES):
        s[i] = 0

    for i in range(PK_NROWS):
        for j in range(SYS_N // 8):
            row[j] = 0

        for j in range(PK_ROW_BYTES):
            row[SYS_N // 8 - PK_ROW_BYTES + j] = pk_ptr[j]

        row[i // 8] |= 1 << (i % 8)

        b = 0
        for j in range(SYS_N // 8):
            b ^= row[j] & e[j]

        b ^= b >> 4
        b ^= b >> 2
        b ^= b >> 1
        b &= 1

        s[i // 8] |= (b << (i % 8))

        pk_ptr = pk_ptr[PK_ROW_BYTES:]


def encrypt(s, pk, e):
    gen_e(e)

    # kat_enabled = True
    #
    # if kat_enabled:
    #     print("encrypt e: positions", end="")
    #     for k in range(SYS_N):
    #         if e[k // 8] & (1 << (k & 7)):
    #             print(k, end=" ")
    #     print()

    syndrome(s, pk, e)
