from crypto_declassify import *
from crypto_unit16 import *
import ctypes


def gf_is_zero_declassify(t):
    # print("t=", t.value)
    mask = gf(crypto_uint16_zero_mask(t))
    # print("mask=", mask.value)
    crypto_declassify(mask, ctypes.sizeof(mask))
    return mask


"""
input: f, element in GF((2^m)^t) 
output: out, minimal polynomial of f 
return: 0 for success and -1 for failure 
"""


def genpoly_gen(out, f):
    mat = (gf * SYS_T * (SYS_T + 1))()
    for i in range(SYS_T + 1):
        for j in range(SYS_T):
            mat[i][j] = 0

    mask = gf()
    inv = gf()
    t = gf()

    # fill matrix
    mat[0][0] = 1

    for i in range(1, SYS_T):
        mat[0][i] = 0

    for i in range(SYS_T):
        mat[1][i] = f[i]

    for j in range(2, SYS_T + 1):
        GF_mul(mat[j], mat[j - 1], f)

    # gaussian
    for j in range(SYS_T):
        for k in range(j + 1, SYS_T):
            mask = gf_iszero(gf(mat[j][j]))
            # print("mask=",mask.value)

            for c in range(j, SYS_T + 1):
                mat[c][j] ^= mat[c][k] & mask.value
        # print("mat[", j, "][", j, "]=", mat[j][j])
        if gf_is_zero_declassify(gf(mat[j][j])):  # Return if not systematic
            return -1

        inv = gf_inv(gf(mat[j][j]))

        for c in range(j, SYS_T + 1):
            mat[c][j] = gf_mul(gf(mat[c][j]), inv)

        for k in range(SYS_T):
            if k != j:
                t.value = mat[j][k]

                for c in range(j, SYS_T + 1):
                    mat[c][k] ^= gf_mul(gf(mat[c][j]), t)

    for i in range(SYS_T):
        out[i] = mat[SYS_T][i]

    return out, f

