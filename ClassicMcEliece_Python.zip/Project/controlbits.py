"""
 This file is for implementing the Nassimi-Sahni algorithm
 See David Nassimi, Sartaj Sahni "Parallel algorithms to set up the Benes permutationnetwork"
 See also https://cr.yp.to/papers/controlbits-20200923.pdf
"""
from crypto_declassify import *
from crypto_int32 import *
from crypto_int16 import *
from int32_sort import *
from gf import *

"""
parameters: 1 <= w <= 14; n = 2^w 
input: permutation pi of {0,1,...,n-1} 
output: (2m-1)n/2 control bits at positions pos,pos+step,... 
output position pos is by definition 1&(out[pos/8]>>(pos&7)) 
caller must 0-initialize positions first 
temp must have space for int32[2*n] 
"""


def cbrecursion(out, pos, step, pi, w, n, temp):
    B = (int32_t * len(temp[n:]))()
    for i in range(len(B)):
        B[i] = temp[n + i]

    q = (uint16_t * (2 * len(temp[n + n // 4:])))()  # q can start anywhere between temp+n and temp+n/2
    for i in range(len(q) // 2):
        q[2 * i] = temp[n + n // 4 + i] & 0x0000ffff
        q[2 * i + 1] = (temp[n + n // 4 + i] >> 16) & 0x0000ffff

    if w == 1:
        out[pos >> 3] ^= pi[0] << (pos & 7)
        return

    for x in range(n):
        temp[x] = ((pi[x] ^ 1) << 16) | pi[x ^ 1]

    int32_sort_test(temp, n)

    for x in range(n):
        Ax = int32_t(temp[x])
        px = int32_t(Ax.value & 0xffff)
        cx = int32_t(crypto_int32_min(px, int32_t(x)))
        B[x] = (px.value << 16) | cx.value
        temp[n + x] = B[x]

    for x in range(n):
        temp[x] = (temp[x] << 16) | x
    int32_sort_test(temp, n)

    for x in range(n):
        temp[x] = (temp[x] << 16) + (B[x] >> 16)
    int32_sort_test(temp, n)

    if w <= 10:
        for x in range(n):
            B[x] = ((temp[x] & 0xffff) << 10) | (B[x] & 0x3ff)
            temp[n + x] = B[x]

        for i in range(1, w - 1):

            for x in range(n):
                temp[x] = ((B[x] & ~0x3ff) << 6) | x
            int32_sort_test(temp, n)

            for x in range(n):
                temp[x] = (temp[x] << 20) | B[x]
            int32_sort_test(temp, n)

            for x in range(n):
                ppcpx = int32_t(temp[x] & 0xfffff)
                ppcx = int32_t((temp[x] & 0xffc00) | (B[x] & 0x3ff))
                B[x] = crypto_int32_min(ppcx, ppcpx)
                temp[n + x] = B[x]

        for x in range(n):
            B[x] &= 0x3ff
            temp[n + x] = B[x]

    else:
        for x in range(n):
            B[x] = (temp[x] << 16) | (B[x] & 0xffff)
            temp[n + x] = B[x]

        for i in range(1, w - 1):

            for x in range(n):
                temp[x] = (B[x] & ~0xffff) | x
            int32_sort_test(temp, n)

            for x in range(n):
                temp[x] = (temp[x] << 16) | (B[x] & 0xffff)

            if i < w - 2:
                for x in range(n):
                    B[x] = (temp[x] & ~0xffff) | (B[x] >> 16)
                    temp[n + x] = B[x]
                # B = (p^(-1)<<16)+p

                int32_sort_test(B, n)  # B = (id<<16)+p^(-2)
                for i in range(len(B)):
                    temp[n + i] = B[i]

                for x in range(n):
                    B[x] = (B[x] << 16) | (temp[x] & 0xffff)
                    temp[n + x] = B[x]
                # B = (p^(-2)<<16)+c

            int32_sort_test(temp, n)

            for x in range(n):
                cpx = int32_t((B[x] & ~0xffff) | (temp[x] & 0xffff))
                B[x] = crypto_int32_min(int32_t(B[x]), cpx)
                temp[n + x] = B[x]

        for x in range(n):
            B[x] &= 0xffff
            temp[n + x] = B[x]

    for x in range(n):
        temp[x] = ((int32_t(pi[x]).value << 16) + x)
    int32_sort_test(temp, n)

    for j in range(n // 2):
        x = 2 * j
        fj = int32_t(B[x] & 1)  # f[j]

        Fx = int32_t(x + fj.value)  # F[x]
        Fx1 = int32_t(Fx.value ^ 1)  # F[x+1]

        out[pos >> 3] ^= fj.value << (pos & 7)

        pos += step

        B[x] = (temp[x] << 16) | Fx.value
        temp[n + x] = B[x]
        B[x + 1] = (temp[x + 1] << 16) | Fx1.value
        temp[n + x + 1] = B[x + 1]

    int32_sort_test(B, n)  # B = (id<<16)+F(pi)

    for i in range(len(B)):
        temp[n + i] = B[i]

    pos += (2 * w - 3) * step * (n // 2)

    for k in range(n // 2):
        y = 2 * k
        lk = int32_t(B[y] & 1)  # l[k]
        Ly = int32_t(y + lk.value)  # L[y]
        Ly1 = int32_t(Ly.value ^ 1)  # L[y+1]

        out[pos >> 3] ^= lk.value << (pos & 7)
        pos += step

        temp[y] = (Ly.value << 16) | (B[y] & 0xffff)
        temp[y + 1] = (Ly1.value << 16) | (B[y + 1] & 0xffff)

    int32_sort_test(temp, n)

    pos -= (2 * w - 2) * step * (n // 2)

    for j in range(n // 2):
        q[j] = (temp[2 * j] & 0xffff) >> 1
        if j % 2 == 0:
            temp[n + n // 4 + j // 2] = temp[n + n // 4 + j // 2] & 0xffff0000 | q[j]
        else:
            temp[n + n // 4 + j // 2] = (q[j] << 16) | (temp[n + n // 4 + j // 2] & 0x0000ffff)

        q[j + n // 2] = (temp[2 * j + 1] & 0xffff) >> 1
        if (j + n // 2) % 2 == 0:
            temp[n + n // 4 + (j + n // 2) // 2] = temp[n + n // 4 + (j + n // 2) // 2] & 0xffff0000 | q[j + n // 2]
        else:
            temp[n + n // 4 + (j + n // 2) // 2] = (q[j + n // 2] << 16) | (
                    temp[n + n // 4 + (j + n // 2) // 2] & 0x0000ffff)

    cbrecursion(out, pos, step * 2, q, w - 1, n // 2, temp)
    cbrecursion(out, pos + step, step * 2, q[n // 2:], w - 1, n // 2, temp)


"""
input: p, an array of int16 
input: n, length of p 
input: s, meaning that stride-2^s cswaps are performed 
input: cb, the control bits 
output: the result of apply the control bits to p 
"""


def layer(p, cb, s, n):
    stride = 1 << s
    index = 0
    d = int16_t()
    m = int16_t()

    for i in range(0, n, stride * 2):
        for j in range(stride):
            d.value = p[i + j] ^ p[i + j + stride]
            m.value = (cb[index >> 3] >> (index & 7)) & 1
            m.value = -m.value
            d.value &= m.value
            p[i + j] ^= d.value
            p[i + j + stride] ^= d.value
            index += 1


"""
parameters: 1 <= w <= 14; n = 2^w 
input: permutation pi of {0,1,...,n-1} 
output: (2m-1)n/2 control bits at positions 0,1,... 
output position pos is by definition 1&(out[pos/8]>>(pos&7)) 
"""


def controlbitsfrompermutation(out, pi, w, n):
    temp = (int32_t * (2 * n))()
    pi_test = (int16_t * n)()
    diff = int16_t()

    ptr = bytearray()

    while True:
        length_out = (((2 * w - 1) * n // 2) + 7) // 8
        out[: length_out] = bytearray([0] * length_out)
        cbrecursion(out, 0, 1, pi, w, n, temp)

        # check for correctness
        for i in range(n):
            pi_test[i] = i

        pos = 0
        ptr = out
        for i in range(w):
            layer(pi_test, ptr[pos * (n >> 4):], i, n)
            # ptr = ptr[n >> 4:]
            pos += 1

        for i in range(w - 2, -1, -1):
            layer(pi_test, ptr[pos * (n >> 4):], i, n)
            pos += 1  # ptr = ptr[n >> 4:]

        out = ptr

        diff.value = 0
        for i in range(n):
            diff.value |= pi[i] ^ pi_test[i]

        diff.value = crypto_int16_nonzero_mask(diff)
        crypto_declassify(diff, ctypes.sizeof(diff))

        if diff.value == 0:
            break

    return out
