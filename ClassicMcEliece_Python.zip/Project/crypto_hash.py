# -*- coding: utf-8 -*-
# Implementation by Gilles Van Assche, hereby denoted as "the implementer".
#
# For more information, feedback or questions, please refer to our website:
# https://keccak.team/
#
# To the extent possible under law, the implementer has waived all copyright
# and related or neighboring rights to the source code in this file.
# http://creativecommons.org/publicdomain/zero/1.0/


from Cryptodome.Hash import SHAKE256


def crypto_hash_32b(output, input, inlen):
    shake1 = SHAKE256.new()
    input_byte = bytes(input)
    shake1.update(input_byte[: inlen])
    hash_output = shake1.read(32)

    for i in range(32):
        output[i] = hash_output[i]
    return output


def shake(output, outlen, input, inlen):
    shake1 = SHAKE256.new()
    input_byte = bytes(input)
    shake1.update(input_byte[:inlen])
    hash_output = shake1.read(outlen)

    for i in range(outlen):
        output[i] = hash_output[i]
    return output
