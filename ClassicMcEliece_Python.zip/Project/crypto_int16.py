from gf import *


def crypto_int16_negative_mask(crypto_int16_x):
    return crypto_int16_x.value >> 15


def crypto_int16_nonzero_mask(crypto_int16_x):
    return crypto_int16_negative_mask(crypto_int16_x) | crypto_int16_negative_mask(int16_t(-crypto_int16_x.value))


def crypto_int16_zero_mask(crypto_int16_x):
    return ~crypto_int16_nonzero_mask(crypto_int16_x)


def crypto_int16_positive_mask(crypto_int16_x):
    crypto_int16_z = int16_t(-crypto_int16_x.value)
    crypto_int16_z.value ^= crypto_int16_x.value & crypto_int16_z.value
    return crypto_int16_negative_mask(crypto_int16_z)


def crypto_int16_unequal_mask(crypto_int16_x, crypto_int16_y):
    crypto_int16_xy = int16_t(crypto_int16_x.value ^ crypto_int16_y.value)
    return crypto_int16_nonzero_mask(crypto_int16_xy)


def crypto_int16_equal_mask(crypto_int16_x, crypto_int16_y):
    return ~crypto_int16_unequal_mask(crypto_int16_x, crypto_int16_y)


def crypto_int16_smaller_mask(crypto_int16_x, crypto_int16_y):
    crypto_int16_xy = int16_t(crypto_int16_x.value ^ crypto_int16_y.value)
    crypto_int16_z = int16_t(crypto_int16_x.value - crypto_int16_y.value)
    crypto_int16_z.value ^= crypto_int16_xy.value & (crypto_int16_z.value ^ crypto_int16_x.value)
    return crypto_int16_negative_mask(crypto_int16_z)


def crypto_int16_min(crypto_int16_x, crypto_int16_y):
    crypto_int16_xy = int16_t(crypto_int16_y.value ^ crypto_int16_x.value)
    crypto_int16_z = int16_t(crypto_int16_y.value - crypto_int16_x.value)
    crypto_int16_z.value ^= crypto_int16_xy.value & (crypto_int16_z.value ^ crypto_int16_y.value)
    crypto_int16_z.value = crypto_int16_negative_mask(crypto_int16_z)
    crypto_int16_z.value &= crypto_int16_xy.value
    return crypto_int16_x.value ^ crypto_int16_z.value


def crypto_int16_max(crypto_int16_x, crypto_int16_y):
    crypto_int16_xy = int16_t(crypto_int16_y.value ^ crypto_int16_x.value)
    crypto_int16_z = int16_t(crypto_int16_y.value - crypto_int16_x.value)
    crypto_int16_z.value ^= crypto_int16_xy.value & (crypto_int16_z.value ^ crypto_int16_y.value)
    crypto_int16_z.value = crypto_int16_negative_mask(crypto_int16_z)
    crypto_int16_z.value &= crypto_int16_xy.value
    return crypto_int16_y.value ^ crypto_int16_z.value


def crypto_int16_minmax(crypto_int16_a, crypto_int16_b):
    crypto_int16_x = crypto_int16_a
    crypto_int16_y = crypto_int16_b
    crypto_int16_xy = int16_t(crypto_int16_y.value ^ crypto_int16_x.value)
    crypto_int16_z = int16_t(crypto_int16_y.value - crypto_int16_x.value)
    crypto_int16_z.value ^= crypto_int16_xy.value & (crypto_int16_z.value ^ crypto_int16_y.value)
    crypto_int16_z.value = crypto_int16_negative_mask(crypto_int16_z)
    crypto_int16_z.value &= crypto_int16_xy.value
    crypto_int16_a.value = crypto_int16_x.value ^ crypto_int16_z.value
    crypto_int16_b.value = crypto_int16_y.value ^ crypto_int16_z.value
