from gf import *


def int32_MINMAX(a, b):
    ab = int32_t(b ^ a)
    c = int32_t(b - a)
    c.value ^= ab.value & (c.value ^ b)
    c.value >>= 31
    c.value &= ab.value
    a ^= c.value
    b ^= c.value


def int32_sort(x, n):
    if n < 2:
        return

    top = 1
    while top < n - top:
        top += top

    p = top
    while p > 0:
        for i in range(n - p):
            if not (i & p):
                int32_MINMAX(x[i], x[i + p])
        i = 0
        q = top
        while q > p:
            while i < n - q:
                if not (i & p):
                    a = int32_t(x[i + p])
                    r = q
                    while r > p:
                        int32_MINMAX(a.value, x[i + r])
                        r >>= 1
                    x[i + p] = a.value
                i += 1
            q >>= 1
        p >>= 1


def int32_sort_test(x, n):
    if n < 2:
        return

    top = 1
    while top < n - top:
        top += top

    p = top
    while p > 0:
        for i in range(n - p):
            if not (i & p):
                # x[i], x[i + p] = int32_MINMAX_test(temp[i], temp[i + p])
                ab = x[i + p] ^ x[i]
                c = x[i + p] - x[i]
                c ^= ab & (c ^ x[i + p])
                c >>= 31
                c &= ab
                x[i] ^= c
                x[i + p] ^= c
                # av, bv = int32_MINMAX_test(x[i], x[i + p])
                # x[i] = av
                # x[i+p] = bv
        i = 0
        q = top
        while q > p:
            while i < n - q:
                if not (i & p):
                    a = x[i + p]
                    r = q
                    while r > p:
                        # a, temp[i + r] = int32_MINMAX_test(a, temp[i + r])
                        ab = x[i + r] ^ a
                        c = x[i + r] - a
                        c ^= ab & (c ^ x[i + r])
                        c >>= 31
                        c &= ab
                        a ^= c
                        x[i + r] ^= c
                        # av, bv = int32_MINMAX_test(a, x[i + r])
                        # a = av
                        # x[i + r] = bv
                        r >>= 1
                    x[i + p] = a
                i += 1
            q >>= 1
        p >>= 1
    # return x
