# This file is for Niederreiter decryption

from benes import *
from util import *
from synd import *
from root import *
from bm import *

"""
Niederreiter decryption with the Berlekamp decoder 
intput: sk, secret key 
         c, ciphertext 
output: e, error vector 
return: 0 for success; 1 for failure 
"""


def decrypt(e, sk, c):
    w = 0
    check = gf()

    r = bytearray(SYS_N // 8)

    g = (gf * (SYS_T + 1))()
    L = (gf * SYS_N)()
    s = (gf * (SYS_T * 2))()
    s_cmp = (gf * (SYS_T * 2))()
    locator = (gf * (SYS_T + 1))()
    images = (gf * SYS_N)()

    t = gf()

    for i in range(SYND_BYTES):
        r[i] = c[i]

    for i in range(SYND_BYTES, SYS_N // 8):
        r[i] = 0

    for i in range(SYS_T):
        g[i] = load_gf(sk[i * 2:])
        # sk = sk[2:]
    g[SYS_T] = 1

    support_gen(L, sk[SYS_T*2:])

    synd(s, g, L, r)

    bm(locator, s)

    root(images, locator, L)

    for i in range(SYS_N // 8):
        e[i] = 0

    for i in range(SYS_N):
        t.value = gf_iszero(gf(images[i])).value & 1
        e[i // 8] |= t.value << (i % 8)
        w += t.value

    # KAT = True
    #
    # if KAT:
    #     print("decrypt e: positions ", end='')
    #     for k in range(SYS_N):
    #         if e[k // 8] & (1 << (k & 7)):
    #             print(k, end=' ')
    #     print()

    synd(s_cmp, g, L, e)

    check.value = w
    check.value ^= SYS_T

    for i in range(SYS_T * 2):
        check.value |= s[i] ^ s_cmp[i]

    check.value -= 1
    check.value >>= 15

    return check.value ^ 1
