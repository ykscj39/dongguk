from gf import *


def uint64_MINMAX(a: uint64_t, b: uint64_t):
    c = uint64_t(b.value - a.value)
    c.value >>= 63
    c.value = -c.value
    c.value &= a.value ^ b.value
    a.value ^= c.value
    b.value ^= c.value

    return a.value, b.value


def uint64_sort(x, n):
    if n < 2:
        return

    top = 1
    while top < n - top:
        top += top

    p = top
    while p > 0:
        for i in range(n - p):
            if not (i & p):
                x[i], x[i + p] = uint64_MINMAX(uint64_t(x[i]), uint64_t(x[i + p]))

        i = 0
        q = top

        while q > p:
            while i < (n - q):
                if not (i & p):
                    a = uint64_t(x[i + p])

                    r = q
                    while r > p:
                        a.value, x[i + r] = uint64_MINMAX(a, uint64_t(x[i + r]))
                        r >>= 1
                    x[i + p] = a.value
                i += 1
            q >>= 1
        p >>= 1
