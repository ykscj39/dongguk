# This file is for evaluating a polynomial at one or more field elements

from gf import *

"""
input: polynomial f and field element a 
return f(a) 
"""


def eval(f, a):
    r = gf()
    r.value = f[SYS_T]

    for i in range(SYS_T - 1, -1, -1):
        r.value = gf_mul(r, a)
        r = gf_add(r, gf(f[i]))

    return r


"""
input: polynomial f and list of field elements L 
output: out = [ f(a) for a in L ] 
"""


def root(out, f, L):
    for i in range(SYS_N):
        out[i] = eval(f, gf(L[i])).value
