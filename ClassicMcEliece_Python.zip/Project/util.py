# This file is for loading/storing data in a little-endian fashion
from gf import *
from params import *


def store_gf(dest, a):
    dest[0] = a.value & 0xFF
    dest[1] = a.value >> 8
    return dest


def load_gf(src):
    a = gf()
    a.value = src[1]
    a.value <<= 8
    a.value |= src[0]
    return a.value & GFMASK


def load4(in_bytes):
    ret = uint32_t(in_bytes[3])
    for i in range(2, -1, -1):
        ret.value = (ret.value << 8)
        ret.value |= in_bytes[i]
    return ret


def store8(out, in_val):
    out[0] = (in_val.value >> 0x00) & 0xFF
    out[1] = (in_val.value >> 0x08) & 0xFF
    out[2] = (in_val.value >> 0x10) & 0xFF
    out[3] = (in_val.value >> 0x18) & 0xFF
    out[4] = (in_val.value >> 0x20) & 0xFF
    out[5] = (in_val.value >> 0x28) & 0xFF
    out[6] = (in_val.value >> 0x30) & 0xFF
    out[7] = (in_val.value >> 0x38) & 0xFF
    return out


def load8(in_bytes):
    ret = uint64_t(in_bytes[7])
    for i in range(6, -1, -1):
        ret.value = (ret.value << 8)
        ret.value |= in_bytes[i]
    return ret


def bitrev(a):
    a.value = ((a.value & 0x00FF) << 8) | ((a.value & 0xFF00) >> 8)
    a.value = ((a.value & 0x0F0F) << 4) | ((a.value & 0xF0F0) >> 4)
    a.value = ((a.value & 0x3333) << 2) | ((a.value & 0xCCCC) >> 2)
    a.value = ((a.value & 0x5555) << 1) | ((a.value & 0xAAAA) >> 1)
    return a.value >> 4
