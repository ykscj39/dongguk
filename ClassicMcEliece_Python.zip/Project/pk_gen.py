# This file is for public-key generation

from unit64_sort import *
from root import *
from util import *
from crypto_declassify import *
from crypto_uint64 import *
import ctypes


def uint64_is_equal_declassify(t, u):
    mask = uint64_t(crypto_uint64_equal_mask(t, u))
    crypto_declassify(mask, ctypes.sizeof(mask))
    return mask


def uint64_is_zero_declassify(t):
    # print("t=", t)
    mask = uint64_t(crypto_uint64_zero_mask(t))
    # print("mask=", mask)
    crypto_declassify(mask, ctypes.sizeof(mask))
    return mask


"""
input: secret key sk 
output: public key pk 
"""


def pk_gen(pk, sk, perm, pi):
    buf = (uint64_t * (1 << GFBITS))()

    mat = [bytearray(SYS_N // 8) for _ in range(PK_NROWS)]
    mask = bytearray()
    b = bytearray()

    g = (gf * (SYS_T + 1))()
    L = (gf * SYS_N)()
    inv = (gf * SYS_N)()

    g[SYS_T] = 1

    for i in range(SYS_T):
        g[i] = load_gf(sk[i * 2:])

    # buf = np.zeros(1 << GFBITS, dtype=np.uint64)
    for i in range(1 << GFBITS):
        buf[i] = perm[i]
        buf[i] <<= 31
        buf[i] |= i

    uint64_sort(buf, 1 << GFBITS)

    for i in range(1, 1 << GFBITS):
        if uint64_is_equal_declassify(uint64_t(buf[i - 1] >> 31), uint64_t(buf[i] >> 31)):
            return -1

    for i in range(1 << GFBITS):
        pi[i] = buf[i] & GFMASK

    for i in range(SYS_N):
        L[i] = bitrev(gf(pi[i]))

    root(inv, g, L)

    for i in range(SYS_N):
        inv[i] = gf_inv(gf(inv[i])).value

    for i in range(PK_NROWS):
        for j in range(SYS_N // 8):
            mat[i][j] = 0

    for i in range(SYS_T):
        for j in range(0, SYS_N, 8):
            for k in range(GFBITS):
                b = ((inv[j + 7] >> k) & 1)
                b <<= 1
                b |= ((inv[j + 6] >> k) & 1)
                b <<= 1
                b |= ((inv[j + 5] >> k) & 1)
                b <<= 1
                b |= ((inv[j + 4] >> k) & 1)
                b <<= 1
                b |= ((inv[j + 3] >> k) & 1)
                b <<= 1
                b |= ((inv[j + 2] >> k) & 1)
                b <<= 1
                b |= ((inv[j + 1] >> k) & 1)
                b <<= 1
                b |= (inv[j + 0] >> k) & 1

                # print("b=", b)

                mat[i * GFBITS + k][j // 8] = b
                # print(f"mat[{i * GFBITS + k}][{j // 8}]={mat[i * GFBITS + k][j // 8]}")

        for j in range(SYS_N):
            inv[j] = gf_mul(gf(inv[j]), gf(L[j]))

    # gaussian elimination
    for i in range(((PK_NROWS + 7) // 8)):
        for j in range(8):
            row = i * 8 + j

            if row >= PK_NROWS:
                break

            for k in range(row + 1, PK_NROWS):
                mask = mat[row][i] ^ mat[k][i]
                mask >>= j
                mask &= 1
                mask = -mask

                for c in range(SYS_N // 8):
                    mat[row][c] ^= mat[k][c] & mask

            # print("mat[", row, "][", i, "]=", mat[row][i])
            if uint64_is_zero_declassify(uint64_t((mat[row][i] >> j) & 1)):
                return -1

            for k in range(PK_NROWS):
                if k != row:
                    mask = mat[k][i] >> j
                    mask &= 1
                    mask = -mask

                    for c in range(SYS_N // 8):
                        mat[k][c] ^= mat[row][c] & mask

    for i in range(PK_NROWS):
        pk[i * PK_ROW_BYTES: (i + 1) * PK_ROW_BYTES] = mat[i][PK_NROWS // 8: PK_NROWS // 8 + PK_ROW_BYTES]
