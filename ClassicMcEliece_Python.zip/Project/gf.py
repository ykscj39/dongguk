# This file is for functions for field arithmetic

from params import *
import ctypes

gf = ctypes.c_uint16
uint16_t = ctypes.c_uint16
uint32_t = ctypes.c_uint32
uint64_t = ctypes.c_uint64
int32_t = ctypes.c_int32
int16_t = ctypes.c_int16
int64_t = ctypes.c_int64


def gf_iszero(a):
    t = uint32_t(a.value)
    t.value -= 1
    t.value >>= 19
    return gf(t.value)


def gf_add(in0, in1):
    return gf(in0.value ^ in1.value)


def gf_mul(in0, in1):
    t0 = uint32_t(in0.value)
    t1 = uint32_t(in1.value)

    tmp = uint32_t(t0.value * (t1.value & 1))

    for i in range(1, GFBITS):
        tmp.value ^= (t0.value * (t1.value & (1 << i)))

    t = uint32_t(tmp.value & 0x7FC000)
    tmp.value ^= t.value >> 9
    tmp.value ^= t.value >> 12

    t.value = tmp.value & 0x3000
    tmp.value ^= t.value >> 9
    tmp.value ^= t.value >> 12

    return tmp.value & ((1 << GFBITS) - 1)


# input: field element in
# return: in^2
def gf_sq(in_val):
    B = (uint32_t * 4)(0x55555555, 0x33333333, 0x0F0F0F0F, 0x00FF00FF)

    x = uint32_t(in_val.value)
    t = uint32_t()

    x.value = (x.value | (x.value << 8)) & (B[3])
    x.value = (x.value | (x.value << 4)) & (B[2])
    x.value = (x.value | (x.value << 2)) & (B[1])
    x.value = (x.value | (x.value << 1)) & (B[0])

    t.value = x.value & 0x7FC000
    x.value ^= t.value >> 9
    x.value ^= t.value >> 12

    t.value = x.value & 0x3000
    x.value ^= t.value >> 9
    x.value ^= t.value >> 12

    return x.value & ((1 << GFBITS) - 1)


def gf_inv(in_val):
    out = gf(in_val.value)

    out.value = gf_sq(out)
    tmp_11 = gf(gf_mul(out, in_val))  # 11

    out.value = gf_sq(tmp_11)
    out.value = gf_sq(out)
    tmp_1111 = gf(gf_mul(out, tmp_11))  # 1111

    out.value = gf_sq(tmp_1111)
    out.value = gf_sq(out)
    out.value = gf_sq(out)
    out.value = gf_sq(out)
    out.value = gf_mul(out, tmp_1111)  # 11111111

    out.value = gf_sq(out)
    out.value = gf_sq(out)
    out.value = gf_mul(out, tmp_11)  # 1111111111

    out.value = gf_sq(out)
    out.value = gf_mul(out, in_val)  # 11111111111

    return uint32_t(gf_sq(out))  # 111111111110


# input: field element den, num
# return: (num/den)
def gf_frac(den, num):
    inv_den = gf_inv(den)
    return gf(gf_mul(inv_den, num))


# input: in0, in1 in GF((2^m)^t)
# output: out = in0*in1
def GF_mul(out, in0, in1):
    prod = (gf * (SYS_T * 2 - 1))()

    for i in range(SYS_T * 2 - 1):
        prod[i] = 0

    for i in range(SYS_T):
        for j in range(SYS_T):
            prod[i + j] ^= gf_mul(gf(in0[i]), gf(in1[j]))

    for i in range((SYS_T - 1) * 2, SYS_T - 1, -1):
        prod[i - SYS_T + 3] ^= prod[i]
        prod[i - SYS_T + 1] ^= prod[i]
        prod[i - SYS_T + 0] ^= gf_mul(gf(prod[i]), gf(2))

    for i in range(SYS_T):
        out[i] = prod[i]
