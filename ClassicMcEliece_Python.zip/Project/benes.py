"""
This file is for the Berlekamp-Massey algorithm
For the implementation strategy, see
   http://crypto.stanford.edu/~mironov/cs359/massey.pdf
"""
from util import *
import transpose
from gf import *


# one layer of the benes network
def layer(data, bits, lgs):
    d = uint64_t()

    s = 1 << lgs
    pos = 0
    for i in range(0, 64, s * 2):
        for j in range(i, i + s):
            d.value = (data[j + 0] ^ data[j + s])
            d.value = (d.value & bits[pos])
            data[j + 0] = data[j + 0] ^ d.value
            data[j + s] = data[j + s] ^ d.value
            pos += 1


# input: r, sequence of bits to be permuted
#        bits, condition bits of the Benes network
#        rev, 0 for normal application; !0 for inverse
# output: r, permuted bits
def apply_benes(r, bits, rev):
    cond_ptr = bytearray()

    bs = (uint64_t * 64)()
    cond = (uint64_t * 64)()

    for i in range(64):
        bs[i] = load8(r[i * 8:]).value

    if rev == 0:
        inc = 256
        cond_ptr = bits
    else:
        inc = -256
        cond_ptr = bits[(2 * GFBITS - 2) * 256:]

    transpose.transpose_64x64(bs, bs)

    for low in range(6):
        for i in range(64):
            cond[i] = load4(cond_ptr[low * inc + i * 4:]).value
        transpose.transpose_64x64(cond, cond)
        layer(bs, cond, low)

    transpose.transpose_64x64(bs, bs)

    for low in range(6):
        for i in range(32):
            cond[i] = load8(cond_ptr[6 + low * inc + i * 8:]).value
        layer(bs, cond, low)

    for low in range(4, -1, -1):
        for i in range(32):
            cond[i] = load8(cond_ptr[12 + abs(low - 4) * inc + i * 8:]).value
        layer(bs, cond, low)

    transpose.transpose_64x64(bs, bs)

    for low in range(5, -1, -1):
        for i in range(64):
            cond[i] = load4(cond_ptr[17 + abs(low - 5) * inc + i * 4:]).value
        transpose.transpose_64x64(cond, cond)
        layer(bs, cond, low)

    transpose.transpose_64x64(bs, bs)

    for i in range(64):
        r[i * 8:] = store8(r[i * 8:], uint64_t(bs[i]))


# input: condition bits c
# output: support s
def support_gen(s, c):
    a = gf()
    L = [bytearray((1 << GFBITS) // 8) for _ in range(GFBITS)]

    for i in range(GFBITS):
        for j in range((1 << GFBITS) // 8):
            L[i][j] = 0

    for i in range(1 << GFBITS):
        a.value = bitrev(gf(i))

        for j in range(GFBITS):
            L[j][i // 8] |= ((a.value >> j) & 1) << (i % 8)

    for j in range(GFBITS):
        apply_benes(L[j], c, 0)

    for i in range(SYS_N):
        s[i] = 0
        for j in range(GFBITS - 1, -1, -1):
            s[i] <<= 1
            s[i] |= (L[j][i // 8] >> (i % 8)) & 1
