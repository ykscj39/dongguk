# This file is for matrix transposition
from gf import *


# input: in, a 64x64 matrix over GF(2)
# output: out, transpose of in
def transpose_64x64(out, in_array):
    x = uint64_t()
    y = uint64_t()
    masks = [
        [uint64_t(0x5555555555555555), uint64_t(0xAAAAAAAAAAAAAAAA)],
        [uint64_t(0x3333333333333333), uint64_t(0xCCCCCCCCCCCCCCCC)],
        [uint64_t(0x0F0F0F0F0F0F0F0F), uint64_t(0xF0F0F0F0F0F0F0F0)],
        [uint64_t(0x00FF00FF00FF00FF), uint64_t(0xFF00FF00FF00FF00)],
        [uint64_t(0x0000FFFF0000FFFF), uint64_t(0xFFFF0000FFFF0000)],
        [uint64_t(0x00000000FFFFFFFF), uint64_t(0xFFFFFFFF00000000)]
    ]

    for i in range(64):
        out[i] = in_array[i]

    for d in range(5, -1, -1):
        s = 1 << d

        for i in range(0, 64, s * 2):
            for j in range(i, i + s):
                x.value = (out[j] & masks[d][0].value) | ((out[j + s] & masks[d][0].value) << s)
                y.value = ((out[j] & masks[d][1].value) >> s) | (out[j + s] & masks[d][1].value)

                out[j + 0] = x.value
                out[j + s] = y.value

