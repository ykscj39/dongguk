from encrypt import *
from decrypt import *
from sk_gen import *
from pk_gen import *
from util import *
from crypto_hash import *
from rng import *
from controlbits import *


def crypto_kem_enc(c, key, pk):
    e = bytearray(SYS_N // 8)
    one_ec = bytearray(1 + SYS_N // 8 + SYND_BYTES)
    one_ec[0] = 1

    encrypt(c, pk, e)

    one_ec[1:1 + SYS_N // 8] = e[:SYS_N // 8]
    one_ec[1 + SYS_N // 8:1 + SYS_N // 8 + SYND_BYTES] = c[:SYND_BYTES]

    key = crypto_hash_32b(key, one_ec, len(one_ec))

    return 0                                                                                                                                         


def crypto_kem_dec(key, c, sk):
    ret_decrypt = bytearray([0])

    m = gf()

    e = bytearray(SYS_N // 8)
    preimage = bytearray(1 + SYS_N // 8 + SYND_BYTES)
    x = preimage
    pos_s = 40 + IRR_BYTES + COND_BYTES
    # s = sk[40 + IRR_BYTES + COND_BYTES:]

    ret_decrypt = decrypt(e, sk[40:], c)

    m.value = ret_decrypt
    m.value -= 1
    m.value >>= 8

    x[0] = m.value & 1
    pos = 1
    for i in range(SYS_N // 8):
        x[pos] = (~m.value & sk[pos_s + i]) | (m.value & e[i])
        pos += 1

    for i in range(SYND_BYTES):
        x[pos] = c[i]
        pos += 1

    preimage = x
    key = crypto_hash_32b(key, preimage, len(preimage))

    return 0


def crypto_kem_keypair(pk, sk):
    seed = bytearray([64] + [0] * 33)
    pre_seed = bytearray(32)

    r = bytearray(SYS_N // 8 + (1 << GFBITS) * 4 + SYS_T * 2 + 32)
    rp = bytearray()

    f = (gf * SYS_T)()  # element in GF(2^mt)
    irr = (gf * SYS_T)()  # Goppa polynomial
    perm = (uint32_t * (1 << GFBITS))()  # random permutation as 32-bit integers
    pi = (int16_t * (1 << GFBITS))()  # random permutation

    randombytes(pre_seed, 32)
    seed[1:] = pre_seed

    while True:
        rp = len(r) - 32

        # expanding and updating the seed

        r = shake(r, len(r), seed, 33)
        sk[:32] = seed[1:33]
        skp = 40

        # print("r=", len(r))
        # for i in range(len(r)):
        #     print("%#x" % r[i], end=" ")

        seed[1:33] = r[rp:len(r)]

        # generating irreducible polynomial

        rp -= ctypes.sizeof(f)
        for i in range(SYS_T):
            f[i] = load_gf(r[rp + i * 2:])

        if genpoly_gen(irr, f) == -1:
            continue
        else:
            irr, f = genpoly_gen(irr, f)

        for i in range(SYS_T):
            skppp = store_gf(sk[skp + i * 2:], gf(irr[i]))
            sk[skp + i * 2: skp + i * 2 + 2] = skppp[0:2]

        skp += IRR_BYTES

        # generating permutation

        rp -= ctypes.sizeof(perm)
        for i in range(1 << GFBITS):
            perm[i] = load4(r[rp + i * 4:]).value

        if pk_gen(pk, sk[skp - IRR_BYTES:], perm, pi):
            continue

        sk[skp:] = controlbitsfrompermutation(sk[skp:], pi, GFBITS, 1 << GFBITS)
        skp += COND_BYTES

        rp -= SYS_N // 8
        sk[skp: skp + SYS_N // 8] = r[rp: rp + SYS_N // 8]

        # storing positions of the 32 pivots
        sk[32:] = store8(sk[32:], uint64_t(0xFFFFFFFF))
        break
    return 0
