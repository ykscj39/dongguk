#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <math.h>
#include "config.h"
#include "poly.h"
#include "matrix.h"
#include "goppa.h"
#include "test.h"

void test_read_val(stPoly **mb, char *filename)
{
	int i;
	FILE *fp = NULL;
	char str_tmp[10000] = { 0, };
	char *ptr;
	int row, col, deg;
	uint16_t coef;

	if ((fp = fopen(filename, "r")) == NULL)
	{
		printf("file read error\n");
		return;
	}

	while (!feof(fp))
	{
		str_tmp[0] = 0;

		fgets(str_tmp, 9900, fp);

		if(str_tmp[0] == 0)
			continue;

		ptr = strtok(str_tmp, ",");	row = atoi(ptr);
		ptr = strtok(NULL, ",");	col = atoi(ptr);
		ptr = strtok(NULL, ",");	deg = atoi(ptr);

		mb[row][col]->d = deg;
		if (deg != -1)
		{
			for (i = 0; i <= deg; i++)
			{
				ptr = strtok(NULL, ","); coef = atoi(ptr);
				mb[row][col]->c[i] = (coef);
			}
		}
	}

	fclose(fp);
	return;
}

void test_write_val(stPoly **mb, int row, int col, char *filename)
{
	int i, j, z;
	FILE *fp = NULL;

	if ((fp = fopen(filename, "w")) == NULL)
	{
		printf("file write error\n");
		return;
	}

	for (i = 0; i < row; i++)
	{
		for (j = 0; j < col; j++)
		{
			fprintf(fp, "%d,%d,%d,", i, j, mb[i][j]->d);
			for (z = 0; z <= mb[i][j]->d; z++)
				fprintf(fp, "%d,", (mb[i][j]->c[z]));
			fprintf(fp, "\n");
		}
	}

	fclose(fp);
	return;
}

double WeakPopovFormSwap(char *filename, int l)
{
	int i, j, k, p, z, id, jd, d;
	int pivots[100] = { 0, };

	stPoly tmp;
	stPoly **mb;
	FILE *fp;
	int e;
	uint16_t c;
	char title[100];
	void *swap;
	double start, end;

	mb = (stPoly **)malloc(sizeof(stPoly *) * l);
	tmp = poly_alloc(3000);

	for (i = 0; i < l; i++)
	{
		mb[i] = (stPoly *)malloc(sizeof(stPoly) * l);

		for (j = 0; j < l; j++)
			mb[i][j] = poly_alloc(3000);
	}

	for (i = 0; i < 100; i++)
		pivots[i] = -1;

	sprintf(title, "%s.csv", filename);
	test_read_val(mb, title);

	start = (((double)clock()) / CLOCKS_PER_SEC);
	for (i = 0; i < l; i++)
	{		
		p = find_pivot_popov_col(mb, i, l);
		
		if (p == -1)
			continue;
		pivots[i] = p;

		for (j = 0; j < i; j++)
		{
			if (p == pivots[j])
			{
				jd = mb[j][p]->d;
				id = mb[i][p]->d;
				e = jd - id;
				
				if (e <= 0)
					e = abs(e);
				else
				{
					swap = mb[j];
					mb[j] = mb[i];
					mb[i] = swap;

					id = mb[i][p]->d;
					jd = mb[j][p]->d;
				}

				c = gf_mul(mb[i][p]->c[id], gf_inv(mb[j][p]->c[jd]));

				for (k = 0; k < l; k++)
				{
					d = -1;
					for (z = e; z >= 0; z--)
						tmp->c[z] = 0;

					for (z = 0; z <= mb[j][k]->d; z++)
					{
						d = z + e;
						tmp->c[d] = gf_mul(mb[j][k]->c[z], c);
					}
					tmp->d = d;
					poly_add(mb[i][k], mb[i][k], tmp);
				}
				i = i - 1;
				break;
			}
		}
	}
	end = (((double)clock()) / CLOCKS_PER_SEC);
	
	for(i = 0; i < l; i++)
	{		
		for(j = 0; j < l; j++)
			poly_free(mb[i][j]);
	}
	free(mb);	
	poly_free(tmp);
	
	return (end - start);
}

void WeakPopovFormSub_swap(stPoly** mb, int rows, int cols)
{
	int i, j, k, p, z, d;
	int pivots[100] = { 0, };
	int e;
	void* swap;
	uint16_t c;
	stPoly tmp = poly_alloc(3000);

	for (i = 0; i < rows; i++)
		pivots[i] = -1;

	for (i = 0; i < rows; i++)
	{
		p = find_pivot_popov_col(mb, i, cols);
		
		if (p == -1)
			continue;
		pivots[i] = p;

		for (j = 0; j < i; j++)
		{
			if (p == pivots[j])
			{
				int jd = mb[j][p]->d;
				int id = mb[i][p]->d;
				e = jd - id;

				if (e <= 0)
					e = abs(e);
				else
				{
					swap = mb[j];
					mb[j] = mb[i];
					mb[i] = swap;

					id = mb[i][p]->d;
					jd = mb[j][p]->d;
				}

				c = gf_mul(mb[i][p]->c[id], gf_inv(mb[j][p]->c[jd]));

				for (k = 0; k < cols; k++)
				{
					d = -1;
					for (z = e; z >= 0; z--)
						tmp->c[z] = 0;

					for (z = 0; z <= mb[j][k]->d; z++)
					{
						d = z + e;
						tmp->c[d] = gf_mul(mb[j][k]->c[z], c);
					}
					tmp->d = d;
					poly_add(mb[i][k], mb[i][k], tmp);
				}

				i = i - 1;
				break;
			}
		}
	}
	
	poly_free(tmp);
}

double WeakPopovFormSub(char *filename, int lk, int l, int **idx, int *len)
{
	int i, j, k;
	stPoly** mb;
	char title[100];
	double start, end;
	stPoly** sub = (stPoly**)malloc(sizeof(stPoly*) * l);
	
	mb = (stPoly**)malloc(sizeof(stPoly*) * l);
	for (i = 0; i < l; i++)
	{
		mb[i] = (stPoly*)malloc(sizeof(stPoly) * l);

		for (j = 0; j < l; j++)
			mb[i][j] = poly_alloc(3000);
	}

	sprintf(title, "%s.csv", filename);
	test_read_val(mb, title);

	start = (((double)clock()) / CLOCKS_PER_SEC);
	for (i = 0; i < lk; i++)
	{
		for (j = 0; j < len[i]; j++)
			sub[j] = mb[idx[i][j]];

		WeakPopovFormSub_swap(sub, len[i], l);
	}
	end = (((double)clock()) / CLOCKS_PER_SEC);

	{
		sprintf(title, "%s_sub_swap.csv", filename);
		test_write_val(mb, l, l, title);
	}
	
	for(i = 0; i < l; i++)
	{		
		for(j = 0; j < l; j++)
			poly_free(mb[i][j]);
	}
	free(mb);
	free(sub);
	

	return (end - start);
}

void minima(char* filename, int l)
{
	int i, j;
	stPoly** mb;
	int rowdeg;
	int idx = 0, min = 3000;
	char title[100];

	mb = (stPoly**)malloc(sizeof(stPoly*) * l);

	for (i = 0; i < l; i++)
	{
		mb[i] = (stPoly*)malloc(sizeof(stPoly) * l);

		for (j = 0; j < l; j++)
			mb[i][j] = poly_alloc(3000);
	}

	sprintf(title, "%s.csv", filename);
	test_read_val(mb, title);

	for (i = 0; i < l; i++)
	{
		rowdeg = mb[i][0]->d;
		for (j = 1; j < l; j++)
		{
			if (rowdeg < mb[i][j]->d)
				rowdeg = mb[i][j]->d;
		}

		if (rowdeg < min)
		{
			min = rowdeg;
			idx = i;
		}
	}
	printf("min = %d\n", min);

	for (i = 0; i < l; i++)
	{
		printf("phi[%d] = ", i);
		for (j = 0; j < mb[idx][i]->d; j++)
			printf("%u ", mb[idx][i]->c[j]);
		printf("\n");
	}
}

void test_goppa()
{
	int i, k, t0, u, l;
	uint64_t *y;
	stPoly delta;

	char title[100];
	double avg1 = 0, avg2 = 0, rst;

	int** idx;
	int* len;

	gpp_init();
		
	y = (uint64_t *)calloc(BYTE_N, sizeof(uint64_t));
	for (i = 0; i < BYTE_N; i++)
		y[i] = 0;
		
	for (i = 0; i < EXTRA_T; i++)
		VEC_SET_BIT(y, i, 1);

	u = (int)floor(_N - _T - sqrt(_N * (_N - 2 * _T - 2)));
	printf("�߰� ������ �ִ뿡�� ���� %d\n", u);

	if (u > floor(_N - _T - sqrt(_N * (_N - 2 * _T - 2))))
	{
		printf("error u\n");
		return;
	}

	printf("u: "); scanf("%d", &u);
	gpp_bernstein1(y, &delta, u, &t0);

	printf("k: "); scanf("%d", &k);
	gpp_bernstein2(delta, k, u, t0, &l);

	if (((-k) & k) != k)
	{
		printf("k�� 2�� �ŵ������� �ƴ�");
		return;
	}

	len = (int*)malloc(sizeof(int) * k);
	idx = (int**)malloc(sizeof(int*) * k);
	
	for (i = 0; i < k; i++)
		idx[i] = (int*)malloc(sizeof(int) * l);

	{
		int row = 0, size = 1, j, z, d;
		i = 0;
		do
		{
			idx[0][i] = row;

			row += k;
			i += 1;
		} while (row < l);
		len[0] = i;

		for (i = 1; i < k; i++)
		{
			d = 0;
			for (j = 0; j < len[0]; j++)
			{
				for (z = 0; z <= size; z++)
				{
					row = idx[0][j] + z;

					if (row >= l)
						break;

					idx[i][d] = row; // j * size + z + j
					d += 1;
				}
			}
			len[i] = d;
			size += 1;
		}

		for (i = 0; i < k; i++)
		{
			printf("%d : ", len[i]);
			for (j = 0; j < len[i]; j++)
				printf("%d ", idx[i][j]);
			printf("\n");
		}

	}

	{
		sprintf(title, "my_lattice_m%d_t%d_u%d_lk%d_l%d", _M, _T, u, k, l);
		
		printf(">>WeakPopovFormSwap[%d]\n", l);
		rst = WeakPopovFormSwap(title, l);
		printf("%.2lf second\n", rst);

		printf(">>WeakPopovFormSub_swap[%d]\n", l);
		rst = WeakPopovFormSub(title, k, l, idx, len);
		printf("%.2lf second\n", rst);
	}	

	{
		sprintf(title, "my_lattice_m%d_t%d_u%d_lk%d_l%d_sub_swap", _M, _T, u, k, l);
		minima(title, l);
	}

	free(len);
	for (i = 0; i < k; i++)
		free(idx[i]);
	free(idx);
	
	free(y);
	return;
}

