#pragma once
#ifndef __CONFIG_H
#define __CONFIG_H

#include <inttypes.h>

//#define PI 1 //original
//#define IP 2

#define SYSTEMATIC		1 //IP
#define NONSYSTEMATIC	2 //PI

#define DEC_PAT			1
#define DEC_BM			2
#define DEC_LIST		3

//G = [IP],  H = [P^I]
#define GMATFORM		SYSTEMATIC 
#define DECODE			DEC_PAT
#define _M				6//(m, t) = (3, 2), (8, 22) (11, 27) (12, 64)

//m, n, k, t
#if _M == 12
#define _T 41
#define _U 0
#elif _M == 11
#define _T 27
#define _U 0
#elif _M == 8
#define _T 22
#define _U 2
#elif _M == 7
#define _T 16
#define _U 2
#elif _M == 4
#define _T 2
#define _U 0
#elif _M == 3
#define _T 2
#define _U 0
#elif _M == 6
#define _T 10
#define _U 2
#endif

#define _Q (1 << _M)
#define _N _Q //2690
#define _K (_N - (_M * _T))
#define _ORDER (_Q - 1)



#if DECODE == DEC_LIST
#define EXTRA_T (_T + _U)
#else
#define EXTRA_T _T + _U
#endif

#endif
