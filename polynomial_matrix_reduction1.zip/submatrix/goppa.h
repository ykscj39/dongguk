#pragma once
#ifndef __GOPPA_H
#define __GOPPA_H
#include <inttypes.h>
#include "matrix.h"

extern double encTimeArr[2];
extern double decTimeArr[10];


void gpp_init();

void gpp_finish(stMatVec gvec);
int find_pivot_popov_col(stPoly **P, int row, int last_col);

#endif