#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "test.h"

void main()
{
        srand(time(NULL));

        //goppa code delta theta °è»ê
        test_goppa();

        //Lattice 

        //test_weak();

        printf("main end\n");
        return;
}

