#include <stdio.h>
#include <stdlib.h>
#include "field.h"
#include "poly.h"

stPoly poly_alloc(int count)
{
	stPoly p = (stPoly)malloc(sizeof(struct _stPoly));
	p->count = count;
	p->c = (uint16_t *)calloc(count, sizeof(uint16_t));
	p->d = _NON;
	return p;
}

void poly_free(stPoly p)
{
	free(p->c); free(p);
	return;
}

void poly_set(stPoly p, uint16_t val)
{
	int i;
	p->d = _NON;
	for (i = 0; i < p->count; i++) p->c[i] = val;
	return;
}

void poly_get_deg(stPoly p)
{
	int d = p->count - 1;
	
	while ((d >= 0) && (p->c[d] == 0)) d -= 1;
	p->d = d;

	if (d == 0 && p->c[0] == 0) p->d = _NON;
	return;
}

void poly_copy(stPoly dst, stPoly src)
{
	int i;

	if (src->d != _NON)
	{
		for (i = 0; i <= src->d; i++)
			dst->c[i] = src->c[i];
	}
	dst->d = src->d;
	return;
}

void poly_add(stPoly rst, stPoly a, stPoly b)
{
	int i, d;

	if (a->d >= b->d)
	{
		for (i = 0; i <= b->d; i++)
			rst->c[i] = gf_add(a->c[i], b->c[i]);

		for (; i <= a->d; i++)
			rst->c[i] = a->c[i];

		d = a->d;
	}
	else
	{
		for (i = 0; i <= a->d; i++)
			rst->c[i] = gf_add(a->c[i], b->c[i]);

		for (; i <= b->d; i++)
			rst->c[i] = b->c[i];
		
		d = b->d;
	}

	//poly_get_deg(rst);
	rst->d = _NON;
	for (i = d; i >= 0; i--)
	{
		if (rst->c[i] != 0)
		{
			rst->d = i;
			break;
		}
	}
	return;
}

void poly_mul(stPoly rst, stPoly a, stPoly b)
{
	int i, j;
	for (i = 0; i <= a->d; i++)
	{
		for (j = 0; j <= b->d; j++)
			rst->c[i + j] = gf_add(rst->c[i + j], gf_mul(a->c[i], b->c[j]));
	}
	rst->d = a->d + b->d;
	return;
}

void poly_quo(stPoly rst, stPoly dvd, stPoly div)
{
	int i, j;
	stPoly rem;
	uint16_t a, b;

	if (dvd->d < div->d)
		return;
	
	rst->d = dvd->d - div->d;

	a = gf_inv(div->c[div->d]);

	rem = poly_alloc(dvd->count);
	poly_copy(rem, dvd);

	for (i = dvd->d; i >= div->d; --i)
	{
		b = gf_mul_fast(a, rem->c[i]);
		rst->c[i - div->d] = b;

		if (b) //!= 0
		{
			rem->c[i] = 0;
			for (j = i - 1; j >= i - div->d; --j)
				rem->c[j] = gf_add(rem->c[j], gf_mul_fast(b, div->c[div->d - i + j]));
		}
	}
	poly_free(rem);

	return;
}

void poly_mod(stPoly dvd, stPoly div)
{
	int i, j, deg;
	uint16_t a, b;

	deg = dvd->d - div->d;

	if (deg < 0)
		return;

	a = gf_inv(div->c[div->d]);
	for (i = dvd->d; deg >= 0; --i, --deg)
	{
		if (dvd->c[i])// != 0
		{
			b = gf_mul_fast(a, dvd->c[i]);
			for (j = 0; j < div->d; ++j)
				dvd->c[j + deg] = gf_add(dvd->c[j + deg], gf_mul_fast(b, div->c[j]));
			dvd->c[i] = 0;
		}
	}
	dvd->d = div->d - 1;

	while (dvd->d >= 0 && dvd->c[dvd->d] == 0)
		dvd->d -= 1;
}

void poly_eea(stPoly a, stPoly b, stPoly tau, stPoly gx, int deg) //extended Euclidean
{
	int i, j, fdeg, udeg, delta;
	stPoly f0, f1, u0, u1, tmp;
	uint16_t c;

	f0 = poly_alloc(gx->count);
	f1 = poly_alloc(gx->count);
	
	u0 = poly_alloc(gx->count);
	u1 = poly_alloc(gx->count);

	poly_copy(f0, gx);
	poly_copy(f1, tau);
		
	u1->c[0] = 1; u1->d = 0;
	delta = f0->d - f1->d;

	fdeg = f1->d;
	udeg = u1->d;

	while (fdeg >= deg)
	{
		for (j = delta; j >= 0; --j)
		{
			c = gf_quo(f0->c[fdeg + j], f1->c[fdeg]);
			if (c) // != 0
			{
				for (i = 0; i <= udeg; ++i)
					u0->c[i + j] = gf_add(u0->c[i + j], gf_mul_fast(c, u1->c[i]));

				for (i = 0; i <= fdeg; ++i)
					f0->c[i + j] = gf_add(f0->c[i + j], gf_mul_fast(c, f1->c[i]));
			}
		}

		tmp = f0; f0 = f1; f1 = tmp;
		tmp = u0; u0 = u1; u1 = tmp;

		udeg = udeg + delta;
		delta = 1;
		while (f1->c[fdeg - delta] == 0)
			delta += 1;
		fdeg -= delta;
	}

	f1->d = fdeg;
	u1->d = udeg;

	poly_copy(a, f1);
	poly_copy(b, u1);

	poly_free(f0);
	poly_free(f1);
	poly_free(u0);
	poly_free(u1);
	
	return;
}

void poly_inv(stPoly rst, stPoly p, stPoly gx)
{
	int i;
	stPoly f1;
	uint16_t c;

	f1 = poly_alloc(gx->count);

	poly_eea(f1, rst, p, gx, 1);

	c = gf_inv(f1->c[0]);
	for (i = 0; i <= rst->d; ++i)
		rst->c[i] = gf_mul_fast(c, rst->c[i]);

	poly_free(f1);

	return;
}

void poly_print(stPoly a, char *title)
{
	int i, j, k;

	printf("%s[%d] ", title, a->d);
	/*for (i = 0; i <= a->d; i++)
		printf("F.fetch_int(%u)*x^%d + ", (a->c[i]), i);//printf("%u ", a->c[i]);//
	printf("\n");
	*/
	if(a->d != -1) {
		for (i = 0; i < a->d; i++) {			
			if(a->c[i] != 0) {					
				printf("a^{%u}x^{%d} + ", gf_get_exp(a->c[i]), i);
			}
		}	
		printf("a^{%u}x^{%d}", gf_get_exp(a->c[a->d]), a->d );
		printf("\n");
	}
}


// destructive
stPoly poly_gcd_aux(stPoly p1, stPoly p2) 
{
	if (p2->d == _NON)
	{
		return p1;
	}
	else 
	{
		poly_mod(p1, p2);
		return poly_gcd_aux(p2, p1);
	}
}

stPoly poly_gcd(stPoly a, stPoly b)
{
	stPoly r1 = poly_alloc(a->count);
	stPoly r2 = poly_alloc(b->count);
	stPoly r0;

	poly_copy(r1, a);
	poly_copy(r2, b);

	if (a->d >= b->d)
	{	
		r0 = poly_alloc(a->count);
		poly_copy(r0, poly_gcd_aux(r1, r2));
		
	}
	else
	{
		r0 = poly_alloc(b->count);
		poly_copy(r0, poly_gcd_aux(r2, r1));
	}

	poly_free(r1);
	poly_free(r2);

	return r0;
}

int poly_irr_BenOr(int e, stPoly gx)
{
	stPoly mod;
	stPoly squ;
	stPoly gcd;
	stPoly rx;
	int i, j, d, rst = gx->d;

	mod = poly_alloc(rst * 2);
	squ = poly_alloc(rst * 2);
	gcd = poly_alloc(rst);
	rx = poly_alloc(rst);

	rx->c[1] = 1; rx->d = 1;

	for (d = 1; d <= (int)(gx->d / 2); d++)
	{
		for (i = 0; i < e; i++)
		{
			poly_set(squ, 0);
			for (j = rx->d; j >= 0; j--)
			{
				squ->c[j * 2] = gf_exp_pow(rx->c[j], 2);
			}
			squ->d = rx->d * 2; //poly_get_deg(squ);
			poly_mod(squ, gx);

			poly_set(rx, 0); poly_copy(rx, squ);			
		}

		rx->c[1] = gf_add(rx->c[1], 1);
		poly_get_deg(rx);

		gcd = poly_gcd(gx, rx);
		
		if (gcd->d > 0)
		{
			rst = d;
			break;
		}
		rx->c[1] = gf_add(rx->c[1], 1);
		poly_get_deg(rx);
	}

	poly_free(mod);
	poly_free(squ);
	poly_free(gcd);
	poly_free(rx);

	return rst;
}

stPoly poly_genIrr(int m, int t, int q)
{
	int i;
	stPoly gx = poly_alloc(t + 1);

	gx->d = t;
	gx->c[t] = 1;
	
	do
	{
		/*for (i = 0; i < t; i++)
			gx->c[i] = rand() % q;
		gx->c[t] = 1;*/
		if (m == 12)
		{
			if (t == 41)
			{
				gx->c[0] = 1358; gx->c[1] = 1144; gx->c[2] = 1216; gx->c[3] = 2472; gx->c[4] = 2817; gx->c[5] = 112; gx->c[6] = 1046; gx->c[7] = 3145; gx->c[8] = 1231; gx->c[9] = 1222; gx->c[10] = 1925; gx->c[11] = 750; gx->c[12] = 2099; gx->c[13] = 2105; gx->c[14] = 3426; gx->c[15] = 2617; gx->c[16] = 1772; gx->c[17] = 2570; gx->c[18] = 1246; gx->c[19] = 2959; gx->c[20] = 1004; gx->c[21] = 1184; gx->c[22] = 4009; gx->c[23] = 1915; gx->c[24] = 3215; gx->c[25] = 2330; gx->c[26] = 2740; gx->c[27] = 3418; gx->c[28] = 2199; gx->c[29] = 3568; gx->c[30] = 3454; gx->c[31] = 636; gx->c[32] = 2362; gx->c[33] = 2888; gx->c[34] = 4075; gx->c[35] = 3484; gx->c[36] = 577; gx->c[37] = 2531; gx->c[38] = 304; gx->c[39] = 442; gx->c[40] = 583; gx->c[41] = 1;
			}
			else if (t == 56)
			{
				gx->c[0] = 433; gx->c[1] = 93; gx->c[2] = 2337; gx->c[3] = 907; gx->c[4] = 1623; gx->c[5] = 1997; gx->c[6] = 710; gx->c[7] = 2062; gx->c[8] = 859; gx->c[9] = 3525; gx->c[10] = 1166; gx->c[11] = 1645; gx->c[12] = 2340; gx->c[13] = 1651; gx->c[14] = 3717; gx->c[15] = 2122; gx->c[16] = 2691; gx->c[17] = 592; gx->c[18] = 416; gx->c[19] = 1452; gx->c[20] = 3308; gx->c[21] = 2363; gx->c[22] = 2092; gx->c[23] = 2515; gx->c[24] = 1697; gx->c[25] = 1383; gx->c[26] = 3252; gx->c[27] = 353; gx->c[28] = 1583; gx->c[29] = 2285; gx->c[30] = 3586; gx->c[31] = 3890; gx->c[32] = 1687; gx->c[33] = 816; gx->c[34] = 2140; gx->c[35] = 3780; gx->c[36] = 2310; gx->c[37] = 376; gx->c[38] = 912; gx->c[39] = 1734; gx->c[40] = 2162; gx->c[41] = 353; gx->c[42] = 2240; gx->c[43] = 972; gx->c[44] = 3928; gx->c[45] = 118; gx->c[46] = 1101; gx->c[47] = 3578; gx->c[48] = 111; gx->c[49] = 743; gx->c[50] = 3142; gx->c[51] = 3173; gx->c[52] = 431; gx->c[53] = 586; gx->c[54] = 3868; gx->c[55] = 11; gx->c[56] = 1;
			}
		}
		else if (m == 11)
		{
			gx->c[0] = 895; gx->c[1] = 528; gx->c[2] = 1411; gx->c[3] = 1979; gx->c[4] = 1635; gx->c[5] = 469; gx->c[6] = 480; gx->c[7] = 764; gx->c[8] = 1882; gx->c[9] = 513; gx->c[10] = 814; gx->c[11] = 1774; gx->c[12] = 275; gx->c[13] = 896; gx->c[14] = 905; gx->c[15] = 928; gx->c[16] = 270; gx->c[17] = 18; gx->c[18] = 1341; gx->c[19] = 1880; gx->c[20] = 835; gx->c[21] = 1869; gx->c[22] = 100; gx->c[23] = 318; gx->c[24] = 739; gx->c[25] = 1653; gx->c[26] = 1280; gx->c[27] = 1;
		}
		else if (m == 10)
		{
			gx->c[0] = 582;	gx->c[1] = 639;	gx->c[2] = 488;	gx->c[3] = 97;	gx->c[4] = 7;	gx->c[5] = 86;	gx->c[6] = 82;	gx->c[7] = 399;	gx->c[8] = 629;	gx->c[9] = 352;	gx->c[10] = 379;	gx->c[11] = 387;	gx->c[12] = 914;	gx->c[13] = 357;	gx->c[14] = 151;	gx->c[15] = 751;	gx->c[16] = 593;	gx->c[17] = 607;	gx->c[18] = 843;	gx->c[19] = 562;	gx->c[20] = 424;	gx->c[21] = 824;	gx->c[22] = 356;	gx->c[23] = 567;	gx->c[24] = 486;	gx->c[25] = 980;	gx->c[26] = 201;	gx->c[27] = 154;	gx->c[28] = 71;	gx->c[29] = 594;	gx->c[30] = 430;	gx->c[31] = 269;	gx->c[32] = 197;	gx->c[33] = 399;	gx->c[34] = 779;	gx->c[35] = 1019;	gx->c[36] = 562;	gx->c[37] = 236;	gx->c[38] = 845;	gx->c[39] = 107;	gx->c[40] = 132;	gx->c[41] = 338;	gx->c[42] = 331;	gx->c[43] = 294;	gx->c[44] = 368;	gx->c[45] = 883;	gx->c[46] = 379;	gx->c[47] = 284;	gx->c[48] = 826;	gx->c[49] = 1;
		}
		else if (m == 8)
		{
			gx->c[0] = 0; gx->c[1] = 0; gx->c[2] = 0; gx->c[3] = 0; gx->c[4] = 0; gx->c[5] = 0; gx->c[6] = 0; gx->c[7] = 0; gx->c[8] = 0; gx->c[9] = 0; gx->c[10] = 0; gx->c[11] = 0; gx->c[12] = 0; gx->c[13] = 0; gx->c[14] = 0; gx->c[15] = 0; gx->c[16] = 0; gx->c[17] = 0; gx->c[18] = 0; gx->c[19] = 0; gx->c[20] = 0; gx->c[21] = 0; gx->c[22] = 1;
			gx->c[0] = gf_get_val(78); gx->c[5] = 1; gx->c[12] = 1; gx->c[15] = 1; gx->c[17] = 1; gx->c[22] = 1;
		}
		else if (m == 3)
		{
			gx->c[0] = 3; gx->c[1] = 1; gx->c[2] = 1;
		}
		else if (m == 7)
		{
			//gx->c[0] = 47; gx->c[1] = 7; gx->c[2] = 64; gx->c[3] = 70; gx->c[4] = 80; gx->c[5] = 30; gx->c[6] = 0; gx->c[7] = 0; gx->c[8] = 0; gx->c[9] = 0; gx->c[10] = 0; gx->c[11] = 0; gx->c[12] = 0; gx->c[13] = 0; gx->c[14] = 0; gx->c[15] = 0; gx->c[16] = 1;
			if (t == 16) {
				gx->c[0] = 104; gx->c[1] = 5; gx->c[2] = 102; gx->c[3] = 71; gx->c[4] = 5; gx->c[5] = 84; gx->c[6] = 64; gx->c[7] = 38; gx->c[8] = 98; gx->c[9] = 20; gx->c[10] = 63; gx->c[11] = 44; gx->c[12] = 11; gx->c[13] = 43; gx->c[14] = 3; gx->c[15] = 7; gx->c[16] = 1;
			}
			else if (t == 15) {
				gx->c[0] = 90; gx->c[1] = 86; gx->c[2] = 109; gx->c[3] = 116; gx->c[4] = 45; gx->c[5] = 7; gx->c[6] = 23; gx->c[7] = 124; gx->c[8] = 68; gx->c[9] = 118; gx->c[10] = 111; gx->c[11] = 73; gx->c[12] = 24; gx->c[13] = 7; gx->c[14] = 82; gx->c[15] = 1;
			}
		}
		else if (m == 4)
		{
			gx->c[0] = 12; gx->c[1] = 12; gx->c[2] = 1; //systematic
			//gx->c[0] = 7; gx->c[1] = 11; gx->c[2] = 1; //nonsystematic
		}
		else if (m == 6)
		{
			gx->c[0] = 3; gx->c[1] = 61; gx->c[2] = 44; gx->c[3] = 56; gx->c[4] = 5; gx->c[5] = 57; gx->c[6] = 24; gx->c[7] = 44; gx->c[8] = 41; gx->c[9] = 28; gx->c[10] = 1;
		}
		else if (m == 5)
		{
			gx->c[0] = 27; gx->c[1] = 0; gx->c[2] = 14; gx->c[3] = 1; 
		}


	} while (poly_irr_BenOr(m, gx) < t);

	return gx;
}


void poly_sqmod_init(stPoly gx, stPoly *sq) 
{
	int i, j, d;
	d = gx->d;

	for (i = 0; i < d / 2; ++i) 
	{
		// sq[i] = x^(2i) mod g = x^(2i)
		sq[i]->d = 2 * i; sq[i]->c[sq[i]->d] = 1;
	}

	for (; i < d; ++i) 
	{
		// sq[i] = x^(2i) mod g = (x^2 * sq[i-1]) mod g
		poly_set(sq[i], 0);
		for (j = sq[i - 1]->d + 2; j >= 2; j--)
			sq[i]->c[j] = sq[i - 1]->c[j - 2];
		sq[i]->d = sq[i - 1]->d + 2;

		poly_mod(sq[i], gx);
	}

	return;
}

/*Modulo p square of a certain polynomial g, sq[] contains the square
Modulo g of the base canonical polynomials of degree < d, where d is
the degree of G. The table sq[] will be calculated by poly_sqmod_init*/
void poly_sqmod(stPoly res, stPoly p, stPoly *sq, int d) 
{
	int i, j;
	uint16_t a;

	poly_set(res, 0);
	// terms of low degree
	for (i = 0; i < d / 2; ++i)
		res->c[i * 2] = gf_square(p->c[i]);

	// terms of high degree
	for (; i < d; ++i) {
		if (p->c[i] != 0) {
			a = gf_square(p->c[i]);
			for (j = 0; j < d; ++j)
			{
				res->c[j] = gf_add(res->c[j], gf_mul(a, sq[i]->c[j]));
			}
		}
	}

	// Update degre
	res->d = d - 1; //poly_set_deg(res, d - 1);
	while ((res->d >= 0) && (res->c[res->d] == 0))
		res->d -= 1;

	return;
}


// p = p * x mod g
// p of degree <= deg(g)-1
void poly_shiftmod(stPoly p, stPoly gx) 
{
	int i, t;
	uint16_t a;

	t = gx->d;
	a = gf_quo(p->c[t - 1], gx->c[t]);
	for (i = t - 1; i > 0; --i)
		p->c[i] = gf_add(p->c[i - 1], gf_mul(a, gx->c[i]));
	p->c[0] = gf_mul(a, gx->c[0]);
	poly_get_deg(p);

	return;
}


stPoly *poly_sqrtmod_init(stPoly gx, int m) 
{
	int i, t, size;
	stPoly aux, p, q, *sq_aux, *sqrt;

	t = gx->d;
	size = gx->count + 1;

	sq_aux = (stPoly *)malloc(t * sizeof(stPoly));
	for (i = 0; i < t; ++i)
		sq_aux[i] = poly_alloc(size);

	poly_sqmod_init(gx, sq_aux);

	q = poly_alloc(size);
	p = poly_alloc(size);

	p->c[1] = 1; p->d = 1;

	// q(z) = 0, p(z) = z
	for (i = 0; i < m * t - 1; ++i) 
	{
		// q(z) <- p(z)^2 mod g(z)
		poly_sqmod(q, p, sq_aux, t);
		// q(z) <-> p(z)
		aux = q; q = p; p = aux;
	}

	// p(z) = z^(2^(tm-1)) mod g(z) = sqrt(z) mod g(z)
	sqrt = (stPoly *)malloc(t * sizeof(stPoly));
	for (i = 0; i < t; ++i)
		sqrt[i] = poly_alloc(size);

	poly_copy(sqrt[1], p);
	for (i = 3; i < t; i += 2) 
	{
		poly_copy(sqrt[i], sqrt[i - 2]);
		poly_shiftmod(sqrt[i], gx);
	}

	for (i = 0; i < t; i += 2) 
	{
		poly_set(sqrt[i], 0);
		sqrt[i]->c[i / 2] = 1;
		sqrt[i]->d = i / 2;
	}

	for (i = 0; i < t; ++i)
		poly_free(sq_aux[i]);
	free(sq_aux);

	poly_free(p);
	poly_free(q);

	return sqrt;
}

int eval_poly(stPoly sgm, int x)
{
	int ret = 0;
	int xn = 1;
	for (int i = 0; i <= sgm->d; ++i)
	{
		ret ^= gf_mul(xn, sgm->c[i]);
		xn = gf_mul(xn, x);
	}
	return ret;
}

