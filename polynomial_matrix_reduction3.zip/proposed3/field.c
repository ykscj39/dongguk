#include <stdlib.h>
#include <stdio.h>
#include "field.h"

uint16_t priPoly[16] = { 0, 1, 7, 11, 25, 37, 91, 131, 285, 529, 1033, 2053, 4179, 8219, 17475, 32771 }; ///< primitive polynomial
//7=137, 6=67
int _ext;
uint16_t _ord;

uint16_t *gf_exp;
uint16_t *gf_val;

void gf_elements(int m, int q)
{
	int i;
	uint16_t pri = priPoly[m];

	_ext = m;
	_ord = (uint16_t)q - 1;

	gf_exp = (uint16_t *)calloc(q, sizeof(uint16_t));
	gf_val = (uint16_t *)calloc(q, sizeof(uint16_t));

	gf_val[0] = 1; gf_exp[0] = q - 1; gf_exp[1] = 0;
	for (i = 1; i < q - 1; i++)
	{
		gf_val[i] = gf_val[i - 1] << 1;
		if (gf_val[i] >= q)
		{
			gf_val[i] ^= pri;
		}
		gf_exp[gf_val[i]] = i;
	}
	gf_val[q - 1] = 1;

	return;
}

uint16_t gf_exp_pow(uint16_t x, int i) 
{
	if (i == 0)
		return 1;
	else if (x == 0)
		return 0;
	else 
	{
		// i mod (q-1)
		while (i >> _ext) i = (i & (_ord)) + (i >> _ext);
		i *= gf_exp[x];
		while (i >> _ext) i = (i & (_ord)) + (i >> _ext);
		
		return gf_val[i];
	}
}