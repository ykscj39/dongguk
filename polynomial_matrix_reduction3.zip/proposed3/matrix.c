#include <stdio.h>
#include <stdlib.h>
#include <string.h> 
#include "matrix.h"

#define VEC_WORDSIZE	(sizeof(uint64_t))		///< 1, 2, 4, 8

int _cwlen;
int _mslen;
uint64_t _pad = 0;

void vec_init(int n, int k)
{
	int i;

	_cwlen = n;
	_mslen = k;

	for (i = 1; i <= (k & (int)(VEC_WORDBITS - 1)); i++)
	{
		_pad <<= 1;
		_pad ^= 1;
	}
}

void vec_genRndVec(uint64_t *a, int aLen)
{
	int i, j;

	for (i = 0; i < aLen; i++)
	{
		a[i] = 0;
		for (j = 0; j < VEC_WORDSIZE; j++)
		{
			a[i] <<= 8;
			a[i] += (rand() & 0xFF);
		}
	}

	a[BYTE_K - 1] &= _pad;

	return;
}

void vec_print(uint64_t *a, int len, char *title)
{
	int i;
	printf("%s", title);
	for (i = 0; i < len; i++)
		printf("%d", VEC_GET_BIT(a, i));
	printf("\n");
}

stMatInt mat_allocInt(int row, int col)
{
	int i, j;
	stMatInt a = (stMatInt)malloc(sizeof(struct _stMatInt));
	a->mat = (uint16_t **)calloc(row, sizeof(uint16_t *));

	for (i = 0; i < row; i++)
	{
		a->mat[i] = (uint16_t *)calloc(col, sizeof(uint16_t));
		for (j = 0; j < col; j++)
		{
			a->mat[i][j] = 0;
		}
	}
	
	a->row = row;
	a->col = col;
	
	return a;
}

void mat_freeInt(stMatInt a)
{
	int i;

	for(i=0; i<a->row; i++)
		free(a->mat[i]);
	free(a->mat);
	free(a);
	return;
}

stMatVec mat_allocVec(int row, int col)
{
	int i;
	stMatVec a = (stMatVec)malloc(sizeof(struct _stMatVec));
	a->row = row;
	a->col = col;
	a->colSize = VEC_SIZE(col);
	a->v = (uint64_t **)calloc(row, sizeof(uint64_t *));

	for (i = 0; i < row; i++)
	{
		a->v[i] = (uint64_t *)calloc(col, sizeof(uint64_t));
	}

	return a;
}

void mat_freeVec(stMatVec a)
{
	int i;

	for (i = 0; i<a->row; i++)
		free(a->v[i]);
	free(a->v);
	free(a);
	return;
}

stMatVec mat_IntToVec(int block, stMatInt H)
{	
	int i, j;

	stMatVec Hsys = mat_allocVec((block * H->row), H->col);

	for (i = 0; i < Hsys->row; i++)
	{	
		for (j = 0; j < Hsys->col; j++)
		{
			VEC_SET_BIT(Hsys->v[i], j, (((H->mat[i / block][j]) >> (i % block)) & 1));
		}
	}

	return Hsys;
}

int mat_ref(stMatVec A, stMatVec *ref)//row echellon form matrix
{
	int i, j, z;
	int row = A->row;
	int col = A->col;
	int diff = col - row;
	int rank = 0;

	stMatVec rst;

	if (row > col)
	{
		printf("error: mat_row echellon form matrix");
		return 0;
	}

	for (i = (row - 1), j = (i + diff); i >= 0; i--, j--)
	{
		int flag = -1;

		if (VEC_GET_BIT(A->v[i], j)) //1
		{
			flag = j;
		}

		if (flag == -1)
		{
			for (z = (i - 1); z >= 0; z--)
			{
				if (VEC_GET_BIT(A->v[z], j)) //1
				{
					//vec_swap(A->colSize, A->v[z], A->v[i]);
					uint64_t *swap = A->v[z];
					A->v[z] = A->v[i];
					A->v[i] = swap;
					
					flag = j;
					break;
				}
			}
		}

		if (flag == -1)
		{
			return 0;
		}
		else
		{
			rank += 1;
			for (z = (i - 1); z >= 0; z--)
			{
				if (VEC_GET_BIT(A->v[z], flag))
				{
					vec_xor(A->colSize, A->v[i], A->v[z]);
				}
			}
			for (z = (i + 1); z < row; z++)
			{
				if (VEC_GET_BIT(A->v[z], flag))
				{
					vec_xor(A->colSize, A->v[i], A->v[z]);
				}
			}
		}
	}
	
	rst = mat_allocVec(col, diff);

	for (i = 0; i < rst->col; i++)
		VEC_SET_BIT(rst->v[i], i, 1);
	
	for (; i < rst->row; i++)
	{
		for (j = 0; j < rst->col; j++)
		{
			VEC_SET_BIT(rst->v[i], j, VEC_GET_BIT(A->v[i - diff], j));
		}
	}
	
	*ref = rst;
	return rank;
}

stMatVec mat_trs(stMatVec a)
{
	int i, j;
	stMatVec rst = mat_allocVec(a->col, a->row);

	for (i = 0; i < rst->row; i++)
	{
		for (j = 0; j < rst->col; j++)
		{
			VEC_SET_BIT(rst->v[i], j, VEC_GET_BIT(a->v[j], i));
		}
	}

	return rst;
}

int mat_mulVec(uint64_t *rst, uint64_t *vt, stMatVec mt)
{
	int i, j, idx = 0;
	uint64_t tmp;
	int rowByte = VEC_SIZE(mt->row);

	for (i = 0; i < rowByte; i++)
	{
		tmp = vt[i];
		for (j = 0; j < VEC_WORDBITS; j++)
		{
			if (tmp & 1)
				vec_xor(mt->colSize, mt->v[idx + j], rst);
			tmp = tmp >> 1;
		}
		idx += VEC_WORDBITS;
	}
	return 1;
}

stMatVec mat_ivs(stMatVec A)
{
	int i, j;
	stMatVec C, E;
	uint64_t *swap;
	int row = A->row;
	
	if (A->row != A->col)
	{
		printf("not same row and column\n");
		return NULL;
	}
	C = mat_allocVec(A->row, A->col);
	E = mat_allocVec(A->row, A->col);

	for (i = 0; i < C->row; i++)
	{
		vec_cpy(C->colSize, A->v[i], C->v[i]);
		VEC_SET_BIT(E->v[i], i, 1);
	}

	for (i = 0; i < row; i++)
	{
		for (j = i + 1; j < row; j++)
		{
			if (VEC_GET_BIT(C->v[j], i) == 1)
			{
				if (VEC_GET_BIT(C->v[i], i) == 1)
				{
					vec_xor(C->colSize, C->v[i], C->v[j]); /* j vector is updated */
					vec_xor(E->colSize, E->v[i], E->v[j]); //20170922
				}
				else
				{
					//vec_swap(C.vecSize, C.v[i].arr, C.v[j].arr);
					//vec_swap(E->vecSize, E->v[i].arr, E->v[j].arr);//20170922
					swap = C->v[i]; C->v[i] = C->v[j]; C->v[j] = swap;
					swap = E->v[i]; E->v[i] = E->v[j]; E->v[j] = swap;
				}
			}
		}

		if (VEC_GET_BIT(C->v[i], i) == 0)
		{
			printf("error : mat_Gaussian(%d)\n", i);
			mat_freeVec(E);
			mat_freeVec(C);
			return NULL;
		}

		for (j = i - 1; j >= 0; j--)
		{
			if (VEC_GET_BIT(C->v[j], i) == 1)
			{
				vec_xor(C->colSize, C->v[i], C->v[j]); /* j vector is updated */
				vec_xor(E->colSize, E->v[i], E->v[j]);
			}
		}
	}

	mat_freeVec(C);

	return E;
}

stMatVec mat_mulMat(stMatVec A, stMatVec B)
{
	int i;
	stMatVec rst = mat_allocVec(A->row, B->col);

	if (A->col != B->row)
	{
		printf("error: check column and row\n");
		return NULL;
	}
		
	for (i = 0; i < A->row; i++)
		mat_mulVec(rst->v[i], A->v[i], B);

	return rst;
}

void mat_print(stMatVec A, char *title)
{
	int i, j;

	printf("\n%s[%d][%d]\n", title, A->row, A->col);
	for (i = 0; i < A->row; i++)
	{
		for (j = 0; j < A->col; j++)
			printf("%d", VEC_GET_BIT(A->v[i], j));
		printf("\n");
	}
	printf("\n");
}


void mat_nullSpace(stMatVec *nullSpace, stMatVec A)
{
	int i, j;

	int row = (A->row <= A->col ? A->row : A->col);
	int col = (A->row >= A->col ? A->row : A->col);

	int free_cnt = 0, pivot_cnt = 0;
	int *fre = (int *)malloc(A->col * sizeof(int));
	int *pivot = (int *)malloc(A->col * sizeof(int));

	stMatVec rst;

	memset(fre, -1, A->col);
	memset(pivot, -1, A->col);

	for (i = 0; i < row; i++)
	{
		int flag = -1;
		if (VEC_GET_BIT(A->v[i], i) == 1)
		{
			flag = i;
		}

		if (flag == -1)
		{
			for (j = (i + 1); j < row; j++)
			{
				if (VEC_GET_BIT(A->v[j], i) == 1)
				{
					vec_swap(A->colSize, A->v[j], A->v[i]);
					flag = i;
					break;
				}
			}
		}

		if (flag == -1)
		{
			/*int z;
			printf("col swap %d\n", i);
			printf("\nHVec\n");
			for (z = 0; z < A->row; z++)
			{
				for (j = 0; j < A->col; j++)
					printf("%d ", VEC_GET_BIT(A->v[z], j));
				printf("\n");
			}
			printf("\n");*/


			fre[free_cnt] = i;	free_cnt += 1;
		}
		else
		{
			pivot[pivot_cnt] = flag; pivot_cnt += 1;
			for (j = 0; j < row; j++)
			{
				if (VEC_GET_BIT(A->v[j], flag) == 1 && j != i)
					vec_xor(A->colSize, A->v[i], A->v[j]);
			}
		}
	}
	for (; i < col; i++)
	{
		fre[free_cnt] = i; free_cnt += 1;
		for (j = pivot_cnt - 1; j >= 0; j--)
		{
			if (pivot[j] == i)
			{
				fre[free_cnt] = -1; free_cnt -= 1;
				break;
			}
		}
	}

	rst = mat_allocVec(col, free_cnt);
	
	for (i = 0; i < free_cnt; i++)
	{
		for (j = 0; j < A->row; j++)
		{
			VEC_SET_BIT(rst->v[j], i, VEC_GET_BIT(A->v[j], fre[i]));
		}
	}
	
	for (i = 0; i < free_cnt; i++)
	{
		if (fre[i] < pivot_cnt)
		{
			vec_swap(rst->colSize, rst->v[fre[i]], rst->v[pivot[fre[i]]]);
		}

		VEC_SET_BIT(rst->v[fre[i]], i, 1);
	}

	*nullSpace = rst;

	free(pivot);
	free(fre);
	
	/*for (i = 0; i < pivot_cnt; i++)
	printf("%d ", pivot[i]);
	printf("\n");*/
}