#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include <string.h>

#include "config.h"
#include "field.h"
#include "poly.h"

#include "goppa.h"

uint16_t L[_Q];
uint16_t evlVal[_Q];//warr
uint16_t evlPst[_Q];//LErr
stPoly g;
stMatInt H;
stMatVec GVec;
stPoly *sqrtmod;

double encTimeArr[2] = { 0, };
double decTimeArr[10] = { 0, };

void gpp_comL(int n)
{
	int i;

	L[0] = 0;
	for (i = 1; i < n; i++) {
		L[i] = gf_get_val(i - 1);
		printf("%u ", L[i]);
	}
}

stMatInt gpp_genH(stPoly gx, int n, int t)
{
	int i, j, z;
	stMatInt C, X, Y, tmp;

	tmp = mat_allocInt(t, n);
	X	= mat_allocInt(t, n);
	Y	= mat_allocInt(n, n);
	
	for (i = 0; i < n; i++)
	{
		Y->mat[i][i] = gx->c[0];
		for (j = 1; j <= t; j++)
			Y->mat[i][i] ^= gf_mul(gf_exp_pow(L[i], j), gx->c[j]);
		Y->mat[i][i] = gf_inv(Y->mat[i][i]);
	}
	
#if DECODE == DEC_PAT
	C = mat_allocInt(t, t);

	for (i = 0; i < t; i++)
	{
		for (j = i; j < t; j++)
			C->mat[i][j] = gx->c[t - (j - i)];
	}
	
	for (i = 0; i < t; i++)
	{
		for (j = 0; j < n; j++)
			X->mat[i][j] = gf_exp_pow(L[j], (t - (i + 1)));
	}
	
	for (i = 0; i < tmp->row; i++)
	{
		for (j = 0; j < tmp->col; j++)
		{
			for (z = 0; z < t; z++)
			{
				if (C->mat[i][z] != 0)
					tmp->mat[i][j] ^= gf_mul(C->mat[i][z], X->mat[z][j]);
			}
			tmp->mat[i][j] = gf_mul(tmp->mat[i][j], Y->mat[j][j]);
		}
	}	
	mat_freeInt(C);
#elif DECODE == DEC_BM	
#endif
	mat_freeInt(X);
	mat_freeInt(Y);

	return tmp;
}

void gpp_init()
{
	stMatVec HVec, tmp;

	gf_elements(_M, _Q);
	gpp_comL(_Q);

	vec_init(_N, _K);

	while (1)
	{
		g = poly_genIrr(_M, _T, _Q); 
		H = gpp_genH(g, _N, _T);
		
		HVec = mat_IntToVec(_M, H);

		#if _M == 8
			mat_nullSpace(&tmp, HVec); break;
		#else
			if (mat_ref(HVec, &tmp) == (_M * _T))
				break;
		#endif

		poly_free(g);
		mat_freeVec(HVec);
		mat_freeInt(H);
	}
	
	poly_print(g, "gx");

	GVec = mat_trs(tmp);

	sqrtmod = poly_sqrtmod_init(g, _M);	

	mat_freeVec(HVec);
	mat_freeVec(tmp);

	printf("parameters ===>>\n");
	printf("m = %d\n", _M);
	printf("n = %d\n", _N);
	printf("t = %d\n", _T);
	printf("k = %d\n", _K);
	printf("=============<<\n");

	return;
}

void gpp_comSyn(stPoly *syn, uint64_t *y, stMatInt parMat)
{
	int i;
	int j;

	stPoly iv;
	stPoly add;

	iv = poly_alloc(parMat->row + 1);
	add = poly_alloc(parMat->row + 1);

	iv->d = parMat->row - 1; //row=4
	for (i = 0; i < parMat->col; i++)
	{
		if (VEC_GET_BIT(y, i) == 1) // 20170928
		{
			for (j = 0; j < parMat->row; j++)
			{
				iv->c[j] = parMat->mat[j][i];
			}
			poly_add(add, add, iv);
		}
	}

	*syn = add;

	poly_free(iv);
	return;
}

///////////////////////////////////////////////////////////////////////////
void Lattice_reduction_Gauss(stPoly gx, stPoly tau, stPoly a, stPoly b)
{
	int i;

	stPoly quo;
	stPoly tmp;

	stPoly a0, b0, a1, b1;

	double u;

	quo = poly_alloc(_T * 2 + 1);

	a0 = poly_alloc(_T * 2 + 1);
	b0 = poly_alloc(_T * 2 + 1);
	a1 = poly_alloc(_T * 2 + 1);
	b1 = poly_alloc(_T * 2 + 1);
	tmp = poly_alloc(_T * 2 + 1);

	poly_copy(a0, gx);
	poly_copy(a1, tau);

	b1->c[0] = 1; b1->d = 0;

	do {
		
		poly_set(tmp, 0); poly_copy(tmp, a0);
		poly_set(a0, 0); poly_copy(a0, a1);
		poly_set(a1, 0); poly_copy(a1, tmp);

		poly_set(tmp, 0); poly_copy(tmp, b0);
		poly_set(b0, 0); poly_copy(b0, b1);
		poly_set(b1, 0); poly_copy(b1, tmp);

		u = (double)(a0->d + a1->d) / (double)(4 * a0->d);

		poly_set(quo, 0); poly_quo(quo, a1, a0); //quo = floor(al1/al2)

		poly_mod(a1, a0); //al1 - floor(al1/al2) * al2

		poly_set(tmp, 0); poly_mul(tmp, quo, b0); //quo * be2
		poly_add(b1, b1, tmp);

	} while (a1->d >= b1->d);//(!((a1.d * 2) <= brk));

	poly_print(a0, "a0");
	poly_print(b0, "b0");
	poly_print(a1, "a1");
	poly_print(b1, "b1");
	
	poly_set(tmp, 0); tmp->c[1] = 1; tmp->d = 1;

	poly_set(quo, 0); poly_mul(quo, b0, b0);
	poly_set(a, 0); poly_mul(a, quo, tmp);
	poly_set(quo, 0); poly_mul(quo, a0, a0);
	poly_add(a, quo, a);

	poly_set(quo, 0); poly_mul(quo, b1, b1);
	poly_set(b, 0); poly_mul(b, quo, tmp);
	poly_set(quo, 0); poly_mul(quo, a1, a1);
	poly_add(b, quo, b);
	
	poly_free(quo);
	poly_free(a0);
	poly_free(b0);
	poly_free(a1);
	poly_free(b1);
	poly_free(tmp);

	return;
}

void cal_l(int *theta, int *l, int *lk, int e0_deg, int t, int extra)
{
	int g0 = 2 * (int)floor((double)(extra + t + - e0_deg) / 2.0);
	int g1 = 2 * (int)floor((double)(extra + e0_deg - t - 1) / 2.0);
	int D = 0;
	int da = 2 * (g0 + g1);
	int db;
	int dc;
	
	*theta = g1 - g0;
	//*lk = 0;
	while (D <= 0) {
		*lk += 1;
		db = -((2 * (g0 + g1)) + ((4 * (*lk)) * (t + extra)));
		dc = (2 * _N) * (((*lk) * (*lk)) + (*lk));
		D = (db * db) - 4 * da * dc;
	}
	//printf("db = %d, dc=%d, D=%d\n", db, dc, D);
	*l = (int)ceil(((double)(-db) - sqrt((double)D)) / (double)(2 * da));
	
	if(da == 0)
	{
		*l=1;
		while( (_N*(*lk+1))/(2*(*l)) >= (double)(t+extra)){			
			*l += 1;
			
			if(*l > 100)
			{
				printf("error: l is over 100\n");
				break;
			}
		}
	}
}

typedef struct _coeff {		// ±žÁ¶ÃŒ ÀÌž§Àº _Person
	int delta;				// ±žÁ¶ÃŒ žâ¹ö 1
	int x;                  // ±žÁ¶ÃŒ žâ¹ö 2
	int h;					// ±žÁ¶ÃŒ žâ¹ö 3
} coeff;

typedef struct _listCoeff {
	coeff *coeff;
	int deg;				// ±žÁ¶ÃŒ žâ¹ö 3
} listCoeff;

int find_pivot_popov_col(stPoly **P, int row, int last_col)
{
	int p = last_col - 1;
	int i;
	
	for (i = last_col - 2; i >= 0; i--)
	{		
		if (P[row][i]->d > P[row][p]->d)
			p = i;
	}
	
	if (P[row][p]->d == _NON)
		p = -1;

	return p;
}

void genReducMat(int theta, int l, int lk, stPoly h, stPoly delta, const int extra, const int flag) 
{
	listCoeff *poly;
	listCoeff ma;
	listCoeff mb;
	listCoeff mr;	
	char title[100];
	int j, z, i;
	int zero = 2147483647;
	
	poly = (listCoeff*)malloc(sizeof(listCoeff) * l);
	
	for (i = 0; i < l; i++)
	{
		poly[i].coeff = (coeff*)malloc(sizeof(coeff) * l);

		for (j = 0; j < l; j++)
		{
			poly[i].coeff[j].delta = 0;
			poly[i].coeff[j].h = 0;
			poly[i].coeff[j].x = 0;
		}
	}
	//printf("lk=%d\n", lk);
	ma.coeff = (coeff *)malloc(sizeof(coeff) * l);
	mb.coeff = (coeff *)malloc(sizeof(coeff) * 2);
	mr.coeff = (coeff *)malloc(sizeof(coeff) * l);

	ma.deg = 1;
	ma.coeff[0].delta = 1; ma.coeff[0].x = 0;
	ma.coeff[1].delta = 0; ma.coeff[1].x = theta;

	mb.deg = 1;
	mb.coeff[0].delta = 1; mb.coeff[0].x = 0;
	mb.coeff[1].delta = 0; mb.coeff[1].x = theta;

	poly[1].deg = 1;
	poly[1].coeff[0].delta = 1; poly[1].coeff[0].x = 0; poly[1].coeff[0].h = -1;
	poly[1].coeff[1].delta = 0; poly[1].coeff[1].x = theta; poly[1].coeff[1].h = -1;
	
	//printf("==============================>\n");
	for (i = 0; i < l; i++)
	{
		mr.coeff[i].delta = zero;
		mr.coeff[i].x = zero;
		mr.coeff[i].h = zero;
	}
	//printf("==============================>\n");
	for (z = 2; z <= lk; z++)
	{
		for (i = 0; i <= ma.deg; i++)
		{
			if (ma.coeff[i].x != zero || ma.coeff[i].delta != zero)
			{
				for (j = 0; j <= mb.deg; j++)
				{
					int delta;
					int x;

					delta = ma.coeff[i].delta + mb.coeff[j].delta;
					x = ma.coeff[i].x + mb.coeff[j].x;
		
					if ((mr.coeff[i + j].delta == delta) && (mr.coeff[i + j].x == x))
					{
						mr.coeff[i + j].delta = zero;
						mr.coeff[i + j].x = zero;
						mr.coeff[i + j].h = zero;
					}
					else
					{
						mr.coeff[i + j].delta = delta;
						mr.coeff[i + j].x = x;
						mr.coeff[i + j].h = -z;
					}
				}
			}
		}
		mr.deg = ma.deg + mb.deg;

		for (i = 0; i <= mr.deg; i++)
		{
			ma.coeff[i].delta = mr.coeff[i].delta;
			ma.coeff[i].x = mr.coeff[i].x;
			ma.coeff[i].h = mr.coeff[i].h;

			poly[z].coeff[i].delta = mr.coeff[i].delta;
			poly[z].coeff[i].x = mr.coeff[i].x;
			poly[z].coeff[i].h = mr.coeff[i].h;

			mr.coeff[i].delta = zero;
			mr.coeff[i].x = zero;
			mr.coeff[i].h = zero;
		}
		poly[z].deg = mr.deg;
		ma.deg = mr.deg;
		mr.deg = 0;
	}
	
	free(ma.coeff);
	free(mb.coeff);
	free(mr.coeff);		

	for (z = 1; z <= l - lk - 1; z++)
	{
		for (i = 0; i < l; i++)
		{
			poly[lk + z].coeff[i].delta = zero;
			poly[lk + z].coeff[i].x = zero;
			poly[lk + z].coeff[i].h = zero;
		}

		for (i = 0; i <= poly[lk].deg; i++)
		{
			if (poly[lk].coeff[i].delta != zero || poly[lk].coeff[i].x != zero)
			{
				poly[lk + z].coeff[i + z].delta = poly[lk].coeff[i].delta;
				poly[lk + z].coeff[i + z].x = poly[lk].coeff[i].x + (z * theta);
				poly[lk + z].coeff[i + z].h = poly[lk].coeff[i].h;
			}
		}
		poly[lk + z].deg = lk + z;
	}
	
	poly[0].deg = 0;
	poly[0].coeff[0].delta = 0; poly[0].coeff[0].x = -poly[l - 1].coeff[l - 1].x; poly[0].coeff[0].h = -poly[l - 1].coeff[l - 1].h;

	for (z = 1; z < l; z++)
	{
		for (i = 0; i <= poly[z].deg; i++)
		{
			if (poly[z].coeff[i].h != zero)
			{
				poly[z].coeff[i].delta = poly[z].coeff[i].delta - poly[l - 1].coeff[l - 1].delta;
				poly[z].coeff[i].x = poly[z].coeff[i].x - poly[l - 1].coeff[l - 1].x;
				poly[z].coeff[i].h = poly[z].coeff[i].h - poly[l - 1].coeff[l - 1].h;
			}
		}
	}	
	
	/*for (z = 0; z < l; z++)
	{
		printf("[%d]=", z);
		for (i = 0; i <= poly[z].deg; i++)
		{
			if (poly[z].coeff[i].x == zero && poly[z].coeff[i].delta== zero){
				printf("0 ");
			}
			else{
				printf("x%dd%dh%d ", poly[z].coeff[i].x, poly[z].coeff[i].delta, poly[z].coeff[i].h);
			}
		}
		printf("\n");
	}	
	return;*/
	
	//printf("==============================>\n");
	{
		int z, y;

		stPoly **mb;

		stPoly msum1;
		stPoly msum2;
		stPoly mmul;
		stPoly mquo;

		stPoly *hlist = (stPoly*)malloc(sizeof(stPoly) * (lk + 1));
		stPoly *dlist = (stPoly*)malloc(sizeof(stPoly) * (lk + 1));
		
		FILE *fp;

		msum1 = poly_alloc(((lk + 1)) + (theta * (l + 1)) + (delta->d * (lk + 1)) * 2 );
		msum2 = poly_alloc(((lk + 1)) + (theta * (l + 1)) + (delta->d * (lk + 1)) * 2);
		mmul = poly_alloc(((lk + 1)) + (theta * (l + 1)) + (delta->d * (lk + 1)) * 2);
		mquo = poly_alloc(((lk + 1)) + (theta * (l + 1)) + (delta->d * (lk + 1)) * 2);
		
		mb = (stPoly **)malloc(sizeof(stPoly *) * l);

		for (z = 0; z < l; z++)
		{
			mb[z] = (stPoly *)malloc(sizeof(stPoly) * l);

			for (i = 0; i < l; i++)
				mb[z][i] = poly_alloc((h->d * (lk + 1)) + (theta * (l + 1)) + (delta->d * (lk + 1)));
		}

		for (z = 0; z < l; z++)
		{
			for (i = 0; i <= poly[z].deg; i++)
			{
				if (poly[z].coeff[i].x != zero || poly[z].coeff[i].delta != zero || poly[z].coeff[i].h != zero)
				{
					poly_set(msum1, 0);
					for (j = 0; j <= h->d; j++)
					{
						msum1->c[j] = h->c[j] * poly[z].coeff[i].h;
					}
					poly_get_deg(msum1);

					poly_set(msum2, 0); msum2->c[poly[z].coeff[i].x] = 1; poly_get_deg(msum2);
					poly_set(mmul, 0); poly_mul(mmul, msum1, msum2);

					poly_set(msum1, 0);
					for (j = 0; j <= delta->d; j++)
					{
						msum1->c[j] = delta->c[j] * poly[z].coeff[i].delta;
					}
					poly_get_deg(msum1);

					poly_set(mb[z][i], 0); poly_mul(mb[z][i], mmul, msum1);
				}
			}
		}
		mb[l - 1][l - 1]->c[theta*(l - lk - 1) + (theta * lk)] = 1; poly_get_deg(mb[l - 1][l - 1]);	

		{
			for (z = 0; z < (lk + 1); z++)
			{
				hlist[z] = poly_alloc( (h->d * (lk + 1)) + (theta * (l + 1)) + (delta->d * (lk + 1)) );
				hlist[z]->c[0] = 1;
				hlist[z]->d = 0;

				dlist[z] = poly_alloc( (h->d * (lk + 1)) + (theta * (l + 1)) + (delta->d * (lk + 1)) );
				dlist[z]->c[0] = 1;
				dlist[z]->d = 0;

				for (i = 1; i <= z; i++)
				{
					poly_set(mmul, 0); poly_mul(mmul, hlist[z], h);
					poly_set(hlist[z], 0); poly_copy(hlist[z], mmul);

					poly_set(mmul, 0); poly_mul(mmul, dlist[z], delta);
					poly_set(dlist[z], 0); poly_copy(dlist[z], mmul);
				}					
			}			
		}

		{
			//2020-09-08 Çà°ú ¿­ ÀüÈ¯ ¹× weak popov form
			//printf("max size %d\n", (h->d * (lk + 1)) + (theta * (l + 1)) + (delta->d * (lk + 1)));

			for (z = 0; z < l; z++)
			{
				for (i = 0; i <= poly[z].deg; i++)
				{
					poly_set(mb[z][i], 0);
				}
			}
			
			for (z = 0; z < l; z++)
			{
				for (i = 0; i <= poly[z].deg; i++)
				{
					if (poly[z].coeff[i].x != zero || poly[z].coeff[i].delta != zero || poly[z].coeff[i].h != zero)
					{
						poly_set(msum1, 0);
						
						poly_copy(msum1, hlist[poly[z].coeff[i].h]);

						poly_set(msum2, 0); msum2->c[poly[z].coeff[i].x] = 1; poly_get_deg(msum2);
						poly_set(mmul, 0); poly_mul(mmul, msum1, msum2);

						poly_set(msum1, 0);

						poly_copy(msum1, dlist[poly[z].coeff[i].delta]);

						poly_set(mb[z][i], 0); poly_mul(mb[z][i], mmul, msum1);
					}
				}
			}
			mb[l - 1][l - 1]->c[0] = 1; poly_get_deg(mb[l - 1][l - 1]);
		}

		sprintf(title, "my_lattice_m%d_t%d_u%d_lk%d_l%d_%d.csv", _M, _T, extra, lk, l, flag);
		printf("write: %s\n", title);
		fp = fopen(title, "w");
		for (i = 0; i < l; i++)
		{
			for (j = 0; j < l; j++)
			{
				fprintf(fp, "%d,%d,%d,", i, j, mb[i][j]->d);
				for (z = 0; z <= mb[i][j]->d; z++)
				{
					fprintf(fp, "%d,", (mb[i][j]->c[z]));
				}
				fprintf(fp, "\n");
			}
		}
		fclose(fp);

		for (z = 0; z < (lk + 1); z++)
		{
			poly_free(hlist[z]);
			poly_free(dlist[z]);
		}

		free(hlist);
		free(dlist);

		for (z = 0; z < l; z++)
		{
			for (i = 0; i < l; i++)
				poly_free(mb[z][i]);
			
			free(mb[z]);
		}
		free(mb);

		poly_free(msum1);
		poly_free(msum2);
		poly_free(mmul);
		poly_free(mquo);
	}
	
	for (i = 0; i < l; i++) {
		free(poly[i].coeff);
	}
	free(poly);
	return;
}

void gpp_bernstein1(uint64_t *codeword, stPoly *del, const int u, int *t0, int *lk)
{
	int i, j, size = g->count;
	stPoly syn, Tx, tau;

	int l, theta, k;
	stPoly a, b, h, r, e1, gcd;
	stPoly delta, tmp;	
	uint16_t sqrt;

	Tx = poly_alloc(size);
	tau = poly_alloc(size);
	a = poly_alloc(EXTRA_T + 2);
	b = poly_alloc(EXTRA_T + 2);

	gpp_comSyn(&syn, codeword, H);
	poly_print(syn, "syndrom");
	if (syn->d != _NON)
	{
		//Step 2  T = S^-1(mod)
		poly_inv(Tx, syn, g);
		poly_print(Tx, "syndrom_inverse");
		
		//Step 3  tau = sqrt(T + X) (mod g)
		Tx->c[1] = gf_add(Tx->c[1], 1);
		if (Tx->d != _NON) //if Tx(z) = z, sigma(z) = z.
		{
			/* X^2^(mt-1) = sqrt(X) */
			for (i = 0; i < _T; i++)
			{
				sqrt = gf_sqrt(Tx->c[i]);
				if (sqrt != 0)
				{
					if (i & 1)
					{
						for (j = 0; j <= sqrtmod[i]->d; j++)
						{
							tau->c[j] = gf_add(tau->c[j], gf_mul_fast(sqrt, sqrtmod[i]->c[j]));
						}
					}
					else
					{
						tau->c[i / 2] = gf_add(tau->c[i / 2], sqrt);
					}
					poly_get_deg(tau);
				}
			}
			poly_print(tau, "tau");

			Lattice_reduction_Gauss(g, tau, a, b);
			// h = z^n + z;
			// e0 = a0^2 + zb0^2
			poly_print(a, "e0");
			// Step 4 find e1
			// e1 = a1^2 + zb1 + re0
			// gcd{a1^2 + z*b1^2 + r*e0, h} = 1;
			h = poly_alloc(_ORDER + 2);
			h->c[_Q] = 1; h->c[1] = 1; h->d = _Q;

			r = poly_alloc(2); r->d = 0;

			e1 = poly_alloc(size * 2 + 1);
			for (i = 0; i < _ORDER; i++)
			{
				r->c[0] = gf_get_val(i);
				poly_set(e1, 0); poly_mul(e1, r, a); //re0
				poly_add(e1, b, e1);

				gcd = poly_gcd(h, e1);
				if (gcd->d == 0)//if (rst.d == 0 && rst.c[0] == 0)
					break;

				poly_free(gcd);
			}
			poly_free(gcd);
			poly_print(r, "r");
			poly_print(e1, "e1");
			//Step 5 find delta
			{
				delta = poly_alloc(h->count + a->count);
				tmp = poly_alloc(h->count);

				poly_inv(tmp, e1, h);
				poly_mul(delta, a, tmp);

				poly_mod(delta, h);
				poly_print(delta, "delta");
			}
						
			//Step 6
			k = 0; *t0 = a->d;
			//printf("t0=%d, theta=%d, l=%d, k=%d\n", a->d, theta, l, k);
			cal_l(&theta, &l, &k, a->d, _T, u);
			printf("t0=%d, theta=%d, l=%d, k=%d\n", a->d, theta, l, k);
			*lk = k;
			
			//lk = 8; l = 42;
		}
		else
		{
			tmp = poly_alloc(2);
			tmp->c[1] = 1; tmp->d = 1;
		}

		*del = delta;

		poly_free(Tx);
		poly_free(tau);//t * 2
		poly_free(a);
		poly_free(b);
		poly_free(h);
		poly_free(r);
		poly_free(e1);
		poly_free(tmp);
	}

	poly_free(syn);

	return;
}

void gpp_bernstein2(stPoly delta, int k, const int u, int t0, int *l, const int flag)
{
	int theta;
	stPoly h;
	h = poly_alloc(_ORDER + 2);
	h->c[_Q] = 1; h->c[1] = 1; h->d = _Q;

	k -= 1;
	//printf("t0=%d, theta=%d, l=%d, k=%d\n", t0, theta, *l, k);
	cal_l(&theta, l, &k, t0, _T, u);
	printf("gpp_bernstein2: t0=%d, theta=%d, l=%d, k=%d\n", t0, theta, *l, k);

	//Step 7
	genReducMat(theta, *l, k, h, delta, u, flag);

	return;
}

void gpp_finish(stMatVec gvec)
{
	int i, j;
	
	for (i = 0; i < gvec->row; i++)
	{
		int flag = 0;
		for (j = 0; j < gvec->colSize; j++)
		{
			if (gvec->v[i][j] != GVec->v[i][j])
			{
				flag = 1;
				printf("pubkey error %d %d %lu %lu\n", i, j, gvec->v[i][j], GVec->v[i][j]);
				break;
			}
		}
		if (flag == 1) break;
	}

	mat_freeInt(H);
	mat_freeVec(GVec);

	for (i = 0; i < g->d; ++i)
		poly_free(sqrtmod[i]);
	free(sqrtmod);

	poly_free(g);
	return;
}
