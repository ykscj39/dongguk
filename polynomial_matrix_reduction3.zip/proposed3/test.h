#pragma once
#ifndef __TEST_H
#define __TEST_H
#include "field.h"

void test_goppa();
void test_weak();

#endif