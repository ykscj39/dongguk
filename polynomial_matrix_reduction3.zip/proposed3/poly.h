#pragma once
#ifndef __POLY_H         
#define __POLY_H    

#include <inttypes.h>

#define _NON -1

typedef struct _stPoly {
	int count;	///< coefficient count
	int d;		///< degree
	uint16_t *c;///< coefficient(alpha exponent)
} *stPoly;

stPoly poly_alloc(int count);
void poly_free(stPoly p);
void poly_set(stPoly p, uint16_t val);
void poly_get_deg(stPoly p);
void poly_copy(stPoly dst, stPoly src);

void poly_add(stPoly rst, stPoly a, stPoly b);
void poly_mul(stPoly rst, stPoly a, stPoly b);
void poly_quo(stPoly rst, stPoly dvd, stPoly div);
void poly_mod(stPoly dvd, stPoly div);

void poly_eea(stPoly a, stPoly b, stPoly tau, stPoly gx, int deg);
void poly_inv(stPoly rst, stPoly p, stPoly gx);
void poly_print(stPoly a, char *title);
int eval_poly(stPoly sgm, int x);
stPoly poly_gcd(stPoly a, stPoly b);


stPoly *poly_sqrtmod_init(stPoly gx, int m);

stPoly poly_genIrr(int m, int t, int n);
#endif