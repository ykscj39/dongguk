#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <math.h>
#include "config.h"
#include "poly.h"
#include "matrix.h"
#include "goppa.h"
#include "test.h"

int pCnt = 0;
int nRow = 0;

int fact(int n)
{
    int i, f = 1;
    for(i = 1; i <= n;i++)
    {
        f = f*i;
    }
    return f;
}

void idx_org(int *idx, int l)
{
	int i;
	for(i=0; i<l; i++)
		idx[i] = i;
}

int state(stPoly **P, int l)
{
	 int nst = 0, i, p;
	 
	 for(i=0; i < l; i++) {
		 p = find_pivot_popov_col(P, i, l);
		 if(p != -1) {
			 //printf("%d\n", (P[i][p]->d * l + (p + 1))); 
			 nst = nst + (P[i][p]->d * l + (p + 1));
			 //printf("[%d] = %d, %d\n", i, P[i][p]->d, p);
		 }
	 }
	 
	 return nst;
}

void pri_deg(stPoly **P, int row, int col)
{
	int i, p;
	FILE *fp;
	
	if ((fp = fopen("st_original.txt", "a")) == NULL)
	{
		printf("file write error\n");
		return;
	}
	
	p = find_pivot_popov_col(P, row, col);
	fprintf(fp, "%d,%d,", row, p);
	for(i=P[row][p]->d - 1; i >= 0; i--) {
		if(P[row][p]->c[i] != 0) {
			fprintf(fp, "%d,", i);
			break;
		}
	}
	
	for(i=0; i < col; i++)
		fprintf(fp, "%d,", P[row][i]->d);	
	
	fprintf(fp, "\n");
	fclose(fp);
}

void idx_rand(int *idx, int l)
{
	int i, j;
	i=0;
	while(i < l) {
		idx[i] = rand() % l;
		for(j=0; j < i; j++) {		
			if(idx[i] == idx[j]) {
				idx[i] = -1;
				break;
			}
		}
		
		if(idx[i] == -1)
			continue;				
		i += 1;
	}
}

void idx_proposed1(int *idx, int k, int l)
{
	int i, j, z;
	
	z = 0;
	for(i = 0; i < k; i++)
	{
		idx[z] = i;
		j = 0;	
		do {
			z = z + 1;	
			j = j + 1;									
			idx[z] = j * k + i;
			
		}while(j * k + i < l);				
	}
}

void idx_proposed3(int *idx, int k, int l)
{
	int i, j, z;
	int ncr, r, b;
	int **nonzero_coef;			
	nonzero_coef = (int **)malloc(sizeof(int *) * ((int)log2(k) + 1));
	
	for(i=0; i < ((int)log2(k) + 1); i++){
		nonzero_coef[i] = (int *)malloc(sizeof(int) * l);
		nonzero_coef[i][l-1] = 0;
	}
				
	for(i=0; i <= k; i++)
	{
		z = 0;
		for(j=0; j<= i; j++)
		{
			ncr=fact(i)/(fact(j)*fact(i-j));
			z = z + ncr%2;
		}
		nonzero_coef[(int)log2(z)][nonzero_coef[(int)log2(z)][l-1]] = i;
		nonzero_coef[(int)log2(z)][l-1] += 1;
	}
	
	z = 0;
	idx[0] = nonzero_coef[0][0];
	for(i = 1; i < ((int)log2(k) + 1); i++){
		r=0; b=0;
		do{
			for(j = nonzero_coef[i][l-1] - 1; j>=0; j--)
			{
				if(l <= r * k + nonzero_coef[i][j]){
					b = b + 1;
					continue;
				}
				z = z + 1;
				idx[z] = r * k + nonzero_coef[i][j];
			}
			r = r + 1;
		}while(b < nonzero_coef[i][l-1]);
	}
	
	for(i=0; i < ((int)log2(k) + 1); i++)
		free(nonzero_coef[i]);
	free(nonzero_coef);
	
}

void test_read_val(stPoly **mb, char *filename)
{
	int i, j=0;
	FILE *fp = NULL;
	char str_tmp[20000] = { 0, };
	char *ptr;
	int row, col, deg;
	uint16_t coef;

	if ((fp = fopen(filename, "r")) == NULL)
	{
		printf("file read error: %s\n", filename);
		return;
	}

	while (!feof(fp))
	{
		str_tmp[0] = 0;

		fgets(str_tmp, 19900, fp);

		if(str_tmp[0] == 0)
			continue;
		
		ptr = strtok(str_tmp, ",");	row = atoi(ptr);
		ptr = strtok(NULL, ",");	col = atoi(ptr);
		ptr = strtok(NULL, ",");	deg = atoi(ptr);	

		mb[row][col]->d = deg;
		if (deg != -1)
		{
			for (i = 0; i <= deg; i++)
			{
				ptr = strtok(NULL, ","); coef = atoi(ptr);
				mb[row][col]->c[i] = (coef);
			}
		}
		j += 1;
	}

	fclose(fp);
	return;
}

void test_write_val(stPoly **mb, int row, int col, char *filename)
{
	int i, j, z;
	FILE *fp = NULL;

	if ((fp = fopen(filename, "w")) == NULL)
	{
		printf("file write error\n");
		return;
	}

	for (i = 0; i < row; i++)
	{
		for (j = 0; j < col; j++)
		{
			fprintf(fp, "%d,%d,%d,", i, j, mb[i][j]->d);
			for (z = 0; z <= mb[i][j]->d; z++)
				fprintf(fp, "%d,", (mb[i][j]->c[z]));
			fprintf(fp, "\n");
		}
	}

	fclose(fp);
	return;
}

double WeakPopovFormSwap(char *filename, int *idx, int l)
{
	int i, j, k, p, z, id, jd, d;
	int pivots[100] = { 0, };

	stPoly tmp;
	stPoly **mb;
	int e;
	uint16_t c;
	char title[100];
	void *swap;
	double start, end;
	stPoly **sub;

	mb = (stPoly **)malloc(sizeof(stPoly *) * l);
	sub = (stPoly**)malloc(sizeof(stPoly *) * l);
	tmp = poly_alloc(5000);

	for (i = 0; i < l; i++)
	{
		sub[i] = (stPoly *)malloc(sizeof(stPoly) * l);

		for (j = 0; j < l; j++){
			sub[i][j] = poly_alloc(5000);
		}
	}

	for (i = 0; i < 100; i++)
		pivots[i] = -1;

	sprintf(title, "%s.csv", filename);
	
	test_read_val(sub, title);
	
	for(i = 0; i < l; i++){
		mb[i] = sub[idx[i]];		
	}
	
	start = (((double)clock()) / CLOCKS_PER_SEC);
	for (i = 0; i < l; i++)
	{		
		p = find_pivot_popov_col(mb, i, l);
		
		if (p == -1)
			continue;
		pivots[i] = p;

		for (j = 0; j < i; j++)
		{
			if (p == pivots[j])
			{
				pCnt += 1;
				jd = mb[j][p]->d;
				id = mb[i][p]->d;
				e = jd - id;
				
				if (e <= 0)
					e = abs(e);
				else
				{
					swap = mb[j];
					mb[j] = mb[i];
					mb[i] = swap;

					id = mb[i][p]->d;
					jd = mb[j][p]->d;
				}

				c = gf_mul(mb[i][p]->c[id], gf_inv(mb[j][p]->c[jd]));

				for (k = 0; k < l; k++)
				{
					d = -1;
					for (z = e; z >= 0; z--)
						tmp->c[z] = 0;

					for (z = 0; z <= mb[j][k]->d; z++)
					{
						d = z + e;
						tmp->c[d] = gf_mul(mb[j][k]->c[z], c);
					}
					tmp->d = d;
					poly_add(mb[i][k], mb[i][k], tmp);
				}
				i = i - 1;
				break;
			}
		}
	}
	end = (((double)clock()) / CLOCKS_PER_SEC);
	
	/*for(i=0; i<l; i++)
	{
		for(j=0; j<l; j++)
		{
			if(mb[i][j]->d != -1) {
				printf("%d %d ",  i,  j);
				for (k= 0; k < mb[i][j]->d; k++) {
					
					if(mb[i][j]->c[k] != 0) {					
						printf("a^%ux^%d + ", gf_get_exp(mb[i][j]->c[k]), k);
					}
				}
			
				printf("a^%ux^%d", gf_get_exp(mb[i][j]->c[mb[i][j]->d]), mb[i][j]->d );
				printf("\n");
			}
		}
	}*/
	
	{
		sprintf(title, "%s_swap.csv", filename);
		test_write_val(mb, l, l, title);
	}

	for(i = 0; i < l; i++)
	{		
		for(j = 0; j < l; j++)
			poly_free(sub[i][j]);
	}
	free(sub);
	free(mb);	
	poly_free(tmp);
	
	return (end - start);
}

int find_secondPivot(int p, stPoly* mb, int l)
{
	int i;
	int  p2 = l - 1;
	
	for(i = l - 2; i > p; i--)	 {
			if(mb[i]->d > mb[p2]->d) 
					p2 = i;
	}
	
	for(i = p - 1; i >= 0; i--) {
		if(mb[i]->d > mb[p2]->d)
			p2 = i;
	}
	
	return p2;			
}

int find_stRow(int excep, int p, int* pgroup, stPoly** mb, int l, int *row)
{
	int i, j, k;
	int r, tmp, diff = -1;
	
	for(j=0; j < pgroup[l]; j++)
	{
		i = pgroup[j];
				
		if(excep == i)
			continue;
		
		tmp = mb[i][p]->d + 1;
		
		for(k=mb[i][p]->d - 1; k >= 0; k--) 
		{
			if(mb[i][p]->c[k] != 0) {
				tmp = mb[i][p]->d - k;
				break;
			}
		}
			
		//condition1
		if(tmp > diff)
		{ 			
			r = i;
			diff = tmp;
		}
		else if(tmp == diff)
		{
			int i2p = find_secondPivot(p, mb[i], l);
			int r2p = find_secondPivot(p, mb[r], l);
			
			//condition2 ->177648
			/*if( (mb[i][p]->d - mb[i][i2p]->d)  > (mb[r][p]->d - mb[r][r2p]->d) ) 
			{
					r = i;
					diff = tmp;
			}
			else if( (mb[i][p]->d - mb[i][i2p]->d)  == (mb[r][p]->d - mb[r][r2p]->d))
			{
				//condition3
				if(mb[i][p]->d < mb[r][p]->d)
				{
					r = i;
					diff = tmp;
				}
			}*/
			
			//condition3
			if(mb[i][p]->d < mb[r][p]->d)
			{
					r = i;
					diff = tmp;
			}
			
		}		
	}
	
	*row = r;	
	
	return diff;
}

int find_stRowPair(int* r1, int* r2, int p, int* pgroup, stPoly** mb, int l)
{	
	int diff1 = find_stRow(-1, p, pgroup, mb, l, r1);
	int diff2 = find_stRow(*r1, p, pgroup, mb, l, r2);
	
	if(diff1 <= diff2)
		return diff1;
	else
		return diff2;
}


void select_stRowPair(stPoly** mb, int l, int *row1, int * row2, int *pivot)
{	
	int i, j;
	int** pgroup = (int **)malloc(sizeof(int *) * l);
	int r1 = -1, r2 = -1, rMinDiff=-1, p;
	int tmp1, tmp2, tmpMinDiff;
	int diff1, diff2;
	
	for (i = 0; i < l; i++) 
	{
		pgroup[i] = (int *)malloc(sizeof(int) * (l + 1));		
		pgroup[i][l] = 0;
	}
	
	for(i = 0; i < l; i++)
	{
		p = find_pivot_popov_col(mb, i, l);
		
		if(p == -1)
			continue;
		
		pgroup[p][pgroup[p][l]] = i;
		pgroup[p][l] += 1;					
	}

	for(i = 0; i < l; i++)
	{
		tmp1 = -1; tmp2 = -1;
		
		if(pgroup[i][l] < 2)	
			continue;
		
		tmpMinDiff = find_stRowPair(&tmp1, &tmp2, i, pgroup[i], mb, l);
		if(r2==-1)
		{
			r1 = tmp1; 
			r2 = tmp2;
			rMinDiff = tmpMinDiff;
			p = i;
		}	
		if(tmpMinDiff > rMinDiff)
		{
			r1 = tmp1; 
			r2 = tmp2;
			rMinDiff = tmpMinDiff;
			p = i;
		}		
		else if(tmpMinDiff == rMinDiff)
		{
				//if( (mb[tmp1][i]->d - mb[tmp2][i]->d)  )
			//printf("MinDiff equal\n");
		}		
	}
	
	*row1 = r1;
	*row2 = r2;
	*pivot = p;
	
	for(i = 0; i < l; i++)
		free(pgroup[i]);	
	free(pgroup);
}

int find_STpair(int *r1, int *r2, int p, stPoly **mb, int l) {
	
	int i, j, k;
	int r1diff, r2diff;
	int diff[100] = { 0, };
	
	for (i = 0; i < 100; i++)
		diff[i] = -1;
	
	for(j=0; j<l; j++)
	{
		diff[j] = -1;
		if(p == find_pivot_popov_col(mb, j, l)) {
			diff[j] = mb[j][p]->d;
			for(k = mb[j][p]->d - 1; k >= 0; k--) {
				if(mb[j][p]->c[k] != 0) {
					diff[j] = mb[j][p]->d - k;
					break;
				}
			}				
		}
	}
			
	*r1=-1; r1diff = -1; 
	for(j=0; j<l; j++)
	{
		if(diff[j] > r1diff) 
		{
			*r1 = j;
			r1diff = diff[j];
		}
		else if(diff[j] != -1 && diff[j] == r1diff) 
		{				
			int r2p = l-1, j2p = l-1;
			for(k=l-2; k>0; k--){
				if(k != p && mb[j][k]->d > mb[j][j2p]->d)
					j2p = k;
				
				if(k != p && mb[*r1][k]->d > mb[*r1][r2p]->d)
					r2p = k;
			}
			if((mb[j][p]->d - mb[j][j2p]->d)  > (mb[*r1][p]->d - mb[*r1][r2p]->d)) {
				*r1 = j;
				r1diff = diff[j];
			}
		}			
	}
	
	*r2=-1; r2diff = -1; 
	for(j=0; j<l; j++)
	{
		if(j == *r1)
			continue;
		
		if(diff[j] > r2diff) 
		{
			*r2 = j;
			r2diff = diff[j];
		}
		else if(diff[j] != -1 && diff[j] == r2diff) 
		{				
			int r2p = l-1, j2p = l-1;
			for(k=l-2; k>0; k--){
				if(k != p && mb[j][k]->d > mb[j][j2p]->d)
					j2p = k;
				
				if(k != p && mb[*r2][k]->d > mb[*r2][r2p]->d)
					r2p = k;
			}
			if((mb[j][p]->d - mb[j][j2p]->d)  > (mb[*r2][p]->d - mb[*r2][r2p]->d)) {
				*r2 = j;
				r2diff = diff[j];
			}
		}
	}
	
	return r2diff;
}

double WeakPopovForm_nonSwap_RealTime(char *filename, int *idx, int l)
{
	stPoly **mb;
	stPoly **sub;
	stPoly tmp;
		
	uint16_t c;
	int e;
	
	char title[100];
	int i, j, k, z, d, brk=0;
	int r1, r2, p, r1d, r2d;
		
	mb = (stPoly **)malloc(sizeof(stPoly *) * l);
	sub = (stPoly**)malloc(sizeof(stPoly *) * l);
	tmp = poly_alloc(5000);
	
	for (i = 0; i < l; i++)
	{
		sub[i] = (stPoly *)malloc(sizeof(stPoly) * l);		
		for (j = 0; j < l; j++){
			sub[i][j] = poly_alloc(5000);
		}
	}
	sprintf(title, "%s.csv", filename);
	
	test_read_val(sub, title);
	for(i = 0; i < l; i++) {
		mb[i] = sub[idx[i]];		
	}
	
	
	
	while(1) {
		brk += 1;
		select_stRowPair(mb, l, &r1, &r2, &p);
		printf(">>r1=%d, r2=%d, p=%d\n", r1, r2, p);
		
		if(r2 == -1)
			break;
		
		//simple transformation
		do{
			pCnt += 1;
			
			if(mb[r2][p]->d > mb[r1][p]->d) {
				int swap = r1;
				r1 = r2;
				r2 = swap;				
			}
			
			r1d = mb[r1][p]->d;
			r2d = mb[r2][p]->d;
			
			e = r1d - r2d;				
			c = gf_mul(mb[r1][p]->c[r1d], gf_inv(mb[r2][p]->c[r2d]));
			
			for (k = 0; k < l; k++)
			{
				d = -1;
				for (z = e; z >= 0; z--)
					tmp->c[z] = 0;

				for (z = 0; z <= mb[r2][k]->d; z++)
				{
					d = z + e;
					tmp->c[d] = gf_mul(mb[r2][k]->c[z], c);
				}
				tmp->d = d;
				poly_add(mb[r1][k], mb[r1][k], tmp);
			}
			
			//printf("%d\n", pCnt);
			
		}while(p == find_pivot_popov_col(mb, r1, l));
				
		{
			sprintf(title, "%s_realtime_%d.csv", filename, brk);
			test_write_val(mb, l, l, title);
		}
	
		if(brk == 3)
			break;

	}
	
	{
		sprintf(title, "%s_swap.csv", filename);
		test_write_val(mb, l, l, title);
	}

	for(i = 0; i < l; i++)
	{		
		for(j = 0; j < l; j++) 
			poly_free(sub[i][j]);
	}
	free(sub);
	free(mb);	
	poly_free(tmp);	
	
	return 0.0;	
}

double realtimeWeakPopovForm_nonSwap(char *filename, int *idx, int l)
{
	int i, j, k, p, z, d;
	
	stPoly tmp;
	stPoly **mb;
	int e;
	uint16_t c;
	char title[100];
	stPoly **sub;
	
	int pairCnt = 0;
	
	int r1, r2, r1d, r2d, r1p, r2p, r1candi, r2candi;

	mb = (stPoly **)malloc(sizeof(stPoly *) * l);
	sub = (stPoly**)malloc(sizeof(stPoly *) * l);
	tmp = poly_alloc(5000);

	for (i = 0; i < l; i++)
	{
		sub[i] = (stPoly *)malloc(sizeof(stPoly) * l);

		for (j = 0; j < l; j++){
			sub[i][j] = poly_alloc(5000);
		}
	}

	sprintf(title, "%s.csv", filename);
	
	test_read_val(sub, title);
	
	for(i = 0; i < l; i++) {
		mb[i] = sub[idx[i]];		
	}
		
	for(i=0; i<l; i++)
	{
		p = find_pivot_popov_col(mb, i, l);
		
		if (p == -1)
			continue;
	
		find_STpair(&r1, &r2, p, mb, l);
		
		if(r2 != -1) {
			printf("p=%d, r1=%d r2=%d, ", p, r1, r2);
			
			pairCnt += 1;
			do{
				pCnt += 1;
				r1d = mb[r1][p]->d;
				r2d = mb[r2][p]->d;
				
				if(r1d >= r2d) 
				{
					e = r1d - r2d;
					
					c = gf_mul(mb[r1][p]->c[r1d], gf_inv(mb[r2][p]->c[r2d]));
					for (k = 0; k < l; k++)
					{
						d = -1;
						for (z = e; z >= 0; z--)
							tmp->c[z] = 0;

						for (z = 0; z <= mb[r2][k]->d; z++)
						{
							d = z + e;
							tmp->c[d] = gf_mul(mb[r2][k]->c[z], c);
						}
						tmp->d = d;
						poly_add(mb[r1][k], mb[r1][k], tmp);
					}
				}
				else 
				{
					e = r2d - r1d;

					c = gf_mul(mb[r2][p]->c[r2d], gf_inv(mb[r1][p]->c[r1d]));
					for (k = 0; k < l; k++)
					{
						d = -1;
						for (z = e; z >= 0; z--)
							tmp->c[z] = 0;

						for (z = 0; z <= mb[r1][k]->d; z++)
						{
							d = z + e;
							tmp->c[d] = gf_mul(mb[r1][k]->c[z], c);
						}
						tmp->d = d;
						poly_add(mb[r2][k], mb[r2][k], tmp);
					}
				}
				
				r1p = find_pivot_popov_col(mb, r1, l);
				r2p = find_pivot_popov_col(mb, r2, l);
			} while (p == r1p && p == r2p);
			
			
			
			if(find_STpair(&r1, &r1candi, r1p, mb, l) >= find_STpair(&r2, &r2candi, r2p, mb, l)) {
				printf("r1=%d r1c=%d, r2c=%d\n", r1, r1candi, r2candi);
				i=r1-1;
				r2 = r1candi;
			}
			else {
				printf("r2=%d r2c=%d\n", r2, r2candi);
				i=r2-1;
				r1 = r2;
				r2 = r2candi;
			}
		
			if(r1 == l-1 && r2 == -1)
			{
				int pivots[100] = {0,};
				for(j=0; j< l; j++)
					pivots[j] = find_pivot_popov_col(mb, j, l);
				
				for(j=0; j< l; j++)
				{
					for(k=0; k<l; k++)
					{
						if(j != k && pivots[j] == pivots[k]) {
							printf("test\n");
							i = -1;
							break;
						}
					}
				}				
			}
			
		}
		
		//printf("%d\n", pCnt);
		//if(pairCnt > 10)			
		//	break;
	}
	//printf("%d\n", pairCnt);

	{
		sprintf(title, "%s_swap.csv", filename);
		test_write_val(mb, l, l, title);
	}

	for(i = 0; i < l; i++)
	{		
		for(j = 0; j < l; j++)
			poly_free(sub[i][j]);
	}
	free(sub);
	free(mb);	
	poly_free(tmp);
	return 0.0;
}

double WeakPopovForm_nonSwap(char *filename, int *idx, int l)
{
	int i, j, k, p, z, id, jd, d;
	int pivots[100] = { 0, };

	stPoly tmp;
	stPoly **mb;
	FILE *fp;
	int e;
	uint16_t c;
	char title[100];
	void *swap;
	double start, end;
	stPoly **sub;

	mb = (stPoly **)malloc(sizeof(stPoly *) * l);
	sub = (stPoly**)malloc(sizeof(stPoly *) * l);
	tmp = poly_alloc(5000);

	for (i = 0; i < l; i++)
	{
		sub[i] = (stPoly *)malloc(sizeof(stPoly) * l);

		for (j = 0; j < l; j++){
			sub[i][j] = poly_alloc(5000);
		}
	}

	for (i = 0; i < 100; i++)
		pivots[i] = -1;

	sprintf(title, "%s.csv", filename);
	
	test_read_val(sub, title);
	
	for(i = 0; i < l; i++){
		mb[i] = sub[idx[i]];		
	}
	
	printf("state M = %d\n", state(mb, l));		
	start = (((double)clock()) / CLOCKS_PER_SEC);
	for (i = 0; i < l; i++)
	{		
		p = find_pivot_popov_col(mb, i, l);
		
		if (p == -1)
			continue;
		pivots[i] = p;
		
		for (j = 0; j < i; j++)
		{			
			if (p == pivots[j])
			{												
				pCnt += 1;
				jd = mb[j][p]->d;
				id = mb[i][p]->d;
				e = jd - id;
				
				if (e <= 0)
				{
					e = abs(e);
					c = gf_mul(mb[i][p]->c[id], gf_inv(mb[j][p]->c[jd]));
					
					pri_deg(mb, j, l); pri_deg(mb, i, l);
					
					for (k = 0; k < l; k++)
					{
						d = -1;
						for (z = e; z >= 0; z--)
							tmp->c[z] = 0;

						for (z = 0; z <= mb[j][k]->d; z++)
						{
							d = z + e;
							tmp->c[d] = gf_mul(mb[j][k]->c[z], c);
						}
						tmp->d = d;
						poly_add(mb[i][k], mb[i][k], tmp);
					}
					pri_deg(mb, i, l);
					i = i - 1;
					//printf("i=%d > %d \n", i + 1, i);
				}
				else
				{
					
					c = gf_mul(mb[j][p]->c[jd], gf_inv(mb[i][p]->c[id]));
					for (k = 0; k < l; k++)
					{
						d = -1;
						for (z = e; z >= 0; z--)
							tmp->c[z] = 0;

						for (z = 0; z <= mb[i][k]->d; z++)
						{
							d = z + e;
							tmp->c[d] = gf_mul(mb[i][k]->c[z], c);
						}
						tmp->d = d;
						poly_add(mb[j][k], mb[j][k], tmp);
					}
					i = j - 1;
					//printf("j=%d > %d\n", j + 1, j);
				}		
				//printf("%d,%d ", pCnt, state(mb, l));
				//printf("\n");
				
				break;
			}
		}
	}
	
	end = (((double)clock()) / CLOCKS_PER_SEC);
	printf("\nstate N = %d\n", state(mb, l));
	
	{
		sprintf(title, "%s_swap.csv", filename);
		test_write_val(mb, l, l, title);
	}

	for(i = 0; i < l; i++)
	{		
		for(j = 0; j < l; j++)
			poly_free(sub[i][j]);
	}
	free(sub);
	free(mb);	
	poly_free(tmp);
	
	return (end - start);
}

void WeakPopovFormSub_nonSwap(stPoly** mb, int rows, int cols)
{
	int i, j, k, p, z, d;
	int pivots[100] = { 0, };
	int e;
	void* swap;
	uint16_t c;
	int jd, id;
	stPoly tmp = poly_alloc(5000);

	for (i = 0; i < rows; i++)
		pivots[i] = -1;

	for (i = 0; i < rows; i++)
	{
		p = find_pivot_popov_col(mb, i, cols);
		
		if (p == -1)
			continue;
		pivots[i] = p;

		for (j = 0; j < i; j++)
		{
			if (p == pivots[j])
			{
				pCnt += 1;
				jd = mb[j][p]->d;
				id = mb[i][p]->d;
				e = jd - id;
				
				if (e <= 0) 
				{
					e = abs(e);
					c = gf_mul(mb[i][p]->c[id], gf_inv(mb[j][p]->c[jd]));
					
					for (k = 0; k < cols; k++)
					{
						d = -1;
						for (z = e; z >= 0; z--)
							tmp->c[z] = 0;

						for (z = 0; z <= mb[j][k]->d; z++)
						{
							d = z + e;
							tmp->c[d] = gf_mul(mb[j][k]->c[z], c);
						}
						tmp->d = d;
						poly_add(mb[i][k], mb[i][k], tmp);
					}

					i = i - 1;
				}
				else
				{
					c = gf_mul(mb[j][p]->c[jd], gf_inv(mb[i][p]->c[id]));

					for (k = 0; k < cols; k++)
					{
						d = -1;
						for (z = e; z >= 0; z--)
							tmp->c[z] = 0;

						for (z = 0; z <= mb[i][k]->d; z++)
						{
							d = z + e;
							tmp->c[d] = gf_mul(mb[i][k]->c[z], c);
						}
						tmp->d = d;
						poly_add(mb[j][k], mb[j][k], tmp);
					}
					i = j - 1;
				}
				break;
			}
		}
	}
	
	poly_free(tmp);
}

void WeakPopovFormSub_swap(stPoly** mb, int rows, int cols)
{
	int i, j, k, p, z, d;
	int pivots[100] = { 0, };
	int e;
	void* swap;
	uint16_t c;
	stPoly tmp = poly_alloc(5000);

	for (i = 0; i < rows; i++)
		pivots[i] = -1;

	for (i = 0; i < rows; i++)
	{
		FILE *fp = NULL;	
		if ((fp = fopen("pCnt.txt", "a")) == NULL) {
			printf("file write error\n");
			return;
		}
	
		fprintf(fp, "%d=%d\n", i , pCnt);
		fclose(fp);
		
		p = find_pivot_popov_col(mb, i, cols);
		
		if (p == -1)
			continue;
		pivots[i] = p;

		for (j = 0; j < i; j++)
		{
			if (p == pivots[j])
			{
				pCnt += 1;
				int jd = mb[j][p]->d;
				int id = mb[i][p]->d;
				e = jd - id;
				
				if (e <= 0)
					e = abs(e);
				else
				{
					swap = mb[j];
					mb[j] = mb[i];
					mb[i] = swap;

					id = mb[i][p]->d;
					jd = mb[j][p]->d;
				}

				c = gf_mul(mb[i][p]->c[id], gf_inv(mb[j][p]->c[jd]));

				for (k = 0; k < cols; k++)
				{
					d = -1;
					for (z = e; z >= 0; z--)
						tmp->c[z] = 0;

					for (z = 0; z <= mb[j][k]->d; z++)
					{
						d = z + e;
						tmp->c[d] = gf_mul(mb[j][k]->c[z], c);
					}
					tmp->d = d;
					poly_add(mb[i][k], mb[i][k], tmp);
				}

				i = i - 1;
				break;
			}
		}
		
		
	}
	
	poly_free(tmp);
}

//double WeakPopovFormSub(char *filename, int lk, int l, int **idx, int *len)
double WeakPopovFormSub(FILE *fp, char *filename, int lk, int l, int *idxs)
{
	int i, j, k;
	stPoly** mb;
	char title[100];
	double start=0.0, end=0.0;
	stPoly** sub = (stPoly**)malloc(sizeof(stPoly*) * l);
	
#if _M == 6
	#if _U == 2
	int len[8] = {6, 11, 16, 21, 27, 32, 37,42};
	int idx[8][42] = {0,};
	#elif _U == 1
	int len[4] = {4,8,12,15};
	int idx[4][15] = {0,};
	//int len[2] = {2,3};
	#endif
	//int idx[2][3] = {0,};
#elif _M == 7
	int len[4] = {8, 15, 23, 30};
	int idx[4][30] = {0,};
#elif _M == 8
	int len[8] = {11, 22, 33, 44, 55, 66, 77, 87};
	int idx[8][87] = {0,};	
#elif _M == 4
	int len[4] = {4,8,11,14};
	int idx[4][14] = {0,};		
	//int len[4] = {3,5,7,9};
	//int idx[4][9] = {0,};
#elif _M == 5
	int len[4] = {6,11,16,21};
	int idx[4][21] = {0,};	
#endif

	for(i=0; i < lk; i++) 
	{
		for( j = 0; j < len[i]; j++)
			idx[i][j] = idxs[j];
	}
	
	mb = (stPoly**)malloc(sizeof(stPoly*) * l);
	for (i = 0; i < l; i++)
	{
		mb[i] = (stPoly*)malloc(sizeof(stPoly) * l);

		for (j = 0; j < l; j++)
			mb[i][j] = poly_alloc(5000);
	}

	sprintf(title, "%s.csv", filename);
	test_read_val(mb, title);
	
	//printf("state M = %d\n", state(mb, l)); fprintf(fp, "state M = %d\n", state(mb, l));
	
	start = (((double)clock()) / CLOCKS_PER_SEC);
	for (i = 0; i < lk; i++)
	{
		for (j = 0; j < len[i]; j++)
			sub[j] = mb[idx[i][j]];

		WeakPopovFormSub_swap(sub, len[i], l);
		//WeakPopovFormSub_nonSwap(sub, len[i], l);
		/*{
			sprintf(title, "%s_swap_%d.csv", filename, i);
			test_write_val(mb, l, l, title);
		}*/
		
		printf("%d pCnt=%d\n", i, pCnt);	
		//printf("state%d = %d, pCnt=%d\n", i, state(mb, l), pCnt);	
		//fprintf(fp, "state%d = %d pCnt=%d\n", i, state(mb, l), pCnt);
	}
	end = (((double)clock()) / CLOCKS_PER_SEC);

	{
		sprintf(title, "%s_swap.csv", filename);
		test_write_val(mb, l, l, title);
	}
	
	for(i = 0; i < l; i++)
	{		
		for(j = 0; j < l; j++)
			poly_free(mb[i][j]);
	}
	free(mb);
	free(sub);

	return (end - start);
}

void minima(char* filename, int l)
{
	int i, j;
	stPoly** mb;
	int rowdeg;
	int idx = 0, min = 3000;
	char title[100];

	mb = (stPoly**)malloc(sizeof(stPoly*) * l);

	for (i = 0; i < l; i++)
	{
		mb[i] = (stPoly*)malloc(sizeof(stPoly) * l);

		for (j = 0; j < l; j++)
			mb[i][j] = poly_alloc(3000);
	}

	sprintf(title, "%s.csv", filename);
	test_read_val(mb, title);

	for (i = 0; i < l; i++)
	{
		rowdeg = mb[i][0]->d;
		for (j = 1; j < l; j++)
		{
			if (rowdeg < mb[i][j]->d)
				rowdeg = mb[i][j]->d;
		}

		if (rowdeg < min)
		{
			min = rowdeg;
			idx = i;
		}
	}
	printf("min = %d\n", min);

	for (i = 0; i < l; i++)
	{
		printf("phi[%d] = ", i);
		for (j = 0; j < mb[idx][i]->d; j++)
			printf("F.fetch_int(%u)*x^%d + ", mb[idx][i]->c[j], j);
		
		
		printf("F.fetch_int(%u)*x^%d ", mb[idx][i]->c[j], j);
		printf("\n");
	}
}

void test_goppa()//Edited on 2023-02-08
{
	int i, k, t0, u, l, f;
	uint64_t *y;
	stPoly delta;

	char title[100];
	double avg1 = 0, avg2 = 0, rst;
	
	int err[100] = {0, };	
	
	FILE *fp = NULL;
	
	int *idx;
	int z, j;
	
	gpp_init();
			
	sprintf(title, "performance_%d.txt", _M);
	if ((fp = fopen(title, "a")) == NULL) {
		printf("file write error\n");
		return;
	}
	
	for(i=0; i<100; i++)
		title[i] = 0x00;
	
	y = (uint64_t *)calloc(BYTE_N, sizeof(uint64_t));
	
	u = (int)floor(_N - _T - sqrt(_N * (_N - 2 * _T - 2)));
	printf("the max number of u is %d\n", u);
	u = _U;
	printf("u=%d\n", u);
	
	/*
	printf("u: "); scanf("%d", &u);
	if (u > floor(_N - _T - sqrt(_N * (_N - 2 * _T - 2))))
	{
		printf("error u\n");
		return;
	}*///Edited on 2023-02-08
	
	for(f = 101; f < 102; f++) { //<< start loop//37
		int errVector[_N] = {0,};
		int errCnt = 0;
		
		for (i = 0; i < BYTE_N; i++)
			y[i] = 0;
		
		/* generate errors */
		do {
			int tmp = rand() % _N;
			if(errVector[tmp] == 0) {
				errVector[tmp] = 1;
				err[errCnt] = tmp;
				errCnt += 1;
			}
		}while( errCnt < (_T + u) );
		//err[0]=77;	err[1]=5;	err[2]=15;	err[3]=49;	err[4]=10;	err[5]=111;	err[6]=26;	err[7]=103;	err[8]=97;	err[9]=1;	err[10]=123;	err[11]=4;	err[12]=8;	err[13]=31;	err[14]=101;	err[15]=120;	err[16]=24;	err[17]=125;
		//err[0]=0; err[1]=1; err[2]=2;
		
		err[0]=12;	err[1]=35;	err[2]=22;	err[3]=4;	err[4]=59;	err[5]=29;	err[6]=15;	err[7]=52;	err[8]=9;	err[9]=26;	err[10]=39;
		
		printf("err %d = ", f);
		for (i = 0; i < _T + u; i++)
			printf("%d ", err[i]);
		printf("\n");
				
		fprintf(fp, "err %d = ", f);
		for (i = 0; i < _T + u; i++) {
			fprintf(fp, "%d ", err[i]);
		}
		fprintf(fp, "\n");

		printf("u = %d\n", u);
		for (i = 0; i < _T + u; i++)
			VEC_SET_BIT(y, i, 1);//VEC_SET_BIT(y, err[i], 1);
			
		gpp_bernstein1(y, &delta, u, &t0, &k); //Edited on 2023-02-08
		//printf("k: "); scanf("%d", &k); //Edited on 2023-02-08

		k = _LATTICE_K;

		if (((-k) & k) != k) {
			printf("k is not a power of 2\n");
			return;
		}	
		gpp_bernstein2(delta, k, u, t0, &l, f); //create a lattice

		printf("lattice creation complete %d\n", f);

		idx = (int*)malloc(sizeof(int) * l);

		{		
			sprintf(title, "my_lattice_m%d_t%d_u%d_lk%d_l%d_%d", _M, _T, u, k, l, f);
			/*
			pCnt = 0;
			rst = WeakPopovFormSub(title, k, l, idx, len);
			printf("subexcutiontime = %.2lf ", rst);
			printf("subsamepivotcnt = %d\n", pCnt);
			*/
			
			/*
			pCnt = 0;
			rst = WeakPopovFormSwap(title, l);
			printf("origin = %.2lf ", rst);
			printf("origin = %d\n", pCnt);
			*/
					
		
			/*idx_rand(idx, l);			
			for(i=0; i<l; i++){
				printf("%d ", idx[i]); fprintf(fp, "%d ", idx[i]);
			}
			printf("\n"); fprintf(fp, "\n");
			
			
			pCnt = 0;
			rst = WeakPopovFormSwap(title, idx, l);
			printf("random = %.2lf ", rst); printf("random = %d\n", pCnt); 
			fprintf(fp, "random = %.2lf ", rst); fprintf(fp, "random = %d\n ", pCnt);
			*/		 

			idx_org(idx, l);
			for(i=0; i<l; i++) { printf("%d ", idx[i]);  } printf("\n"); 

			pCnt = 0; nRow = 0;
			//rst = WeakPopovFormSwap(title, idx, l);
			//rst = WeakPopovForm_nonSwap(title, idx, l);
			rst = WeakPopovFormSub(fp, title, k, l, idx);
			
			//rst = realtimeWeakPopovForm_nonSwap(title, idx, l);
			//rst = WeakPopovForm_nonSwap_RealTime(title, idx, l);
			
			printf("original = %.2lf ", rst); printf("original = %d\n", pCnt); 
			fprintf(fp, "original = %.2lf ", rst); fprintf(fp, "original = %d\n", pCnt);		

			//proposed2
			/*
			#if _M == 6				
				#if _U == 2
					idx[0]=0;	idx[1]=8;	idx[2]=16;	idx[3]=24;	idx[4]=32;	idx[5]=40;	idx[6]=4;	idx[7]=12;	idx[8]=20;	idx[9]=28;	idx[10]=36;	idx[11]=2;	idx[12]=10;	idx[13]=18;	idx[14]=26;	idx[15]=34;	idx[16]=6;	idx[17]=14;	idx[18]=22;	idx[19]=30;	idx[20]=38;	idx[21]=1;	idx[22]=9;	idx[23]=17;	idx[24]=25;	idx[25]=33;	idx[26]=41;	idx[27]=3;	idx[28]=11;	idx[29]=19;	idx[30]=27;	idx[31]=35;	idx[32]=5;	idx[33]=13;	idx[34]=21;	idx[35]=29;	idx[36]=37;	idx[37]=7;	idx[38]=15;	idx[39]=23;	idx[40]=31;	idx[41]=39;
				#elif _U == 1
					idx[0]=0;	idx[1]=4;	idx[2]=8;	idx[3]=12;	idx[4]=2;	idx[5]=6;	idx[6]=10;	idx[7]=14;	idx[8]=1;	idx[9]=5;	idx[10]=9;	idx[11]=13;	idx[12]=3;	idx[13]=7;	idx[14]=11;
				#endif
			#elif _M == 7
				idx[0]=0;	idx[1]=4;	idx[2]=8;	idx[3]=12;	idx[4]=16;	idx[5]=20;	idx[6]=24;	idx[7]=28;	idx[8]=2; idx[9]=6;	idx[10]=10;	idx[11]=14;	idx[12]=18;	idx[13]= 22;	idx[14]=26;	idx[15]=1;	idx[16]=5;	idx[17]=9;	idx[18]=13;	idx[19]=17;	idx[20]=21;	idx[21]=25;	idx[22]=29;	idx[23]=3; 	idx[24]= 7;	idx[25]= 11;	idx[26]= 15;	idx[27]=19;	idx[28]=23;	idx[29]=27;
			#elif _M == 8
				idx[0]=0;	idx[1]=8;	idx[2]=16;	idx[3]=24;	idx[4]=32;	idx[5]=40;	idx[6]=48;	idx[7]=56;	idx[8]=64;	idx[9]=72;	idx[10]=80;	idx[11]=4;	idx[12]=12;	idx[13]=20;	idx[14]=28;	idx[15]=36;	idx[16]=44;	idx[17]=52;	idx[18]=60;	idx[19]=68;	idx[20]=76;	idx[21]=84;	idx[22]=2;	idx[23]=10;	idx[24]=18;	idx[25]=26;	idx[26]=34;	idx[27]=42;	idx[28]=50;	idx[29]=58;	idx[30]=66;	idx[31]=74;	idx[32]=82;	idx[33]=6;	idx[34]=14;	idx[35]=22;	idx[36]=30;	idx[37]=38;	idx[38]=46;	idx[39]=54;	idx[40]=62;	idx[41]=70;	idx[42]=78;	idx[43]=86;	idx[44]=1;	idx[45]=9;	idx[46]=17;	idx[47]=25;	idx[48]=33;	idx[49]=41;	idx[50]=49;	idx[51]=57;	idx[52]=65;	idx[53]=73;	idx[54]=81;	idx[55]=3;	idx[56]=11;	idx[57]=19;	idx[58]=27;	idx[59]=35;	idx[60]=43;	idx[61]=51;	idx[62]=59;	idx[63]=67;	idx[64]=75;	idx[65]=83;	idx[66]=5;	idx[67]=13;	idx[68]=21;	idx[69]=29;	idx[70]=37;	idx[71]=45;	idx[72]=53;	idx[73]=61;	idx[74]=69;	idx[75]=77;	idx[76]=85;	idx[77]=7;	idx[78]=15;	idx[79]=23;	idx[80]=31;	idx[81]=39;	idx[82]=47;	idx[83]=55;	idx[84]=63;	idx[85]=71;	idx[86]=79;			
			#elif _M == 4
				idx[0]=0;	idx[1]=4;	idx[2]=8;	idx[3]=12;	idx[4]=2;	idx[5]=6;	idx[6]=10;	idx[7]=1;	idx[8]=5;	idx[9]=9;	idx[10]=13;	idx[11]=3;	idx[12]=7;	idx[13]=11;
			#elif _M == 5
				idx[0]=0;	idx[1]=4;	idx[2]=8;	idx[3]=12;	idx[4]=16;	idx[5]=20;	idx[6]=2;	idx[7]=6;	idx[8]=10;	idx[9]=14;	idx[10]=18;	idx[11]=1;	idx[12]=5;	idx[13]=9;	idx[14]=13;	idx[15]=17;	idx[16]=3;	idx[17]=7;	idx[18]=11;	idx[19]=15;	idx[20]=19;	
			#endif
			for(i=0; i<l; i++) { printf("%d ", idx[i]);  } printf("\n"); 
			
			pCnt = 0;	nRow = 0;
			rst = WeakPopovFormSub(fp, title, k, l, idx);
			
			printf("proposed2 = %.2lf ", rst); printf("proposed2 = %d\n", pCnt); 
			fprintf(fp, "proposed2 = %.2lf ", rst); fprintf(fp, "proposed2 = %d\n", pCnt);		
			*/
			
			/*
			idx_proposed1(idx, k, l);			
			for(i=0; i<l; i++)
				printf("%d ", idx[i]);
			printf("\n");			

			pCnt = 0;
			rst = WeakPopovFormSub(fp, title, k, l, idx);//WeakPopovForm_nonSwap(title, idx, l);
			printf("proposed1 = %.2lf ", rst); printf("proposed1 = %d\n", pCnt);
			fprintf(fp, "proposed1 = %.2lf ", rst); fprintf(fp, "proposed1 = %d\n", pCnt);
			*/
			

			idx_proposed3(idx, k, l);
			for(i=0; i<l; i++)
				printf("%d ", idx[i]);
			printf("\n");

			pCnt = 0;
			rst = WeakPopovFormSub(fp, title, k, l, idx);//rst = WeakPopovForm_nonSwap(title, idx, l);			
			printf("proposed3 = %.2lf ", rst); printf("proposed3 = %d\n", pCnt);
			fprintf(fp, "proposed3 = %.2lf ", rst); fprintf(fp, "proposed3 = %d\n", pCnt);
			
		}	

		{
			sprintf(title, "my_lattice_m%d_t%d_u%d_lk%d_l%d_%d_swap", _M, _T, u, k, l, f);
			//sprintf(title, "my_lattice_m%d_t%d_u%d_lk%d_l%d_%d_sub_swap", _M, _T, u, k, l, f);
			minima(title, l);
		}

		free(idx);
	
	}//<< end loop
	fclose(fp);
	free(y);
	return;
}

void test_weak()
{
	//m=4
	int idx[9] = {0,1,2,3,4,5,6,7,8};
	//int idx[9] = {0,4,8,2,6,1,5,3,7};
	
	//m=6
	//int idx[3] = {0,1,2}; //4 > 8
	//int idx[3] = {0,2,1}; //1 > 6
	//int idx[3] = {1,2,0}; //4 > 10
	//int idx[3] = {1,0,2}; //4 > 8
	//int idx[3] = {2,1,0}; //4 > 10
	//int idx[3] = {2,0,1}; //1 > 6 
	
	double rst;
	FILE *fp = NULL;
	char title[100];
	
	gpp_init();
				
	sprintf(title, "performance_%d.txt", _M);
	if ((fp = fopen(title, "a")) == NULL) {
		printf("file write error\n");
		return;
	}
	
	
	pCnt = 0;	
	//rst = WeakPopovFormSub(fp, "test_m6_lk2_l3",  2,  3,  idx);
	rst = WeakPopovFormSub(fp, "test_m4_lk4_l9",  4,  9,  idx);
	printf("proposed3 = %.2lf ", rst); printf("proposed3 = %d\n", pCnt); 
	fclose(fp);
}

