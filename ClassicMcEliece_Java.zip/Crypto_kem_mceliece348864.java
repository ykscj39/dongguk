package mce;

public class Crypto_kem_mceliece348864 {
	public static final int crypto_kem_mceliece348864_ref_PUBLICKEYBYTES = 261120;
	public static final int crypto_kem_mceliece348864_ref_SECRETKEYBYTES = 6492;
	public static final int crypto_kem_mceliece348864_ref_CIPHERTEXTBYTES = 128;
	public static final int crypto_kem_mceliece348864_ref_BYTES = 32;
	
	//extern int crypto_kem_mceliece348864_ref_keypair(unsigned char *,unsigned char *);
	//extern int crypto_kem_mceliece348864_ref_enc(unsigned char *,unsigned char *,const unsigned char *);
	//extern int crypto_kem_mceliece348864_ref_dec(unsigned char *,const unsigned char *,const unsigned char *);
	
	//#define crypto_kem_mceliece348864_keypair crypto_kem_mceliece348864_ref_keypair
	//#define crypto_kem_mceliece348864_enc crypto_kem_mceliece348864_ref_enc
	//#define crypto_kem_mceliece348864_dec crypto_kem_mceliece348864_ref_dec
	public static final int crypto_kem_mceliece348864_PUBLICKEYBYTES = crypto_kem_mceliece348864_ref_PUBLICKEYBYTES;
	public static final int crypto_kem_mceliece348864_SECRETKEYBYTES = crypto_kem_mceliece348864_ref_SECRETKEYBYTES;
	public static final int crypto_kem_mceliece348864_BYTES = crypto_kem_mceliece348864_ref_BYTES;
	public static final int crypto_kem_mceliece348864_CIPHERTEXTBYTES = crypto_kem_mceliece348864_ref_CIPHERTEXTBYTES;
}
