package mce;

public class GF {
	Params params = new Params();

	int length, width;
	
	void setData()
	{
		length=30;
		width=14;
	}
	
	void area()
	{
		int area;
		area = length * width;
		//System.out.println(area);
	}
	
	char gf_iszero(char a)
	{
		long t = a;

		t -= 1;
		t >>>= 19;

		return (char) t;
	}
	
	char gf_add(char in0, char in1)
	{
		return (char) (in0 ^ in1);
	}
	
	char gf_mul(char in0, char in1)
	{
		int i;

		long tmp;
		long t0;
		long t1;
		long t;

		t0 = in0;
		t1 = in1;

		tmp = t0 * (t1 & 1);

		for (i = 1; i < params.GFBITS; i++)
			tmp ^= (t0 * (t1 & (1 << i)));

		t = tmp & 0x7FC000;
		tmp ^= t >>> 9;
		tmp ^= t >>> 12;

		t = tmp & 0x3000;
		tmp ^= t >>> 9;
		tmp ^= t >>> 12;

		return (char) (tmp & ((1 << params.GFBITS)-1));
	}
	
	/* input: field element in */
	/* return: in^2 */
	char gf_sq(char in)
	{
		final long[] B = {0x55555555, 0x33333333, 0x0F0F0F0F, 0x00FF00FF};

		long x = in; 
		long t;

		x = (x | (x << 8)) & B[3];
		x = (x | (x << 4)) & B[2];
		x = (x | (x << 2)) & B[1];
		x = (x | (x << 1)) & B[0];

		t = x & 0x7FC000;
		x ^= t >>> 9;
		x ^= t >>> 12;

		t = x & 0x3000;
		x ^= t >>> 9;
		x ^= t >>> 12;		
		
		return (char) (x & ((1 << params.GFBITS)-1));
	}
	
	char gf_inv(char in)
	{
		char tmp_11;
		char tmp_1111;

		char out = in;

		out = gf_sq(out);
		tmp_11 = gf_mul(out, in); // 11

		out = gf_sq(tmp_11);
		out = gf_sq(out);
		tmp_1111 = gf_mul(out, tmp_11); // 1111

		out = gf_sq(tmp_1111);
		out = gf_sq(out);
		out = gf_sq(out);
		out = gf_sq(out);
		out = gf_mul(out, tmp_1111); // 11111111

		out = gf_sq(out);
		out = gf_sq(out);
		out = gf_mul(out, tmp_11); // 1111111111

		out = gf_sq(out);
		out = gf_mul(out, in); // 11111111111

		return gf_sq(out); // 111111111110
	}
	
	/* input: field element den, num */
	/* return: (num/den) */
	char gf_frac(char den, char num)
	{
		return gf_mul(gf_inv(den), num);
	}
		
	/* input: in0, in1 in GF((2^m)^t)*/
	/* output: out = in0*in1 */
	void GF_mul(char[] out, char[] in0, char[] in1)
	{
		int i, j;

		char[] prod = new char[ params.SYS_T*2-1 ];

		for (i = 0; i < params.SYS_T * 2-1; i++)
			prod[i] = 0;

		for (i = 0; i < params.SYS_T; i++)
			for (j = 0; j < params.SYS_T; j++)
				prod[i+j] ^= gf_mul(in0[i], in1[j]);

		//
	 
		for (i = (params.SYS_T-1)*2; i >= params.SYS_T; i--) {
			prod[i - params.SYS_T + 3] ^= prod[i];
			prod[i - params.SYS_T + 1] ^= prod[i];
			prod[i - params.SYS_T + 0] ^= gf_mul(prod[i], (char) 2);
		}

		for (i = 0; i < params.SYS_T; i++)
			out[i] = prod[i];
	}
}
