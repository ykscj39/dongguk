package mce;

public class Crypto_kem {	
	//#define crypto_kem_keypair crypto_kem_mceliece348864_keypair
	//#define crypto_kem_enc crypto_kem_mceliece348864_enc
	//#define crypto_kem_dec crypto_kem_mceliece348864_dec	
	public final int crypto_kem_PUBLICKEYBYTES  = Crypto_kem_mceliece348864.crypto_kem_mceliece348864_PUBLICKEYBYTES;
	public final int crypto_kem_SECRETKEYBYTES  = Crypto_kem_mceliece348864.crypto_kem_mceliece348864_SECRETKEYBYTES;
	public final int crypto_kem_BYTES 		    = Crypto_kem_mceliece348864.crypto_kem_mceliece348864_BYTES;
	public final int crypto_kem_CIPHERTEXTBYTES = Crypto_kem_mceliece348864.crypto_kem_mceliece348864_CIPHERTEXTBYTES;
	public static final String	crypto_kem_PRIMITIVE = "mceliece348864";
}
