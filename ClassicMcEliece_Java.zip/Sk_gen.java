package mce;

public class Sk_gen {
	Params params = new Params();
	GF gf = new GF();
	
	int genpoly_gen(char[] out, char[] f) {
		int i, j, k, c;
		
		char[][] mat = new char[params.SYS_T + 1][params.SYS_T];
		char mask, inv, t;
		
		mat[0][0] = 1;
		
		for(i=1; i < params.SYS_T; i++)
			mat[0][i] = 0;
		
		for(i=0; i < params.SYS_T; i++)
			mat[1][i] = f[i];
		
		for(j=2; j <= params.SYS_T; j++)
			gf.GF_mul(mat[j], mat[j-1], f);
		
		// gaussian

		for (j = 0; j < params.SYS_T; j++)
		{
			for (k = j + 1; k < params.SYS_T; k++)
			{
				mask = gf.gf_iszero(mat[ j ][ j ]);

				for (c = j; c < params.SYS_T + 1; c++)
					mat[ c ][ j ] ^= mat[ c ][ k ] & mask;

			}

			if ( mat[ j ][ j ] == 0 ) // return if not systematic
			{
				return -1;
			}

			inv = gf.gf_inv(mat[j][j]);

			for (c = j; c < params.SYS_T + 1; c++)
				mat[ c ][ j ] = gf.gf_mul(mat[ c ][ j ], inv) ;

			for (k = 0; k < params.SYS_T; k++)
			{
				if (k != j)
				{
					t = mat[ j ][ k ];

					for (c = j; c < params.SYS_T + 1; c++)
						mat[ c ][ k ] ^= gf.gf_mul(mat[ c ][ j ], t);
				}
			}
		}

		for (i = 0; i < params.SYS_T; i++)
			out[i] = mat[ params.SYS_T ][ i ];
		
		return 0;		
	}
}
