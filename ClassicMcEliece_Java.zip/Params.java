package mce;

public class Params {
	
	public static final int GFBITS = 12;
	public static final int SYS_N = 3488;
	public static final int SYS_T = 64;

	public static final int COND_BYTES = ((1 << (GFBITS-4))*(2*GFBITS - 1));
	public static final int IRR_BYTES = (SYS_T * 2);

	public static final int PK_NROWS = (SYS_T*GFBITS); 
	public static final int PK_NCOLS = (SYS_N - PK_NROWS);
	public static final int PK_ROW_BYTES = ((PK_NCOLS + 7)/8);

	public static final int SYND_BYTES = ((PK_NROWS + 7)/8);

	public static final int GFMASK = ((1 << GFBITS) - 1);
	
	public static final boolean KAT = true;

}
