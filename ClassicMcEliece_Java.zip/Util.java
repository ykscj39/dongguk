package mce;

public class Util {
	Params params = new Params();
	
	void store_gf(byte[] dest, char a)
	{
		dest[0] = (byte) (a & 0xFF);
		dest[1] = (byte) (a >> 8);
	}
	
	char load_gf(final byte[] src){
		char a;
		a = (char) (src[1] & 0x00ff);
		a <<= 8;
		a |= (src[0] & 0x00ff);;
		
		return (char) (a & params.GFMASK);		
	}
	
	int load4(final byte[] in)
	{
		int i;
		int ret = in[3] & 0x000000ff;

		for (i = 2; i >= 0; i--)
		{
			ret <<= 8;
			ret |= (in[i] & 0x000000ff);
		}

		return ret;
	}
	
	void store8(byte[] out, long in)
	{
		out[0] = (byte) ((in >>> 0x00) & 0xFF);
		out[1] = (byte) ((in >>> 0x08) & 0xFF);
		out[2] = (byte) ((in >>> 0x10) & 0xFF);
		out[3] = (byte) ((in >>> 0x18) & 0xFF);
		out[4] = (byte) ((in >>> 0x20) & 0xFF);
		out[5] = (byte) ((in >>> 0x28) & 0xFF);
		out[6] = (byte) ((in >>> 0x30) & 0xFF);
		out[7] = (byte) ((in >>> 0x38) & 0xFF);
	}
	
	long load8(final byte[] in)
	{
		int i;
		long ret = in[7] & 0x00000000000000FFL;

		for (i = 6; i >= 0; i--)
		{
			ret <<= 8;
			ret |= (in[i] & 0x00000000000000FFL);
		}

		return ret;
	}
	
	char bitrev(char a)
	{
		a = (char) (((a & 0x00FF) << 8) | ((a & 0xFF00) >> 8));
		a = (char) (((a & 0x0F0F) << 4) | ((a & 0xF0F0) >> 4));
		a = (char) (((a & 0x3333) << 2) | ((a & 0xCCCC) >> 2));
		a = (char) (((a & 0x5555) << 1) | ((a & 0xAAAA) >> 1));
		
		return (char) (a >> 4);
	}

}
