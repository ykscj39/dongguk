package mce;

public class Uint64_sort {
	public class NumberClass{
		long num;
		NumberClass (long num){
			this.num = num;
		}
	}
	
	static void uint64_MINMAX (NumberClass a, NumberClass b) {
		do {
			long c = b.num - a.num;
			c >>>= 63;
			c = -c;
			c &= a.num ^ b.num;
			a.num ^= c;
			b.num ^= c;
		} while(false);
	}
	
	static void uint64_sort(long[] x, long n) {
		long top, p, q, r, i;
		Uint64_sort obj = new Uint64_sort();
		Uint64_sort.NumberClass num1 = obj.new NumberClass(0);
		Uint64_sort.NumberClass num2 = obj.new NumberClass(0);
		
		if (n < 2) return;
		
		top = 1;
		while (top < n - top) top += top;
		//System.out.println("n:" + n);
		//System.out.println("top:"+ top);
		//Pri.longHexPri(x);
		for (p = top; p > 0; p >>= 1) {
			for (i = 0; i < n - p; ++i) {
				if ((i & p) == 0) {
					num1.num = x[(int) i]; num2.num = x[(int) (i + p)];
					uint64_MINMAX(num1, num2);
					x[(int) i] = num1.num; x[(int) (i + p)] = num2.num;
				}
			}
			i = 0;
			for (q = top;q > p;q >>= 1) {
				for (; i < n - q; ++i) {
					if ((i & p) == 0) {
						long a = x[(int) (i + p)];
						
						for (r = q; r > p; r >>= 1) {
							num1.num = a; num2.num = x[(int) (i + r)];
							uint64_MINMAX(num1, num2);
							a = num1.num; x[(int) (i + r)] = num2.num;
						}
						x[(int) (i + p)] = a;
					}
				}
			}
		}
	}
}
