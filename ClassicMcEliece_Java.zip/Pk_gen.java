package mce;

public class Pk_gen {

	Pri pri = new Pri();
	Params params = new Params();
	Util util = new Util();
	GF gf = new GF();
	Uint64_sort uint64_sort = new Uint64_sort();
	Root root = new Root();
		
	/* input: secret key sk */
	/* output: public key pk */
	int pk_gen(byte[] pk, byte[] sk, int[] perm, short[] pi)
	{
		int i, j, k;
		int row, c;

		long[] buf = new long[ 1 << Params.GFBITS ];

		byte[][] mat = new byte[ Params.PK_NROWS ][ Params.SYS_N/8 ];
		byte mask;
		byte b;

		char[] g = new char[ Params.SYS_T + 1 ]; // Goppa polynomial
		char[] L = new char[ Params.SYS_N ]; // support
		char[] inv = new char[ Params.SYS_N ];
		
		byte[] tmp = new byte[2];

		//System.out.print("sk(pkgen):"); pri.byteHexPri(sk);
		
		g[ Params.SYS_T ] = 1;

		for (i = 0; i < Params.SYS_T; i++) { 
			System.arraycopy(sk, i * 2, tmp, 0, 2);
			g[i] = util.load_gf(tmp);
		}
		//System.out.print("g(pkgen):"); pri.charHexPri(g);
		
		for (i = 0; i < (1 << Params.GFBITS); i++)
		{			
			buf[i] = (perm[i] & 0x00000000ffffffffL);
			buf[i] <<= 31;			
			buf[i] |= i;
		}
		//System.out.print("buf1:"); pri.longHexPri(buf);
				
		uint64_sort.uint64_sort(buf, 1 << Params.GFBITS);
		//System.out.print("buf2:"); pri.longHexPri(buf);

		for (i = 1; i < (1 << Params.GFBITS); i++) {
			if ((buf[i-1] >>> 31) == (buf[i] >>> 31)) {
				return -1; 
			}
		}
		
		for (i = 0; i < (1 << Params.GFBITS); i++) pi[i] = (short) (buf[i] & Params.GFMASK);
		//System.out.println("pi");
		//pri.charHexPri(pi);
		
		for (i = 0; i < Params.SYS_N; i++) L[i] = util.bitrev((char) pi[i]);
		//System.out.println("L");
		//pri.charHexPri(L);
					
		// filling the matrix			
		for (i = 0; i < Params.SYS_N; i++)
		{
			char r = g[Params.SYS_T];
			for (j = Params.SYS_T-1; j >= 0; j--)
			{
				r = gf.gf_mul(r, L[i]);
				r = gf.gf_add(r, g[j]);
			}
			inv[i] = r;
		}
		//System.out.println("inv");
		//pri.charHexPri(inv);
		
		root.root(inv, g, L);
		//System.out.println("inv");
		//pri.charHexPri(inv);
		
		for (i = 0; i < Params.SYS_N; i++)
			inv[i] = gf.gf_inv(inv[i]);
		//System.out.println("inv");
		//pri.charHexPri(inv);
		
		for (i = 0; i < Params.PK_NROWS; i++) {
			for (j = 0; j < Params.SYS_N/8; j++)
				mat[i][j] = 0;
		}
		
		for (i = 0; i < Params.SYS_T; i++)
		{
			for (j = 0; j < Params.SYS_N; j+=8) {
				for (k = 0; k < Params.GFBITS;  k++)
				{
					b  = (byte) ((inv[j+7] >>> k) & 1); b <<= 1;
					b |= (inv[j+6] >>> k) & 1; b <<= 1;
					b |= (inv[j+5] >>> k) & 1; b <<= 1;
					b |= (inv[j+4] >>> k) & 1; b <<= 1;
					b |= (inv[j+3] >>> k) & 1; b <<= 1;
					b |= (inv[j+2] >>> k) & 1; b <<= 1;
					b |= (inv[j+1] >>> k) & 1; b <<= 1;
					b |= (inv[j+0] >>> k) & 1;
					
					mat[ i*Params.GFBITS + k ][ j/8 ] = b;
				}
			}
				
			for (j = 0; j < Params.SYS_N; j++)
				inv[j] = gf.gf_mul(inv[j], L[j]);
		}
		
		//System.out.println("mat");
		//for (i = 0; i < PAR.PK_NROWS; i++)
			//pri.charHexPri(mat[i]);
		
		// gaussian elimination

		for (i = 0; i < (Params.PK_NROWS + 7) / 8; i++)
		for (j = 0; j < 8; j++)
		{
			row = i*8 + j;			

			if (row >= Params.PK_NROWS)
				break;

			for (k = row + 1; k < Params.PK_NROWS; k++)
			{
				mask = (byte) (mat[ row ][ i ] ^ mat[ k ][ i ]);
				mask >>>= j;
				mask &= 1;
				mask = (byte) -mask;//should check

				for (c = 0; c < Params.SYS_N/8; c++)
					mat[ row ][ c ] ^= mat[ k ][ c ] & mask;
			}

			if ( ((mat[ row ][ i ] >>> j) & 1) == 0 ) // return if not systematic
			{
				//System.out.println("not systematic");
				return -1;
			}

			for (k = 0; k < Params.PK_NROWS; k++)
			{
				if (k != row)
				{
					mask = (byte) (mat[ k ][ i ] >> j);
					mask &= 1;
					mask = (byte) -mask;

					for (c = 0; c < Params.SYS_N/8; c++)
						mat[ k ][ c ] ^= mat[ row ][ c ] & mask;
				}
			}
		}
		
		for (i = 0; i < Params.PK_NROWS; i++) 
			System.arraycopy(mat[i], Params.PK_NROWS/8, pk, i * Params.PK_ROW_BYTES, Params.PK_ROW_BYTES);
				
		return 0;
	}
}
