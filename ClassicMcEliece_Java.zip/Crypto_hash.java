package mce;

public class Crypto_hash {

	Sha3 sha3 = new Sha3();
	
	void crypto_hash_32b(byte[] out, byte[] in, long inlen) {
		sha3.shake256(in, (int) inlen, out, 32);	
	}
	
	void shake(byte[] out, int outlen, byte[] in, long inlen) {
		sha3.shake256(in, (int) inlen, out, outlen);
	}
}