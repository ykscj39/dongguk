package mce;

import java.util.Arrays;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.SecretKeySpec;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

public class Rng {
	public static final int RNG_SUCCESS = 0;
	public static final int RNG_BAD_MAXLEN = -1;
	public static final int RNG_BAD_OUTBUF = -2;
	public static final int RNG_BAD_REQ_LEN = -3;
	
	Pri pri = new Pri();
	
	public final class AES_XOF_struct {
		byte [] buffer = new byte[16];
	    int     buffer_pos;
	    long    length_remaining;
	    byte [] key = new byte[32];
	    byte [] ctr = new byte[16];
	    
	    // point initialized from parameters
	    public AES_XOF_struct(byte[] buffer, int buffer_pos, long length_remaining, byte[] key, byte[] ctr) {
	    	this.buffer = buffer;
	    	this.buffer_pos = buffer_pos;
	    	this.length_remaining = length_remaining;
	    	this.key = key;
	    	this.ctr = ctr;
	    }

	    // accessor methods
	    public byte[] buffer()			 { return buffer; }
	    public int 	  buffer_pos()		 { return buffer_pos; }
	    public long   length_remaining() { return length_remaining; }
	    public byte[] key()			 	 { return key; }
	    public byte[] ctr()			 	 { return ctr; }
	}
	
	public final static class AES256_CTR_DRBG_struct {
		public static volatile byte[] Key;
		public static volatile byte[] V;
		public static volatile int reseed_counter;
	    
	    // point initialized from parameters
	    public AES256_CTR_DRBG_struct() {
	    	this.Key = new byte[32];
	    	this.V   = new byte[16];
	    }
	    
		// accessor methods
	    public byte[] Key() { return Key; }
	    public byte[] V()	{ return V; }
	    public int reseed_counter() { return reseed_counter; }
	}
		
	AES256_CTR_DRBG_struct DRBG_ctx = new AES256_CTR_DRBG_struct();
	
	void randombytes_init(byte[] entropy_input, byte[] personalization_string, int security_strength) {
		byte[] seed_material = new byte[48];
	    int i;    
	    
	    System.arraycopy(entropy_input, 0, seed_material, 0, entropy_input.length);
	    if(personalization_string != null) {
	    	for (i=0; i < 48; i++)
	    		seed_material[i] ^= personalization_string[i];
	    }
	    
	    Arrays.fill(DRBG_ctx.Key, (byte) 0);
	    Arrays.fill(DRBG_ctx.V, (byte) 0);
	    AES256_CTR_DRBG_Update(seed_material, DRBG_ctx.Key, DRBG_ctx.V);
	    DRBG_ctx.reseed_counter = 1;
	    
	    //System.out.print("DRBG_ctx.Key:"); pri.byteHexPri(DRBG_ctx.Key);
	    //System.out.print("DRBG_ctx.V:"); pri.byteHexPri(DRBG_ctx.V);
	}
	
	void AES256_CTR_DRBG_Update (byte[] provided_data, byte[] Key, byte[] V) {
		byte[] temp = new byte[48];
		int i;
		int j;
		
		for (i=0; i<3; i++) {
			/* increment V */
			for (j=15; j>=0; j--) {
				if ( V[j] == (byte) 0xff )
	            	V[j] = 0x00;
	            else {
	            	char b = 0;
	            	b ^= V[j];
	            	b++;
	            	V[j] = (byte) (b & 0xFF);
	            	//V[j]++;
	                break;
	            }
	        }
			
			try {
				byte[] block = new byte[16];
				AES256_ECB(Key, V, block);//AES256_ECB(Key, V, temp, 16 * i);
				System.arraycopy(block, 0, temp, 16 * i, 16);
				
			} catch (InvalidKeyException | NoSuchAlgorithmException | NoSuchPaddingException | IllegalBlockSizeException
					| BadPaddingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} //주소로 넘길 없어 파라미터 추가	         
	    }
		
		if ( provided_data != null )
	        for (i=0; i<48; i++)
	            temp[i] ^= provided_data[i];
		
		System.arraycopy(temp, 0, Key, 0, 32);
		System.arraycopy(temp, 32, V, 0, 16);
	}
	
	void AES256_ECB(byte[] key, byte[] ctr, byte[] buffer) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException {
		final String alg = "AES/ECB/PKCS5Padding";
		 Cipher cipher = Cipher.getInstance(alg);
		 SecretKeySpec keySpec = new SecretKeySpec(key, "AES");
		 cipher.init(Cipher.ENCRYPT_MODE, keySpec);
		 
		 byte[] cipherByte = cipher.doFinal(ctr);
		 System.arraycopy(cipherByte, 0, buffer, 0, 16);
	}
	
	int	randombytes(byte[] x, long xlen) {
		byte[] block = new byte[16];
		int i = 0;
		int j;
		
		//System.out.print("randombytes x:"); pri.byteHexPri(x);
		//System.out.print("randombytes DRBG_ctx.V:"); pri.byteHexPri(DRBG_ctx.V);
		while ( xlen > 0 ) {
	        /* increment V */
	        for (j=15; j >= 0; j--) {
	            if ( DRBG_ctx.V[j] == (byte) 0xff ) {	            	
	                DRBG_ctx.V[j] = 0x00;
	            }
	            else {	            	
	            	char b = (char) (0x0000 ^ DRBG_ctx.V[j]);
	            	b++;
	            	DRBG_ctx.V[j] = (byte) (b & 0xff);
	            	//DRBG_ctx.V[j]++;
	                break;
	            }
	        }	            
	        
	        try {
				AES256_ECB(DRBG_ctx.Key, DRBG_ctx.V, block);
			} catch (InvalidKeyException | NoSuchAlgorithmException | NoSuchPaddingException | IllegalBlockSizeException
					| BadPaddingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	        
	        if ( xlen > 15 ) {
	        	System.arraycopy(block, 0, x, i, 16);
	            i += 16;
	            xlen -= 16;
	        }
	        else {
	        	System.arraycopy(block, 0, x, i, (int)xlen);
	            xlen = 0;
	        }	        
	    }		
		
	    AES256_CTR_DRBG_Update(null, DRBG_ctx.Key, DRBG_ctx.V);
	    DRBG_ctx.reseed_counter++;		
	    //System.out.print("randombytes x:"); pri.byteHexPri(x);	    
		return RNG_SUCCESS;		
	}
}
