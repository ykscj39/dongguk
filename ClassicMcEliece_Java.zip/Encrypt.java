package mce;

public class Encrypt {
	static Params params = new Params();
	static Rng rng = new Rng();
	static Util util = new Util(); 
	
	class union{
		char[] nums = new char[ params.SYS_T * 2 ];
		byte[] bytes = new byte[ params.SYS_T*2 * Character.BYTES ];
	}
	
	static byte same_mask(char x, char y)
	{
		int mask;

		mask = x ^ y;
		mask -= 1;
		mask >>>= 31;
		mask = -mask;

		return (byte) (mask & 0xFF);
	}
		
	/* output: e, an error vector of weight t */
	static void gen_e(byte[] e) {
		int i, j, eq, count;
		Encrypt obj = new Encrypt();
		union buf = obj.new union();
		
		char[] ind = new char[ params.SYS_T ];
		byte mask;	
		byte[] val = new byte[ params.SYS_T ];	
	
		while (true) {
			//System.out.println("encrypt:buf.bytes["+buf.bytes.length+"]"); 
			rng.randombytes(buf.bytes, buf.bytes.length);
			
			for (i = 0; i < params.SYS_T*2; i++) {
				byte[] tmp = new byte[2];
				System.arraycopy(buf.bytes, i * 2, tmp, 0, 2);
				buf.nums[i] = util.load_gf(tmp);
			}
			
			// moving and counting indices in the correct range

			count = 0;
			for (i = 0; i < params.SYS_T*2 && count < params.SYS_T; i++) {
				if (buf.nums[i] < params.SYS_N)
					ind[ count++ ] = buf.nums[i];
			}
			
			if (count < params.SYS_T) continue;

			// check for repetition

			eq = 0;
			for (i = 1; i < params.SYS_T; i++) { 
				for (j = 0; j < i; j++) {
					if (ind[i] == ind[j]) 
						eq = 1;
				}
			}

			if (eq == 0)
				break;
		}

		for (j = 0; j < params.SYS_T; j++)
			val[j] = (byte) (1 << (ind[j] & 7));

		for (i = 0; i < params.SYS_N/8; i++) {
			e[i] = 0;

			for (j = 0; j < params.SYS_T; j++) {
				mask = same_mask((char) i, (char) (ind[j] >>> 3));
				e[i] |= val[j] & mask;
			}
		}
	}
	
	/* input: public key pk, error vector e */
	/* output: syndrome s */
	static void syndrome(byte[] s, final byte[] pk, byte[] e)
	{
		byte b;
		byte[] row = new byte[params.SYS_N/8];
		int pk_ptr = 0;

		int i, j;

		for (i = 0; i < params.SYND_BYTES; i++)
			s[i] = 0;

		for (i = 0; i < params.PK_NROWS; i++)	
		{
			for (j = 0; j < params.SYS_N/8; j++) 
				row[j] = 0;

			for (j = 0; j < params.PK_ROW_BYTES; j++) 
				row[ params.SYS_N/8 - params.PK_ROW_BYTES + j ] = pk[pk_ptr + j];

			row[i/8] |= 1 << (i%8);
			
			b = 0;
			for (j = 0; j < params.SYS_N/8; j++)
				b ^= row[j] & e[j];

			b ^= b >>> 4;
			b ^= b >>> 2;
			b ^= b >>> 1;
			b &= 1;

			s[ i/8 ] |= (b << (i%8));

			pk_ptr += params.PK_ROW_BYTES;
		}
	}
	
	void encrypt(byte[] s, final byte[] pk, byte[] e) {
		gen_e(e);
		if (params.KAT) {
			int k;
			System.out.print("encrypt e: positions");
			for (k = 0; k < params.SYS_N; ++k) {
				if ( (e[k/8] & (1 << (k & 7))) != 0 )
					System.out.print(" " + k);
			}
			System.out.println();
		}
		syndrome(s, pk, e);
	}
}
