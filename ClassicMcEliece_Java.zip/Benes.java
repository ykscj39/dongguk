package mce;
public class Benes {
	static Pri pri = new Pri();
	static Params params = new Params();
	static Util util = new Util();
	static Transpose transpose = new Transpose();
	
	/* one layer of the benes network */
	static void layer(long[] data, long[] bits, int lgs) {
		int i, j, s;
		long d;		
		int bits_ptr = 0;
		
		s = 1 << lgs;

		for (i = 0; i < 64; i += s*2) {
			for (j = i; j < i+s; j++)
			{
				d = (data[j+0] ^ data[j+s]);
				d &= bits[bits_ptr];
				data[j+0] ^= d;
				data[j+s] ^= d;
				bits_ptr += 1;
			}
		}
	}
	
	/* input: r, sequence of bits to be permuted */
	/*        bits, condition bits of the Benes network */
	/*        rev, 0 for normal application; !0 for inverse */
	/* output: r, permuted bits */
	void apply_benes(byte[] r, final byte[] bits, int rev)
	{
		int i;

		int cond_ptr; 
		int inc, low;

		long[] bs = new long[64];
		long[] cond = new long[64];
		
		byte[] tmp = new byte[8];
		int r_ptr = 0;
		
		for (i = 0; i < 64; i++) {
			tmp[0] = r[r_ptr];
			tmp[1] = r[r_ptr + 1];
			tmp[2] = r[r_ptr + 2];
			tmp[3] = r[r_ptr + 3];
			tmp[4] = r[r_ptr + 4];
			tmp[5] = r[r_ptr + 5];
			tmp[6] = r[r_ptr + 6];
			tmp[7] = r[r_ptr + 7];
			
			bs[i] = util.load8(tmp);
			r_ptr += 8;
		}
		//System.out.print("bs:"); pri.longHexPri(bs);
		
		if (rev == 0) {
			inc = 256;
			cond_ptr = 0;
		}
		else {
			inc = -256;
			cond_ptr = (2 * params.GFBITS - 2) * 256;
		}
		
		transpose.transpose_64x64(bs, bs);
		//System.out.print("bs:"); pri.longHexPri(bs);		
		
		//System.out.print("bits["+bits.length+"]:"); pri.byteHexPri(bits);
		for (low = 0; low <= 5; low++) 
		{ 
			for (i = 0; i < 64; i++) {
				int cp = (i * 4) + cond_ptr;
				tmp[0] = bits[cp]; 
				tmp[1] = bits[cp + 1]; 
				tmp[2] = bits[cp + 2]; 
				tmp[3] = bits[cp + 3];
				
				cond[i] = (util.load4(tmp) & 0x00000000FFFFFFFFL);
			}			
			transpose.transpose_64x64(cond, cond);			
			layer(bs, cond, low); 
			cond_ptr += inc;
		}		
		transpose.transpose_64x64(bs, bs);
		//System.out.print("bs:"); pri.longHexPri(bs);
		
		for (low = 0; low <= 5; low++) {			
			for (i = 0; i < 32; i++) {
				int cp = (i * 8) + cond_ptr;
				tmp[0] = bits[cp];
				tmp[1] = bits[cp + 1];
				tmp[2] = bits[cp + 2];
				tmp[3] = bits[cp + 3];
				tmp[4] = bits[cp + 4];
				tmp[5] = bits[cp + 5];
				tmp[6] = bits[cp + 6];
				tmp[7] = bits[cp + 7];				
				cond[i] = util.load8(tmp);				
			}
			layer(bs, cond, low); 
			cond_ptr += inc; 
		}
		//System.out.print("bs:"); pri.longHexPri(bs);
		
		for (low = 4; low >= 0; low--) {			
			for (i = 0; i < 32; i++) {
				int cp = (i * 8) + cond_ptr;				
				tmp[0] = bits[cp];
				tmp[1] = bits[cp + 1];
				tmp[2] = bits[cp + 2];
				tmp[3] = bits[cp + 3];
				tmp[4] = bits[cp + 4];
				tmp[5] = bits[cp + 5];
				tmp[6] = bits[cp + 6];
				tmp[7] = bits[cp + 7];
				
				cond[i] = util.load8(tmp);
			}
			layer(bs, cond, low); 
			cond_ptr += inc; 
		}
		transpose.transpose_64x64(bs, bs);
		//System.out.print("bs:"); pri.longHexPri(bs);
		
		for (low = 5; low >= 0; low--) {			
			for (i = 0; i < 64; i++) {
				int cp = (i * 4) + cond_ptr;
				tmp[0] = bits[cp]; 
				tmp[1] = bits[cp + 1]; 
				tmp[2] = bits[cp + 2]; 
				tmp[3] = bits[cp + 3];
				
				cond[i] = util.load4(tmp);
			}
			transpose.transpose_64x64(cond, cond);
			layer(bs, cond, low); 
			cond_ptr += inc; 
		}
		transpose.transpose_64x64(bs, bs);
		//System.out.print("bs:"); pri.longHexPri(bs);

		r_ptr = 0;
		for (i = 0; i < 64; i++) {	
			util.store8(tmp, bs[i]);
			r[r_ptr] = tmp[0];
			r[r_ptr + 1] = tmp[1];
			r[r_ptr + 2] = tmp[2];
			r[r_ptr + 3] = tmp[3];
			r[r_ptr + 4] = tmp[4];
			r[r_ptr + 5] = tmp[5];
			r[r_ptr + 6] = tmp[6];
			r[r_ptr + 7] = tmp[7];
			
			r_ptr += 8;
		}		
	}
	
	
	/* input: condition bits c */
	/* output: support s */
	void support_gen(char[] s, final byte[] c)
	{
		char a;
		int i, j;
		byte[][] L = new byte[ params.GFBITS ][ (1 << params.GFBITS)/8 ];

		for (i = 0; i < params.GFBITS; i++) {
			for (j = 0; j < (1 << params.GFBITS)/8; j++)
				L[i][j] = 0;
		}

		for (i = 0; i < (1 << params.GFBITS); i++) {
			a = util.bitrev((char) i);
			for (j = 0; j < params.GFBITS; j++)
				L[j][ i/8 ] |= ((a >> j) & 1) << (i%8);
		}		
		
		for (j = 0; j < params.GFBITS; j++)
			apply_benes(L[j], c, 0);
		
		/*System.out.println("L row "+params.GFBITS);	
		for (i = 0; i < params.GFBITS; i++) {
			System.out.print("L"+i+"["+L[i].length+"]:"); pri.byteHexPri(L[i]);
		}*/
		
		
		for (i = 0; i < params.SYS_N; i++) {
			s[i] = 0;
			for (j = params.GFBITS-1; j >= 0; j--) {
				s[i] <<= 1;
				s[i] |= (L[j][i/8] >> (i%8)) & 1;
			}
		}
	}

}
