package mce;

public class Synd {
	static Params params = new Params();
	static Root root = new Root();
	static GF gf = new GF();
	
	/* input: Goppa polynomial f, support L, received word r */
	/* output: out, the syndrome of length 2t */
	void synd(char[] out, char[] f, char[] L, byte[] r)
	{
		int i, j;
		char e, e_inv, c;

		for (j = 0; j < 2 * params.SYS_T; j++)
			out[j] = 0;

		for (i = 0; i < params.SYS_N; i++)
		{
			c = (char) ((r[i/8] >>> (i%8)) & 1);

			e = root.eval(f, L[i]);
			e_inv = gf.gf_inv(gf.gf_mul(e,e));

			for (j = 0; j < 2 * params.SYS_T; j++)
			{
				out[j] = gf.gf_add(out[j], gf.gf_mul(e_inv, c));
				e_inv = gf.gf_mul(e_inv, L[i]);
			}
		}
	}

}
