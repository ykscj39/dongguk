package mce;

public class BM {
	static Params params = new Params();
	static GF gf = new GF();
	
	char min(char a, char b) {
		return ((a < b) ? a : b);
	}
	/* the Berlekamp-Massey algorithm */
	/* input: s, sequence of field elements */
	/* output: out, minimal polynomial of s */
	void bm(char[] out, char[] s)
	{
		int i;

		char N = 0;
		char L = 0;
		char mle;
		char mne;

		char[] T = new char[ params.SYS_T+1  ];
		char[] C = new char[ params.SYS_T+1 ];
		char[] B = new char[ params.SYS_T+1 ];

		char b = 1, d, f;

		//

		for (i = 0; i < params.SYS_T+1; i++)
			C[i] = B[i] = 0;

		B[1] = C[0] = 1;

		//

		for (N = 0; N < 2 * params.SYS_T; N++) {
			d = 0;

			for (i = 0; i <= min(N, (char) params.SYS_T); i++)
				d ^= gf.gf_mul(C[i], s[ N-i]);
		
			mne = d; mne -= 1;   mne >>= 15; mne -= 1;
			mle = N; mle -= 2*L; mle >>= 15; mle -= 1;
			mle &= mne;

			for (i = 0; i <= params.SYS_T; i++)			
				T[i] = C[i];

			f = gf.gf_frac(b, d);

			for (i = 0; i <= params.SYS_T; i++)			
				C[i] ^= gf.gf_mul(f, B[i]) & mne;

			L = (char) ((L & ~mle) | ((N+1-L) & mle));

			for (i = 0; i <= params.SYS_T; i++)			
				B[i] = (char) ((B[i] & ~mle) | (T[i] & mle));

			b = (char) ((b & ~mle) | (d & mle));

			for (i = params.SYS_T; i >= 1; i--) B[i] = B[i-1];
			B[0] = 0;
		}

		for (i = 0; i <= params.SYS_T; i++)
			out[i] = C[ params.SYS_T-i ];
	}
}
