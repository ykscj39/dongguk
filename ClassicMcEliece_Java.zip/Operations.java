package mce;

import java.util.Arrays;

public class Operations {
	Pri pri = new Pri();
	Params params = new Params();
	Rng rng = new Rng();
	Crypto_hash crypto_hash = new Crypto_hash();
	Util util = new Util();
	Sk_gen sk_gen = new Sk_gen();
	Pk_gen pk_gen = new Pk_gen();
	Controlbits controlbits = new Controlbits();
	Encrypt encrypt = new Encrypt();
	Decrypt decrypt = new Decrypt();
	
	int crypto_kem_enc(byte[] c, byte[] key, final byte[] pk) {
		byte[] two_e = new byte[ 1 + params.SYS_N/8 ];
		int e = 1;
		byte[] one_ec = new byte[ 1 + params.SYS_N/8 + (params.SYND_BYTES + 32) ];
		two_e[0] = 2;
		one_ec[0] = 1;
		
		byte[] tmp = null;
		
		tmp = new byte[two_e.length - e];
		encrypt.encrypt(c, pk, tmp);
		System.arraycopy(tmp, 0, two_e, e, tmp.length);
		//System.out.print("two_e:"); pri.byteHexPri(two_e);
		//System.out.print("c:"); pri.byteHexPri(c);
				
		tmp = new byte[c.length - params.SYND_BYTES];
		System.arraycopy(c, params.SYND_BYTES, tmp, 0, tmp.length);
		crypto_hash.crypto_hash_32b(tmp, two_e, two_e.length); 
		System.arraycopy(tmp, 0, c, params.SYND_BYTES, tmp.length);
		//System.out.print("two_e["+two_e.length+"]:"); pri.byteHexPri(two_e);
		//System.out.print("c:"); pri.byteHexPri(c);
		
		System.arraycopy(two_e, e, one_ec, 1, params.SYS_N/8);
		//System.out.print("one_ec:"); pri.byteHexPri(one_ec);	
		System.arraycopy(c, 0, one_ec, 1 + params.SYS_N/8, params.SYND_BYTES + 32);
		//System.out.print("one_ec:"); pri.byteHexPri(one_ec);
		
		
		crypto_hash.crypto_hash_32b(key, one_ec, one_ec.length);
		//System.out.print("key:"); pri.byteHexPri(key);
		
		return 0;
	}
	
	int crypto_kem_dec(byte[] key, final byte[] c, final byte[] sk) {
		int i;
		
		byte ret_confirm = 0;
		byte ret_decrypt = 0;

		char m;
		
		byte[] conf = new byte[32];
		byte[] two_e = new byte[ 1 + params.SYS_N/8 ];
		int e = 1;
		
		byte[] preimage = new byte[ 1 + params.SYS_N/8 + (params.SYND_BYTES + 32) ];
		int x = 0; //preimage pointer
		int s = 40 + params.IRR_BYTES + params.COND_BYTES; //sk pointer
		
		byte[] tmp1;
		byte[] tmp2;
		
		two_e[0]=2;
				
		tmp1 = new byte[two_e.length - e];		
		tmp2 = new byte[sk.length - 40];
		System.arraycopy(sk, 40, tmp2, 0, tmp2.length);		
		ret_decrypt = (byte) decrypt.decrypt(tmp1, tmp2, c);
		System.arraycopy(tmp1, 0, two_e, e, tmp1.length);
		//System.out.print("two_e:"); pri.byteHexPri(two_e);
				
		crypto_hash.crypto_hash_32b(conf, two_e, two_e.length);
		//System.out.print("conf:"); pri.byteHexPri(conf);
		
		for (i = 0; i < 32; i++)
			ret_confirm |= conf[i] ^ c[params.SYND_BYTES + i];
		
		m = (char) (ret_decrypt | ret_confirm);
		m -= 1;
		m >>= 8;
				
		preimage[x] = (byte) (m & 1); //*x++ = m & 1; 
		x++;
		
		for (i = 0; i < params.SYS_N/8; i++) {
			preimage[x] = (byte) ((~m & sk[s + i]) | (m & two_e[e + i]));
			x++;
			//*x++ = (~m & s[i]) | (m & e[i]);
		}
		
		for (i = 0; i < params.SYND_BYTES + 32; i++) {
			preimage[x] = c[i];
			x++;
			//*x++ = c[i];
		}
		//System.out.print("preimage:"); pri.byteHexPri(preimage);
		
		crypto_hash.crypto_hash_32b(key, preimage, preimage.length);
		//System.out.print("key:"); pri.byteHexPri(key);
		
		return 0;
	}
	
	int crypto_kem_keypair (byte[] pk, byte[] sk)
	{		
		int i;
		byte[] seed = new byte[33];// = {64};
		seed[0] = (byte)64;
		
		byte[] r = new byte[ params.SYS_N/8 + (1 << params.GFBITS) * Integer.BYTES + params.SYS_T*2 + 32 ];
		int rp, skp;

		char[] f = new char[ params.SYS_T ]; // element in GF(2^mt)
		char[] irr = new char[ params.SYS_T ]; // Goppa polynomial
		int[] perm = new int[ 1 << params.GFBITS ]; // random permutation as 32-bit integers
		short[] pi = new short[ 1 << params.GFBITS ]; // random permutation

		//char[] midd = new char[32];
		byte[] tmp = new byte[params.IRR_BYTES];
		if(32 > params.IRR_BYTES)
			tmp = new byte[32];
		
		
		System.arraycopy(seed, 1, tmp, 0, 32);
		//System.out.println("operations:seed[32]"); 
		rng.randombytes(tmp, 32);
		System.arraycopy(tmp, 0, seed, 1, 32);		
		
		//System.out.println(PAR.SYS_N/8 + (1 << PAR.GFBITS) * Integer.BYTES + PAR.SYS_T*2 + 32);
		int bk = 0;
		while (true)
		{
			bk += 1;
			if(bk == 4)	break;
			
			rp = r.length - 32;//rp = &r[ r.length() - 32 ];
			skp = 0; //skp = sk;
			
			// expanding and updating the seed
			crypto_hash.shake(r, r.length, seed, (long)33);
						
			System.arraycopy(seed, 1, sk, 0, 32);
			skp += 32 + 8;
			//System.arraycopy(r, r.length - 32, seed, 1, 32);
			
			rp -= f.length * 2;
			
			Arrays.fill(tmp, (byte)0);
			for(i=0; i < params.SYS_T; i++) {
				System.arraycopy(r, rp + i * 2, tmp, 0, 2);
				f[i] = util.load_gf(tmp);
			}
			//System.out.print("f:"); pri.charHexPri(f);
			
			if (sk_gen.genpoly_gen(irr, f) != 0)
				continue;
			//System.out.print("irr:"); pri.charHexPri(irr);
			
			for (i = 0; i < params.SYS_T; i++) {
				System.arraycopy(sk, skp + i * 2, tmp, 0, 2);
				util.store_gf(tmp, irr[i]);
				System.arraycopy(tmp, 0, sk, skp + i * 2, 2);
			}
			//System.out.print("sk:"); pri.byteHexPri(sk);
			
			skp += params.IRR_BYTES;
			
			// generating permutation
			rp -= perm.length * 4;

			//System.out.print("perm:");
			for (i = 0; i < (1 << params.GFBITS); i++) {
				System.arraycopy(r, rp + i * 4, tmp, 0, 4);
				perm[i] = util.load4(tmp); 
				//System.out.print(String.format("%08x", perm[i]));
			}
			//System.out.println();
				
			System.arraycopy(sk, skp - params.IRR_BYTES, tmp, 0, params.IRR_BYTES); System.arraycopy(r, r.length - 32, seed, 1, 32);
			if (pk_gen.pk_gen(pk, tmp, perm, pi) != 0)
				continue;			
			//System.out.print("pk="); pri.byteHexPri(pk);
			
			tmp = new byte[sk.length - skp];	
			controlbits.controlbitsfrompermutation(tmp, pi, params.GFBITS, 1 << params.GFBITS);
			System.arraycopy(tmp, 0, sk, skp, sk.length - skp);
			//System.out.print("sk2:"); pri.byteHexPri(sk);
			
			skp += params.COND_BYTES;
			
			// storing the random string s
			rp -= params.SYS_N/8;			
			System.arraycopy(r, rp, sk, skp, params.SYS_N/8);//memcpy(skp, rp, SYS_N/8);
			//System.out.print("sk3:"); pri.byteHexPri(sk);
			
			// storing positions of the 32 pivots
			tmp = new byte[8];
			util.store8(tmp, 0xFFFFFFFFL);
			System.arraycopy(tmp, 0, sk, 32, 8);
			//System.out.print("sk4:"); pri.byteHexPri(sk);
			
			break;
		}
		
		return (int)0;
	}

}
