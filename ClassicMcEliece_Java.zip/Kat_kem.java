package mce;

import java.util.Arrays;

public class Kat_kem {
	public static final int KATNUM = 2;
	public static final int KAT_SUCCESS         = 0;
	public static final int KAT_FILE_OPEN_ERROR = -1;
	public static final int KAT_CRYPTO_FAILURE  = -4;
	
	public static byte[] entropy_input = new byte[48];
	public static byte[][] seed = new byte[KATNUM][48];
	
	//static Pri pri = new Pri();
	static Operations operations = new Operations();
	static Pri pri = new Pri();
	static Util util = new Util();
		
	public static void main(String[] args) {
		 
		// TODO Auto-generated method stub
		GF gf = new GF();
		gf.setData();
		gf.area();
				
		//int vInt = Integer.parseUnsignedInt("4294967295");
	    //System.out.println(vInt); // -1
	    //String sInt = Integer.toUnsignedString(vInt);
	    //System.out.println(sInt); // 4294967295

		//////////////////////////////////////////////////
	    Rng rng = new Rng();
	    Crypto_kem crypto_kem = new Crypto_kem();
	   
	    int ret_val;
	    int i, j;
	    byte[] ct = null;
	    byte[] ss = null;
	    byte[] ss1 = null;
	    byte[] pk = null;
	    byte[] sk = null;
   
	    for(i=0; i < 48; i++)
	    	entropy_input[i] = (byte) i;
	    rng.randombytes_init(entropy_input, null, 256);
	    //pri.byteHexPri(entropy_input);

	    for (i=0; i<KATNUM; i++) {
	    	rng.randombytes(seed[i], 48);
	    }
	    	   
	    for (i=0; i<KATNUM; i++) {//KATNUM
	    	if (ct == null) ct = new byte[crypto_kem.crypto_kem_CIPHERTEXTBYTES];
	    	if (ss == null) ss = new byte[crypto_kem.crypto_kem_BYTES];
	        if (ss1 == null) ss1 = new byte[crypto_kem.crypto_kem_BYTES];
	        if (pk == null) pk = new byte[crypto_kem.crypto_kem_PUBLICKEYBYTES];
	        if (sk == null) sk = new byte[crypto_kem.crypto_kem_SECRETKEYBYTES];
       
	        rng.randombytes_init(seed[i], null, 256);
	    
	        System.out.print("seed:"); pri.byteHexPri(seed[i]);
	        
	        if ( (ret_val = operations.crypto_kem_keypair(pk, sk)) != 0) {
	        	System.out.println("crypto_kem_keypair returned" + ret_val);
	        }
	        //System.out.print("pk:"); pri.byteHexPri(pk);
	        //System.out.print("sk:"); pri.byteHexPri(sk);
	        
	        if ( (ret_val = operations.crypto_kem_enc(ct, ss, pk)) != 0) {
	        	System.out.println("crypto_kem_enc returned" + ret_val);
	        }	             
	        System.out.print("ct:"); pri.byteHexPri(ct);
	        //System.out.print("oss:"); pri.byteHexPri(ss);	        
	        
	        if ( (ret_val = operations.crypto_kem_dec(ss1, ct, sk)) != 0) {
	        	System.out.println("crypto_kem_dec returned" + ret_val);
	        }	        
	        
	        if ( Arrays.equals(ss, ss1) == false ) {
	        	System.out.println("crypto_kem_dec returned bad 'ss' value");
	        }
	        
	        System.out.print("ss:"); pri.byteHexPri(ss1);
	        System.out.println("");
	    }
	    
	    System.out.println("main end");
		//return KAT_SUCCESS;
	}
}
