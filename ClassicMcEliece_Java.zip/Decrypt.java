package mce;

public class Decrypt {
	static Pri pri = new Pri();
	static Params params = new Params();
	static Util util = new Util();
	static Benes benes = new Benes();
	static Synd synd = new Synd();
	static BM bm = new BM();
	static Root root = new Root();
	static GF gf = new GF();
	
	/* Niederreiter decryption with the Berlekamp decoder */
	/* intput: sk, secret key */
	/*         c, ciphertext */
	/* output: e, error vector */
	/* return: 0 for success; 1 for failure */
	int decrypt(byte[] e, final byte[] sk, final byte[] c)
	{
		int i, w = 0; 
		char check;	

		byte[] r = new byte[ params.SYS_N/8 ];

		char[] g = new char[ params.SYS_T+1 ];
		char[] L = new char[ params.SYS_N ];

		char[] s = new char[ params.SYS_T*2 ];
		char[] s_cmp = new char[ params.SYS_T*2 ];
		char[] locator = new char[ params.SYS_T+1 ];
		char[] images = new char[ params.SYS_N ];

		char t;
		
		byte[] tmp  = new byte[2];
		int skp = 0;
		
		//System.out.println("decrypt");
		//System.out.print("sk["+sk.length+"]:"); pri.byteHexPri(sk);
		//System.out.print("c["+c.length+"]:"); pri.byteHexPri(c);
		//System.out.print("e["+e.length+"]:"); pri.byteHexPri(e);
		
		for (i = 0; i < params.SYND_BYTES; i++)       r[i] = c[i];
		for (i = params.SYND_BYTES; i < params.SYS_N/8; i++) r[i] = 0;
		//System.out.print("r["+r.length+"]:"); pri.byteHexPri(r);

		for (i = 0; i < params.SYS_T; i++) {
			tmp[0] = sk[skp];
			tmp[1] = sk[skp + 1];
			g[i] = util.load_gf(tmp); 
			skp += 2; 
		} g[ params.SYS_T ] = 1;
		//System.out.print("g["+g.length+"]:"); pri.charHexPri(g);

		//System.out.println(skp);
		tmp = new byte[sk.length - skp];
		System.arraycopy(sk, skp, tmp, 0, tmp.length);
		benes.support_gen(L, tmp);
		tmp = null;
		//System.out.print("L["+L.length+"]:"); pri.charHexPri(L);

		synd.synd(s, g, L, r);
		//System.out.print("s["+s.length+"]:"); pri.charHexPri(s);

		bm.bm(locator, s);
		//System.out.print("locator["+locator.length+"]:"); pri.charHexPri(locator);
		
		root.root(images, locator, L);
		//System.out.print("images["+images.length+"]:"); pri.charHexPri(images);

		//
		
		for (i = 0; i < params.SYS_N/8; i++) 
			e[i] = 0;

		for (i = 0; i < params.SYS_N; i++) {
			t = (char) (gf.gf_iszero(images[i]) & 1);

			e[ i/8 ] |= t << (i%8);
			w += t;
	    }
		
		if(params.KAT)
		{
			int k;
			System.out.print("decrypt e: positions");
			for (k = 0;k < params.SYS_N;++k) {
				if ( (e[k/8] & (1 << (k&7))) != 0 )
					System.out.print(" " + k);
			}
			System.out.println();
		}
		synd.synd(s_cmp, g, L, e);
		//System.out.print("s_cmp["+s_cmp.length+"]:"); pri.charHexPri(s_cmp);

		check = (char) w;
		check ^= params.SYS_T;

		for (i = 0; i < params.SYS_T*2; i++)
			check |= s[i] ^ s_cmp[i]; 

		check -= 1;
		check >>= 15;

		return check ^ 1;
	}

}
