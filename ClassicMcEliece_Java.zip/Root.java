package mce;

public class Root {
	Params params = new Params();
	GF gf = new GF();
	/* input: polynomial f and field element a */
	/* return f(a) */
	char eval(char[] f, char a)
	{
		int i;
		char r;
		
		r = f[ params.SYS_T ];

		for (i = params.SYS_T-1; i >= 0; i--)
		{
			r = gf.gf_mul(r, a);
			r = gf.gf_add(r, f[i]);
		}

		return r;
	}
	
	/* input: polynomial f and list of field elements L */
	/* output: out = [ f(a) for a in L ] */
	void root(char[] out, char[] f, char[] L)
	{
		int i; 

		for (i = 0; i < params.SYS_N; i++)
			out[i] = eval(f, L[i]);
	}
}
