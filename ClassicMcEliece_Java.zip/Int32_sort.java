package mce;

import mce.Uint64_sort.NumberClass;

public class Int32_sort {
	
	public class NumberClass{
		int num;
		NumberClass (int num){
			this.num = num;
		}
	}
	
	static void int32_MINMAX (NumberClass a, NumberClass b) {
		do {
			int ab = b.num ^ a.num; 
			//System.out.println("ab:" + String.format("%08x", ab));
			int c = b.num - a.num;
			//System.out.println("c:" + String.format("%08x", c));
			c ^= ab & (c ^ b.num);
			//System.out.println("c(XOR):" + String.format("%08x", c));
			c >>= 31;
			//System.out.println("c(shift):" + String.format("%08x", c));
			c &= ab;
			//System.out.println("c(AND):" + String.format("%08x", c));
			a.num ^= c;
			b.num ^= c;
		} while(false);
	}
	
	static void int32_sort(int[] x, long n)
	{
		long top, p, q, r, i;
		Int32_sort obj = new Int32_sort();
		Int32_sort.NumberClass num1 = obj.new NumberClass(0);
		Int32_sort.NumberClass num2 = obj.new NumberClass(0);
		
		if (n < 2) return;
		
		top = 1;
		while (top < n - top) top += top;
		
		for (p = top; p > 0; p >>= 1) {
			for (i = 0; i < n - p; ++i) {
				if ((i & p) == 0) {
					num1.num = x[(int) i]; num2.num = x[(int) (i + p)];
					int32_MINMAX(num1, num2);
					x[(int) i] = num1.num; x[(int) (i + p)] = num2.num;
				}
			}
			i = 0;
			for (q = top; q > p; q >>= 1) {
				for (;i < n - q;++i) {
					if ((i & p) == 0) {
						int a = x[(int) (i + p)];
						for (r = q;r > p;r >>= 1) {
							num1.num = a; num2.num = x[(int) (i + r)];
							int32_MINMAX(num1, num2);
							a = num1.num; x[(int) (i + r)] = num2.num;
						}
						x[(int) (i + p)] = a;
					}
				}
			}
		}
	}
}
