package mce;

import java.util.Arrays;

public class Controlbits {
	static Pri pri = new Pri();
	static Int32_sort int32_sort = new Int32_sort();
	
	/* parameters: 1 <= w <= 14; n = 2^w */
	/* input: permutation pi of {0,1,...,n-1} */
	/* output: (2m-1)n/2 control bits at positions pos,pos+step,... */
	/* output position pos is by definition 1&(out[pos/8]>>(pos&7)) */
	/* caller must 0-initialize positions first */
	/* temp must have space for int32[2*n] */

	static void cbrecursion(byte[] out, long pos, long step, final short[] pi, long w, long n, int[] temp) {
		//System.out.println("cnt="+cnt);
		
		long x, i, j, k;
		
		int[] A = temp;
		//System.arraycopy(temp, 0, A, 0, (int) n);
		
		int[] B = new int[(int) n];
		System.arraycopy(temp, (int) n, B, 0, (int) n);
		
		short[] q = new short[(int) n];
		/* q can start anywhere between temp+n and temp+n/2 */
				
		if(w == 1) {
			out[(int) (pos >> 3)] ^= pi[0] << (pos & 7);
			return;			
		}
		
		//for (x = 0;x < n;++x) A[x] = ((pi[x]^1)<<16)|pi[x^1];
		for (x = 0; x < n; ++x)
		{
			int tmp = 0x0000;
			tmp ^= (pi[(int) x] ^ 1);
			tmp = tmp << 16;
			tmp ^= pi[(int) (x ^ 1)];
			A[(int) x] = tmp;
		}		
		int32_sort.int32_sort(A, n); /* A = (id<<16)+pibar */
		/*if(cnt == 1) {
			System.out.print("A="); pri.intHexPri(A);
		}*/
		
		for (x = 0; x < n; ++x) {
			int Ax = A[(int) x];
			int px = Ax & 0xffff;
			int cx = px;
			
			if (x < cx) cx = (int) x;
		    B[(int) x] = (px << 16) | cx;
		}
		/* B = (p<<16)+c */
		
		for (x = 0; x < n; ++x) A[(int) x] = (int) ((A[(int) x] << 16) | x); /* A = (pibar<<16)+id */
		int32_sort.int32_sort(A, n); /* A = (id<<16)+pibar^-1 */
		
		for (x = 0;x < n;++x) A[(int) x] = (A[(int) x] << 16)+(B[(int) x] >> 16); /* A = (pibar^(-1)<<16)+pibar */
		int32_sort.int32_sort(A, n); /* A = (id<<16)+pibar^2 */
		
		if (w <= 10) {
			for (x = 0; x < n; ++x) B[(int) x] = ((A[(int) x] & 0xffff) << 10)|(B[(int) x] & 0x3ff);
			
			for (i = 1; i < w - 1; ++i) {
				/* B = (p<<10)+c */
				
				for (x = 0; x < n; ++x) A[(int) x] = (int) ( ((B[(int) x] & ~0x3ff) << 6) | x ); /* A = (p<<16)+id */
				int32_sort.int32_sort(A, n); /* A = (id<<16)+p^{-1} */
				
				for (x = 0; x < n; ++x) A[(int) x] = (A[(int) x] << 20) | B[(int) x]; /* A = (p^{-1}<<20)+(p<<10)+c */
				int32_sort.int32_sort(A, n); /* A = (id<<20)+(pp<<10)+cp */
				
				for (x = 0; x < n; ++x) {
					 int ppcpx = A[(int) x] & 0xfffff;
					 int ppcx = (A[(int) x] & 0xffc00) | (B[(int) x]&0x3ff);
					 if (ppcpx < ppcx) ppcx = ppcpx;
					 B[(int) x] = ppcx;
				}
			}
			for (x = 0;x < n;++x) B[(int) x] &= 0x3ff;
		}
		else {
			for (x = 0; x < n; ++x) B[(int) x] = (A[(int) x] << 16) | (B[(int) x] & 0xffff);
			for (i = 1; i < w - 1; ++i) {
				/* B = (p<<16)+c */
				for (x = 0; x < n; ++x) A[(int) x] = (int) ((B[(int) x] & ~0xffff) | x);
				int32_sort.int32_sort(A, n); /* A = (id<<16)+p^(-1) */
				
				for (x = 0; x < n; ++x) A[(int) x] = (A[(int) x] << 16) | (B[(int) x] & 0xffff);
				/* A = p^(-1)<<16+c */
				
				if (i < w - 2) {
					for (x = 0; x < n; ++x) B[(int) x] = (A[(int) x] & ~0xffff) | (B[(int) x] >> 16);
					/* B = (p^(-1)<<16)+p */
					int32_sort.int32_sort(B, n); /* B = (id<<16)+p^(-2) */
					
					for (x = 0; x < n; ++x) B[(int) x] = (B[(int) x] << 16) | (A[(int) x] & 0xffff);
					/* B = (p^(-2)<<16)+c */
				}
				
				int32_sort.int32_sort(A, n);
				/* A = id<<16+cp */
				for (x = 0; x < n; ++x) {
					int cpx = (B[(int) x] & ~0xffff)|(A[(int) x] & 0xffff);
			        if (cpx < B[(int) x]) B[(int) x] = cpx;
			    }				
			}
			for (x = 0; x < n; ++x) B[(int) x] &= 0xffff;
		}
		for (x = 0; x < n; ++x) A[(int) x] = (int) ((((int)pi[(int) x]) << 16) + x);
		int32_sort.int32_sort(A, n); /* A = (id<<16)+pi^(-1) */
		
		for (j = 0; j < n/2; ++j) {
			long lx = 2*j;
			int fj = B[(int) lx]&1; /* f[j] */
		    int Fx = (int) (lx + fj); /* F[x] */
		    int Fx1 = Fx^1; /* F[x+1] */
		    
		    out[(int) (pos >> 3)] ^= fj << (pos&7);
		    pos += step;
		    
		    B[(int) lx] = (A[(int) lx]<<16)|Fx;
		    B[(int) (lx+1)] = (A[(int) (lx+1)]<<16)|Fx1;
		}
		/* B = (pi^(-1)<<16)+F */
		int32_sort.int32_sort(B, n); /* B = (id<<16)+F(pi) */
		
		pos += (2*w - 3) * step * (n/2);
		
		for (k = 0; k < n/2; ++k) {
			long y = 2*k;
			int lk = B[(int) y] & 1; /* l[k] */
			int Ly = (int) (y + lk); /* L[y] */
			int Ly1 = Ly ^ 1; /* L[y+1] */
			
			out[(int) (pos >> 3)] ^= lk << (pos & 7);
			pos += step;
			
			A[(int) y] = (Ly << 16) | (B[(int) y] & 0xffff);
			A[(int) (y + 1)] = (Ly1 << 16) | (B[(int) (y + 1)] & 0xffff);
		}
		/* A = (L<<16)+F(pi) */
		
		int32_sort.int32_sort(A, n); /* A = (id<<16)+F(pi(L)) = (id<<16)+M */
		
		pos -= (2*w - 2) * step * (n/2);
				
		for (j = 0; j < n/2; ++j) {
			q[(int) j] = (short) ((A[(int) (2 * j)] & 0xffff) >> 1);
		    q[(int) (j + n/2)] = (short) ((A[(int) (2 * j + 1)] & 0xffff) >> 1);
		}
		
		System.arraycopy(B, 0, temp, (int) n, (int) n);
		
		cbrecursion(out, pos, step * 2, q, w - 1, n/2, temp);
		
		short[] tmp = new short[q.length];
		System.arraycopy(q, (int)n/2, tmp, 0, (int)n/2 );
		cbrecursion(out, pos + step, step * 2, tmp, w - 1, n/2, temp);
		System.arraycopy(tmp, 0, q, (int)n/2, (int)n/2 );
		
		//System.out.print("out:"); Pri.byteHexPri(out);
	}
	
	/* input: p, an array of int16 */
	/* input: n, length of p */
	/* input: s, meaning that stride-2^s cswaps are performed */
	/* input: cb, the control bits */
	/* output: the result of apply the control bits to p */
	static void layer(short[] p, final byte[] cb, int s, int n) {
		int i, j;
		int stride = 1 << s;
		int index = 0;
		short d, m;
		
		for (i = 0; i < n; i += stride*2) {
			for (j = 0; j < stride; j++) {
				d = (short) (p[ i+j ] ^ p[ i+j+stride ]);
				m = (short) ((cb[ index >> 3 ] >> (index & 7)) & 1);
				m = (short) -m;
				d &= m;
				p[ i+j ] ^= d;
				p[ i+j+stride ] ^= d;
				index++;
			}
		}
	}
	
	void controlbitsfrompermutation(byte[] out, final short[] pi, long w, long n) {
		int[] temp = new int[(int) (2 * n)];
		short[] pi_test = new short[(int) n];
		short diff;
		
		int i;
		byte[] ptr = null;
		int p = 0;
		
		/*System.out.println("w="+w); 
		System.out.println("n="+n);
		System.out.println("out.length="+out.length);
		System.out.println(((((2*w-1)*n/2)+7)/8));
		System.out.println("n >> 4="+( n >> 4));
		*/
		
		while(true) {
			Arrays.fill(out, 0, (int) ((((2 * w - 1) * n/2)+7)/8), (byte) 0);
			//System.out.print("out1["+out.length+"]:"); Pri.byteHexPri(out);
			
			cbrecursion(out, 0, 1, pi, w, n, temp);
			//System.out.print("out2["+out.length+"]:"); Pri.byteHexPri(out);
			
			// check for correctness
			for (i = 0; i < n; i++)
				pi_test[i] = (short) i;
			//System.out.print("pi_test["+pi_test.length+"]:"); Pri.shortHexPri(pi_test);
			
		    ptr = out;
		    p = 0;
		    for (i = 0; i < w; i++) {
		    	byte[] tmp = new byte[(int) n >> 4]; //(int) (((n/((1 << i) * 2)) * (1 << i)) >>> 4) 
		    	System.arraycopy(ptr, p, tmp, 0, (int) n >> 4);
		    	layer(pi_test, tmp, i, (int) n);
		    	p += n >> 4;
		    }
		    //System.out.print("pi_test["+pi_test.length+"]:"); Pri.shortHexPri(pi_test);

		    for (i = (int) (w-2); i >= 0; i--) {
		    	byte[] tmp = new byte[(int) n >> 4];
		    	System.arraycopy(ptr, p, tmp, 0, (int) n >> 4);
		    	layer(pi_test, tmp, i, (int) n);
		    	p += n >> 4;
		    }
		    //System.out.print("pi_test["+pi_test.length+"]:"); Pri.shortHexPri(pi_test);

		    diff = 0;
		    for (i = 0; i < n; i++)
		    	diff |= pi[i] ^ pi_test[i];
		    		    
		    if (diff == 0)
		    	break;
		}	
	}
}
